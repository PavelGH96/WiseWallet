#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Синхронно меняет номер версии во всех местах, где он прописан.

Версия живёт в трёх файлах, и раньше её приходилось править руками:
из-за этого README отставал от кода, а service worker держал старый кэш.

Запуск из папки проекта:

    python3 tools/bump-version.py 3.38
"""
import io, os, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def read(name):
    with io.open(os.path.join(ROOT, name), encoding="utf-8") as f:
        return f.read()


def write(name, text):
    with io.open(os.path.join(ROOT, name), "w", encoding="utf-8") as f:
        f.write(text)


def main():
    if len(sys.argv) != 2 or not re.match(r"^\d+\.\d+$", sys.argv[1]):
        print("Использование: python3 tools/bump-version.py 3.38")
        return 1
    new = sys.argv[1]

    html = read("index.html")
    m = re.search(r'const WW_VERSION = "([\d.]+)";', html)
    if not m:
        print("Не нашёл WW_VERSION в index.html")
        return 1
    old = m.group(1)
    if old == new:
        print("Версия уже " + new)
        return 0

    write("index.html", html.replace('const WW_VERSION = "%s";' % old,
                                     'const WW_VERSION = "%s";' % new, 1))

    sw = read("sw.js")
    sw_old = 'CACHE = "wisewallet-v%s"' % old
    if sw_old not in sw:
        print("Внимание: в sw.js не найдено " + sw_old + " — проверьте вручную")
    else:
        write("sw.js", sw.replace(sw_old, 'CACHE = "wisewallet-v%s"' % new, 1))

    readme = read("README.md")
    write("README.md", readme.replace("# WiseWallet v%s" % old,
                                      "# WiseWallet v%s" % new, 1))

    print("Версия %s → %s (index.html, sw.js, README.md)" % (old, new))
    print("Не забудьте описать изменения в README и переустановить PWA — новый кэш подхватится сам.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
