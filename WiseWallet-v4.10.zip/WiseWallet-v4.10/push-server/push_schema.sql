-- WiseWallet v3.9: фоновые push-уведомления.
-- Выполните весь файл в Supabase → SQL Editor.

-- ============================================================
-- 1. Таблица подписок на push (по одной строке на устройство)
-- ============================================================
create table if not exists public.ww_push (
  endpoint text primary key,
  sub jsonb not null,
  sync_id text,
  user_id uuid,
  tz_min integer default 300,
  created_at timestamptz not null default now()
);
alter table public.ww_push enable row level security;
drop policy if exists ww_push_select on public.ww_push;
drop policy if exists ww_push_insert on public.ww_push;
drop policy if exists ww_push_update on public.ww_push;
drop policy if exists ww_push_delete on public.ww_push;
-- Политики открытые (как у ww_state в legacy-режиме), чтобы работало и без входа по email.
-- В подписке нет финансовых данных — только технический адрес доставки уведомлений.
create policy ww_push_select on public.ww_push for select using (true);
create policy ww_push_insert on public.ww_push for insert with check (true);
create policy ww_push_update on public.ww_push for update using (true);
create policy ww_push_delete on public.ww_push for delete using (true);

-- ============================================================
-- 2. Расписание: вызывать функцию ww-push каждый день в 09:00
--    по Екатеринбургу (04:00 UTC).
--    ПЕРЕД ЗАПУСКОМ ЗАМЕНИТЕ:
--      YOUR_PROJECT_REF — ref вашего проекта (Settings → General),
--      YOUR_ANON_KEY   — anon key (Settings → API Keys).
-- ============================================================
create extension if not exists pg_cron;
create extension if not exists pg_net;

select cron.schedule(
  'ww-push-daily',
  '0 4 * * *',
  $$
  select net.http_post(
    url := 'https://YOUR_PROJECT_REF.supabase.co/functions/v1/ww-push',
    headers := jsonb_build_object('Content-Type', 'application/json', 'Authorization', 'Bearer YOUR_ANON_KEY'),
    body := '{}'::jsonb
  );
  $$
);

-- Полезное:
-- Сменить время: удалить и создать заново с другим cron-выражением (время в UTC!):
--   select cron.unschedule('ww-push-daily');
-- Проверить список задач:
--   select * from cron.job;
-- Посмотреть последние запуски:
--   select * from cron.job_run_details order by start_time desc limit 10;
