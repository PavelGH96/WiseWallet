// WiseWallet: Edge Function «ww-push» — рассылка фоновых push-напоминаний о платежах.
// Запускается по расписанию (pg_cron, см. push_schema.sql) или вручную.
// Секреты (Edge Functions → Secrets): VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY, VAPID_SUBJECT.

import { createClient } from "npm:@supabase/supabase-js@2";
import webpush from "npm:web-push@3.6.7";

// --- upcoming:start (порт логики upcomingReminders из приложения; чистый JS) ---
function upcoming(state, tzMin) {
  const days = Number((state && state.settings && state.settings.reminderDays) != null ? state.settings.reminderDays : 3);
  if (!days) return [];
  const dismissed = (state && state.settings && state.settings.dismissed) || {};
  const nowL = new Date(Date.now() + (tzMin || 0) * 60000);
  const y0 = nowL.getUTCFullYear(), m0 = nowL.getUTCMonth(), d0 = nowL.getUTCDate();
  const today = Date.UTC(y0, m0, d0);
  const horizon = today + days * 86400000;
  const dim = (y, m) => new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
  const key = (t) => { const d = new Date(t); return d.getUTCFullYear() + "-" + String(d.getUTCMonth() + 1).padStart(2, "0") + "-" + String(d.getUTCDate()).padStart(2, "0"); };
  const todayKey = key(today);
  const nextFromDay = (day) => {
    let y = y0, m = m0;
    let t = Date.UTC(y, m, Math.min(day || 1, dim(y, m)));
    if (t < today) { m++; if (m > 11) { m = 0; y++; } t = Date.UTC(y, m, Math.min(day || 1, dim(y, m))); }
    return t;
  };
  const list = [];
  for (const c of ((state && state.credits) || []).filter((x) => x.status === "active")) {
    if (!c.payDay) continue;
    const t = nextFromDay(c.payDay);
    if (t > horizon) continue;
    if (dismissed["credit:" + c.id + ":" + key(t)]) continue;
    const grace = c.graceFrom && c.graceTo && todayKey >= c.graceFrom && todayKey <= c.graceTo;
    list.push({ name: c.name, amount: grace ? +c.gracePayment || 0 : +c.payment || 0, days: Math.round((t - today) / 86400000) });
  }
  for (const r of (state && state.recurring) || []) {
    const t = nextFromDay(r.day);
    if (t > horizon) continue;
    const k = (r.type === "income" ? "recur-inc:" : "recur:") + r.id + ":" + key(t);
    if (dismissed[k]) continue;
    list.push({ name: r.name, amount: +r.amount || 0, days: Math.round((t - today) / 86400000) });
  }
  for (const c of ((state && state.credits) || []).filter((x) => x.status === "active" && x.graceTo)) {
    const p = String(c.graceTo).split("-").map(Number);
    if (p.length !== 3 || p.some(isNaN)) continue;
    const t = Date.UTC(p[0], p[1] - 1, p[2]);
    if (t < today || t > horizon) continue;
    if (dismissed["grace:" + c.id + ":" + c.graceTo]) continue;
    list.push({ name: "Конец льготного периода: " + c.name, amount: +c.payment || 0, days: Math.round((t - today) / 86400000) });
  }
  list.sort((a, b) => a.days - b.days);
  return list;
}
function fmtAmount(a) { try { return new Intl.NumberFormat("ru-RU").format(Math.round(a)) + " \u20bd"; } catch (e) { return a + " \u20bd"; } }
function whenText(d) { return d <= 0 ? "сегодня" : d === 1 ? "завтра" : "через " + d + " дн."; }
// --- upcoming:end ---

Deno.serve(async (_req) => {
  const supa = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  webpush.setVapidDetails(
    Deno.env.get("VAPID_SUBJECT") || "mailto:pavel.demenshin@gmail.com",
    Deno.env.get("VAPID_PUBLIC_KEY")!,
    Deno.env.get("VAPID_PRIVATE_KEY")!
  );

  const { data: subs, error } = await supa.from("ww_push").select("*");
  if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500 });

  let sent = 0, removed = 0, empty = 0;
  for (const row of subs || []) {
    let state: unknown = null;
    if (row.user_id) {
      const r = await supa.from("ww_user_state").select("data").eq("user_id", row.user_id).maybeSingle();
      state = r.data ? r.data.data : null;
    } else if (row.sync_id) {
      const r = await supa.from("ww_state").select("data").eq("id", row.sync_id).maybeSingle();
      state = r.data ? r.data.data : null;
    }
    if (!state) { empty++; continue; }

    const items = upcoming(state, row.tz_min == null ? 300 : row.tz_min);
    if (!items.length) { empty++; continue; }

    const title = items.length === 1 ? "WiseWallet: платёж " + whenText(items[0].days) : "WiseWallet: платежи в ближайшие дни (" + items.length + ")";
    const body = items.slice(0, 6).map((x) => x.name + " — " + fmtAmount(x.amount) + " (" + whenText(x.days) + ")").join("\n");

    try {
      await webpush.sendNotification(row.sub, JSON.stringify({ title, body, tag: "ww-daily" }));
      sent++;
    } catch (e) {
      const code = e && typeof e === "object" && "statusCode" in e ? (e as { statusCode: number }).statusCode : 0;
      if (code === 404 || code === 410) { await supa.from("ww_push").delete().eq("endpoint", row.endpoint); removed++; }
    }
  }

  return new Response(JSON.stringify({ subscriptions: (subs || []).length, sent, removed, empty }), { headers: { "Content-Type": "application/json" } });
});
