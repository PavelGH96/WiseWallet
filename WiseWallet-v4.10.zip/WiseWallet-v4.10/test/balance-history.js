/* Тесты v3.59: стартовый баланс кошелька не течёт в прошлые месяцы + целые иконки/надписи */
const { chromium } = require('playwright');
const FILE = process.env.WW_APP || 'file://' + require('path').resolve(__dirname, '../index.html');
const fails = [];
function check(name, cond, extra) {
  console.log((cond ? '  ok   ' : '  FAIL ') + name + (extra !== undefined ? '  -> ' + JSON.stringify(extra) : ''));
  if (!cond) fails.push(name);
}

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text())) errors.push('CONSOLE: ' + m.text()); });

  await page.goto(FILE);
  await page.evaluate(() => localStorage.setItem('ww_session_v2', JSON.stringify({ access_token: 'x.y.z', refresh_token: 'r', expires_at: Date.now() + 3600e3, user_id: '00000000-0000-4000-8000-000000000001', email: 't359@test.local' })));
  await page.goto(FILE);
  await page.waitForTimeout(1800);

  check('версия приложения задана', /^\d+\.\d+$/.test(String(await page.evaluate(() => WW_VERSION))), await page.evaluate(() => WW_VERSION));

  /* ---------- 1. битые символы и иконка истории ---------- */
  const glyphs = await page.evaluate(() => {
    const bad = [];
    const walk = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = walk.nextNode())) if (n.nodeValue.indexOf('\uFFFD') !== -1) bad.push(n.nodeValue.trim().slice(0, 60));
    return { bad, srcHasBad: document.documentElement.innerHTML.indexOf('\uFFFD') !== -1 };
  });
  check('нет битых символов в интерфейсе', glyphs.bad.length === 0 && !glyphs.srcHasBad, glyphs);

  const hist = await page.evaluate(() => {
    const btns = Array.from(document.querySelectorAll('.ww331-bbtn'));
    const b = btns.find(x => /История изменений/.test(x.title || ''));
    if (!b) return { found: false };
    const svg = b.querySelector('svg');
    const r = svg ? svg.getBoundingClientRect() : null;
    return { found: true, svg: !!svg, w: r ? Math.round(r.width) : 0, h: r ? Math.round(r.height) : 0, text: (b.textContent || '').trim() };
  });
  check('у кнопки «История изменений» есть видимая иконка', hist.found && hist.svg && hist.w > 10 && hist.h > 10 && hist.text === '', hist);

  const allIcons = await page.evaluate(() => {
    const bar = document.querySelector('.ww331-bar');
    if (!bar) return { ok: false };
    if (window.ww49QuickBarOpen) ww49QuickBarOpen();
    const btns = Array.from(bar.querySelectorAll('.ww331-bbtn'));
    return {
      ok: true,
      n: btns.length,
      empty: btns.filter(b => !b.querySelector('svg') && !(b.textContent || '').replace(/\s|\d/g, '')).map(b => b.title || b.id)
    };
  });
  check('все кнопки плавающей панели с иконками', allIcons.ok && allIcons.empty.length === 0, allIcons);

  const planTitle = await page.evaluate(() => {
    nav('planner');
    const h = Array.from(document.querySelectorAll('h2')).map(x => x.textContent.trim());
    return h.filter(t => /планиро/i.test(t));
  });
  check('заголовки без повреждённых слов', planTitle.length > 0 && planTitle.every(t => /планирование/i.test(t) && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(t)), planTitle);

  /* ---------- 2. стартовый баланс и прошлые месяцы ---------- */
  const seeded = await page.evaluate(async () => {
    const ym = todayStr().slice(0, 7);
    S.accounts = [{ id: 'a_card', name: 'Карта', type: 'card', balance0: 50000, archived: false }];
    delete S.accounts[0].balance0From;
    S.transactions = [];
    S.recurring = [];
    S.credits = [];
    save();
    ww59Migrate();
    await new Promise(r => setTimeout(r, 200));
    return { from: S.accounts[0].balance0From, ym };
  });
  check('для старого кошелька сумма привязана к текущему месяцу', seeded.from === seeded.ym + '-01', seeded);

  const byMonth = await page.evaluate(() => {
    const cur = todayStr().slice(0, 7);
    const prev = (function (ym, n) { const p = ym.split('-').map(Number); const d = new Date(p[0], p[1] - 1 + n, 1); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0'); })(cur, -1);
    const prev2 = (function (ym, n) { const p = ym.split('-').map(Number); const d = new Date(p[0], p[1] - 1 + n, 1); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0'); })(cur, -2);
    const last = function (ym) { const p = ym.split('-').map(Number); return new Date(p[0], p[1], 0).toISOString().slice(0, 10); };
    return {
      prev2: accBalanceAsOf('a_card', last(prev2)),
      prev: accBalanceAsOf('a_card', last(prev)),
      cur: accBalanceAsOf('a_card', todayStr()),
      now: accBalance('a_card')
    };
  });
  check('в прошлых месяцах на счетах 0', byMonth.prev === 0 && byMonth.prev2 === 0, byMonth);
  check('в текущем месяце сумма на месте', byMonth.cur === 50000 && byMonth.now === 50000, byMonth);

  /* шапка «Свободные деньги» по месяцам */
  const hero = await page.evaluate(async () => {
    const shift = function (ym, n) { const p = ym.split('-').map(Number); const d = new Date(p[0], p[1] - 1 + n, 1); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0'); };
    const cur = todayStr().slice(0, 7);
    const res = {};
    ww26SetPeriod({ type: 'month', anchor: shift(cur, -1) + '-01' });
    nav('dashboard');
    await new Promise(r => setTimeout(r, 500));
    res.prevTotal = ww318Free().total;
    res.prevText = (document.querySelector('#ww318-hero .hside .sv') || {}).textContent;
    ww26SetPeriod({ type: 'month', anchor: cur + '-01' });
    nav('dashboard');
    await new Promise(r => setTimeout(r, 500));
    res.curTotal = ww318Free().total;
    return res;
  });
  check('в шапке дашборда за прошлый месяц счета пусты', hero.prevTotal === 0 && /0/.test(String(hero.prevText || '')), hero);
  check('за текущий месяц сумма сохранилась', hero.curTotal === 50000, hero);

  /* операции прошлых месяцев по-прежнему считаются */
  const withTx = await page.evaluate(() => {
    const shift = function (ym, n) { const p = ym.split('-').map(Number); const d = new Date(p[0], p[1] - 1 + n, 1); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0'); };
    const prev = shift(todayStr().slice(0, 7), -1);
    S.transactions.push({ id: 'tx1', date: prev + '-10', type: 'income', amount: 1000, accountId: 'a_card', categoryId: 'c_salary', note: 'Тест', tags: [] });
    save();
    const last = (function (ym) { const p = ym.split('-').map(Number); return new Date(p[0], p[1], 0).toISOString().slice(0, 10); })(prev);
    return { prev: accBalanceAsOf('a_card', last), cur: accBalanceAsOf('a_card', todayStr()) };
  });
  check('реальные операции прошлого месяца учитываются', withTx.prev === 1000 && withTx.cur === 51000, withTx);

  /* новый кошелёк сразу помечен датой */
  const created = await page.evaluate(async () => {
    S.transactions = [];
    save();
    ww29Add('acc');
    await new Promise(r => setTimeout(r, 300));
    document.getElementById('ww29-name').value = 'Вклад';
    document.getElementById('ww29-bal').value = '7000';
    ww29Save('acc');
    await new Promise(r => setTimeout(r, 400));
    const a = S.accounts.find(x => x.name === 'Вклад');
    const shift = function (ym, n) { const p = ym.split('-').map(Number); const d = new Date(p[0], p[1] - 1 + n, 1); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0'); };
    const prev = shift(todayStr().slice(0, 7), -1);
    const last = (function (ym) { const p = ym.split('-').map(Number); return new Date(p[0], p[1], 0).toISOString().slice(0, 10); })(prev);
    return { from: a && a.from === undefined ? a.balance0From : (a || {}).balance0From, prev: accBalanceAsOf(a.id, last), cur: accBalanceAsOf(a.id, todayStr()), today: todayStr() };
  });
  check('новый кошелёк не влияет на прошлые месяцы', created.from === created.today && created.prev === 0 && created.cur === 7000, created);

  /* редактирование суммы кошелька по-прежнему действует с сегодня */
  const edited = await page.evaluate(async () => {
    const p = ww26EditAccBalance('a_card');
    await new Promise(r => setTimeout(r, 350));
    const inp = document.querySelector('.dlg-ov.open input, .dlg input');
    if (inp) { inp.value = '60000'; inp.dispatchEvent(new Event('input', { bubbles: true })); }
    const ok = Array.from(document.querySelectorAll('.dlg-ov.open button, .dlg button')).find(b => /Сохранить/.test(b.textContent || ''));
    if (ok) ok.click();
    await p;
    await new Promise(r => setTimeout(r, 300));
    const shift = function (ym, n) { const q = ym.split('-').map(Number); const d = new Date(q[0], q[1] - 1 + n, 1); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0'); };
    const prev = shift(todayStr().slice(0, 7), -1);
    const last = (function (ym) { const q = ym.split('-').map(Number); return new Date(q[0], q[1], 0).toISOString().slice(0, 10); })(prev);
    return { now: accBalance('a_card'), prev: accBalanceAsOf('a_card', last) };
  });
  check('изменение суммы не переписывает прошлые месяцы', edited.now === 60000 && edited.prev === 0, edited);

  console.log('\nERRORS', JSON.stringify(errors));
  if (errors.length) fails.push('ошибки в консоли');
  await browser.close();
  console.log(fails.length ? '\nПРОВАЛЫ: ' + JSON.stringify(fails) : '\nВсе проверки прошли');
  process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
