const { chromium } = require('playwright');
const FILE = process.env.WW_APP || 'file://' + require('path').resolve(__dirname, '../index.html');
const SESSION = { access_token: 'x.y.z', refresh_token: 'r', expires_at: Date.now() + 3600e3, user_id: '00000000-0000-4000-8000-000000000001', email: 'sw@test.local' };
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true, deviceScaleFactor: 2 });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text())) errors.push('CONSOLE: ' + m.text()); });

  await page.goto(FILE);
  await page.evaluate(s => localStorage.setItem('ww_session_v2', JSON.stringify(s)), SESSION);
  await page.goto(FILE);
  await page.waitForTimeout(1800);
  check('версия приложения задана', /^\d+\.\d+$/.test(await page.evaluate(() => WW_VERSION)));

  // демо-данные: один счёт, одна категория расхода с двумя операциями
  const ids = await page.evaluate(() => {
    const a = S.accounts.filter(x => !x.archived)[0];
    const c = S.categories.filter(x => x.type === 'expense')[0];
    S.transactions = [
      { id: uid(), date: todayStr(), type: 'expense', amount: 300, accountId: a.id, categoryId: c.id, tags: [], createdAt: Date.now() },
      { id: uid(), date: todayStr(), type: 'expense', amount: 200, accountId: a.id, categoryId: c.id, tags: [], createdAt: Date.now() }
    ];
    save(); nav('dashboard'); renderCoins();
    return { acc: a.id, accName: a.name, cat: c.id, catName: c.name };
  });
  await page.waitForTimeout(600);

  // ---------- 1. минус в кошельке ----------
  console.log('\n1. Отрицательная сумма в кошельке');
  await page.evaluate(id => { ww26EditAccBalance(id); }, ids.acc);
  await page.waitForTimeout(400);
  const dlg = await page.evaluate(() => {
    const i = document.getElementById('ww-dlg-in');
    return { open: !!document.querySelector('.dlg-ov.open'), type: i && i.type, inputmode: i && i.getAttribute('inputmode'), signBtn: !!document.getElementById('ww55-sign') };
  });
  check('диалог суммы открыт, поле текстовое (минус доступен на iOS)', dlg.open && dlg.type === 'text' && dlg.inputmode === 'text', dlg);
  check('есть кнопка «± сменить знак»', dlg.signBtn);
  // кнопка ± меняет знак
  await page.evaluate(() => { document.getElementById('ww-dlg-in').value = '1500'; document.querySelector('#ww55-sign button').click(); });
  check('«±» переворачивает знак', await page.evaluate(() => document.getElementById('ww-dlg-in').value) === '-1500');
  // вводим с пробелами, запятой и типографским минусом
  await page.evaluate(() => { document.getElementById('ww-dlg-in').value = '\u22124 200,50'; document.getElementById('ww-dlg-ok').click(); });
  await page.waitForTimeout(600);
  const bal = await page.evaluate(id => ({ bal: accBalance(id), dlgClosed: !document.querySelector('.dlg-ov.open') }), ids.acc);
  check('баланс стал отрицательным (пробелы/запятая/− разобраны)', Math.abs(bal.bal + 4200.5) < 0.01 && bal.dlgClosed, bal);
  const coinNeg = await page.evaluate(id => {
    const c = document.querySelector('.coin.acc[data-acc="' + id + '"] .camt');
    return { text: c && c.textContent, neg: c && c.classList.contains('neg'), color: c && getComputedStyle(c).color };
  }, ids.acc);
  check('минус на кошельке подсвечен красным', coinNeg.neg === true && /-|\u2212/.test(coinNeg.text || ''), coinNeg);

  // отрицательный начальный баланс нового счёта
  await page.evaluate(() => { ww29Add('acc'); });
  await page.waitForTimeout(300);
  const addDlg = await page.evaluate(() => { const i = document.getElementById('ww29-bal'); return { type: i && i.type, im: i && i.getAttribute('inputmode') }; });
  check('поле начального баланса принимает минус', addDlg.type === 'text' && addDlg.im === 'text', addDlg);
  await page.evaluate(() => { document.getElementById('ww29-name').value = 'Кредитка'; document.getElementById('ww29-bal').value = '-12 000,25'; ww29Save('acc'); });
  await page.waitForTimeout(500);
  const newAcc = await page.evaluate(() => { const a = S.accounts.find(x => x.name === 'Кредитка'); return a ? { b: a.balance0, bal: accBalance(a.id) } : null; });
  check('новый счёт создан с отрицательным балансом', newAcc && Math.abs(newAcc.bal + 12000.25) < 0.01, newAcc);

  // ---------- 2. редактирование расхода ----------
  console.log('\n2. Правка суммы расхода на дашборде');
  const hasBtn = await page.evaluate(id => !!document.querySelector('.coin.cat[data-cat="' + id + '"] .ww55-exp-btn'), ids.cat);
  check('на монете расхода есть кнопка ⋮', hasBtn);
  check('сумма расхода за период = 500', await page.evaluate(id => ww55ExpTotal(id), ids.cat) === 500);
  await page.evaluate(id => document.querySelector('.coin.cat[data-cat="' + id + '"] .ww55-exp-btn').click(), ids.cat);
  await page.waitForTimeout(300);
  const menu = await page.evaluate(() => { const m = document.getElementById('ww55-exp-menu'); return m ? [...m.querySelectorAll('button')].map(b => b.textContent.trim()) : null; });
  check('меню содержит правку суммы и переименование', menu && menu.length === 2, menu);
  // увеличение: 500 -> 800 (должна добавиться операция на 300)
  await page.evaluate(id => { ww55EditExpense(id); }, ids.cat);
  await page.waitForTimeout(350);
  await page.evaluate(() => { document.getElementById('ww-dlg-in').value = '800'; document.getElementById('ww-dlg-ok').click(); });
  await page.waitForTimeout(500);
  let st = await page.evaluate(id => ({ total: ww55ExpTotal(id), n: S.transactions.filter(t => t.categoryId === id).length }), ids.cat);
  check('увеличение суммы → 800 дополнительной операцией', st.total === 800 && st.n === 3, st);
  // уменьшение: 800 -> 250
  await page.evaluate(id => { ww55EditExpense(id); }, ids.cat);
  await page.waitForTimeout(350);
  await page.evaluate(() => { document.getElementById('ww-dlg-in').value = '250'; document.getElementById('ww-dlg-ok').click(); });
  await page.waitForTimeout(500);
  st = await page.evaluate(id => ({ total: ww55ExpTotal(id), amounts: S.transactions.filter(t => t.categoryId === id).map(t => t.amount) }), ids.cat);
  check('уменьшение суммы → 250 без отрицательных расходов', st.total === 250 && st.amounts.every(a => a > 0), st);
  // отрицательный расход запрещён
  await page.evaluate(id => { ww55EditExpense(id); }, ids.cat);
  await page.waitForTimeout(350);
  await page.evaluate(() => { document.getElementById('ww-dlg-in').value = '-100'; document.getElementById('ww-dlg-ok').click(); });
  await page.waitForTimeout(300);
  const err = await page.evaluate(() => ({ err: (document.getElementById('ww-dlg-err') || {}).textContent, stillOpen: !!document.querySelector('.dlg-ov.open') }));
  check('отрицательный расход отклоняется', err.stillOpen && /отрицательн/i.test(err.err || ''), err);
  await page.evaluate(() => document.getElementById('ww-dlg-cancel').click());
  await page.waitForTimeout(300);
  check('сумма после отказа не изменилась', await page.evaluate(id => ww55ExpTotal(id), ids.cat) === 250);

  // ---------- 3. скролл уведомлений ----------
  console.log('\n3. Скролл списка уведомлений');
  await page.evaluate(() => {
    // много уведомлений: регулярные платежи на ближайшие дни
    S.notifRead = {};
    S.recurring = [];
    for (let i = 1; i <= 20; i++) {
      const d = new Date(); d.setDate(d.getDate() + (i % 25));
      S.recurring.push({ id: uid(), name: 'Платёж ' + i, amount: 1000 + i, day: d.getDate(), type: 'expense', categoryId: (S.categories[0] || {}).id, accountId: S.accounts[0].id, active: true });
    }
    save();
    ww331OpenNotifs();
  });
  await page.waitForTimeout(700);
  const sc = await page.evaluate(() => {
    const modal = document.getElementById('modal');
    const box = document.getElementById('ww331-notif-scroll');
    const foot = box && box.nextElementSibling;
    const cs = box ? getComputedStyle(box) : null;
    return {
      rows: box ? box.querySelectorAll('.ww331-row').length : 0,
      cls: modal.className,
      boxOverflow: cs && cs.overflow, boxMax: cs && cs.maxHeight,
      nested: box ? box.scrollHeight > box.clientHeight + 2 : null,
      modalScrollable: modal.scrollHeight > modal.clientHeight + 2,
      footSticky: foot ? getComputedStyle(foot).position : null,
      headSticky: getComputedStyle(modal.querySelector('.mhead')).position
    };
  });
  console.log('SCROLL', JSON.stringify(sc));
  check('уведомлений достаточно для скролла', sc.rows >= 10, sc.rows);
  check('вложенный скроллер отключён', sc.boxOverflow === 'visible' && sc.nested === false, sc);
  check('скроллится сама модалка (один слой)', sc.modalScrollable === true);
  check('шапка и кнопки зафиксированы', sc.headSticky === 'sticky' && sc.footSticky === 'sticky', sc);

  // реальный скролл жестом пальца
  const before = await page.evaluate(() => document.getElementById('modal').scrollTop);
  const box = await page.locator('#ww331-notif-scroll').boundingBox();
  await page.mouse.move(box.x + box.width / 2, box.y + 60);
  await page.mouse.wheel(0, 400);
  await page.waitForTimeout(400);
  const after = await page.evaluate(() => document.getElementById('modal').scrollTop);
  check('список действительно прокручивается', after > before + 100, { before, after });

  // отметка «прочитано» не сбрасывает прокрутку (поведение v3.47)
  const pos = await page.evaluate(() => {
    const rows = document.querySelectorAll('#ww331-notif-scroll .ww331-row');
    const row = rows[rows.length - 1];
    const btn = row.querySelector('button[title="Отметить прочитанным"]');
    const st = document.getElementById('modal').scrollTop;
    if (btn) btn.click();
    return { st, after: document.getElementById('modal').scrollTop, marked: !row.classList.contains('ww331-unread') };
  });
  check('отметка прочтения не прокручивает наверх', pos.st === pos.after && pos.marked, pos);

  // класс уведомлений не протекает в другие окна
  await page.evaluate(() => { closeModal(); typeof ww331OpenJournal === 'function' ? ww331OpenJournal() : showModal('<div class="mhead"><h3>Тест</h3></div><p>x</p>'); });
  await page.waitForTimeout(400);
  check('класс уведомлений снят с другого окна', await page.evaluate(() => !document.getElementById('modal').classList.contains('ww55-notif')));
  await page.evaluate(() => closeModal());

  console.log('\nERRORS', JSON.stringify(errors));
  if (errors.length) fails.push('ошибки в консоли');
  await browser.close();
  console.log(fails.length ? '\nПРОВАЛЫ: ' + JSON.stringify(fails) : '\nВсе проверки прошли');
  process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
