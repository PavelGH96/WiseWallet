const path=require("path");
const {chromium}=require("playwright");
const FILE = process.env.WW_APP || 'file://' + require('path').resolve(__dirname, '../index.html');
const SESSION={access_token:"smoke.jwt.token",refresh_token:"smoke.refresh",expires_at:Date.now()+3600e3,user_id:"00000000-0000-4000-8000-000000000001",email:"smoke@example.com"};
(async()=>{
 const browser=await chromium.launch({executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium',args:["--no-sandbox"]});
 const errors=[];
 async function make(viewport,mobile){
  const c=await browser.newContext({viewport,hasTouch:mobile,isMobile:mobile,deviceScaleFactor:mobile?2:1});const p=await c.newPage();
  p.on("pageerror",e=>errors.push("PAGEERROR: "+e.message));p.on("console",m=>{if(m.type()==="error"&&!/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text()))errors.push("CONSOLE: "+m.text())});
  await p.goto(FILE);await p.evaluate(s=>{localStorage.setItem("ww_session_v2",JSON.stringify(s));const st=JSON.parse(localStorage.getItem("ww_state_v1")||"null");if(st&&st.settings){st.settings.setOpen={"Тема":true,"Синхронизация Supabase":true,"📄 Финансовый отчёт (PDF)":true};localStorage.setItem("ww_state_v1",JSON.stringify(st));}localStorage.removeItem("ww51_settings_collapsed_v1");},SESSION);
  await p.reload();await p.waitForTimeout(1700);await p.evaluate(()=>nav("settings"));await p.waitForTimeout(1300);return{c,p};
 }
 const {c,p}=await make({width:1280,height:950},false);
 const snap=()=>p.evaluate(()=>{const cards=[].filter.call(document.querySelectorAll("#page-settings .card"),x=>getComputedStyle(x).display!=="none");return{count:cards.length,titles:cards.map(x=>(x.querySelector("h2")||{}).textContent.replace("⌄","").trim()),collapsed:cards.filter(x=>x.classList.contains("collapsed")).length,allCollapsed:cards.every(x=>x.classList.contains("collapsed")),allAccordion:cards.every(x=>x.dataset.acc==="1"&&x.querySelector(":scope > .set-body")&&x.querySelector("h2.set-h")),open:cards.filter(x=>!x.classList.contains("collapsed")).map(x=>(x.querySelector("h2")||{}).textContent.trim()),report:{exists:!!document.getElementById("ww43-card"),collapsed:document.getElementById("ww43-card")?.classList.contains("collapsed"),bodyDisplay:document.querySelector("#ww43-card>.set-body")?getComputedStyle(document.querySelector("#ww43-card>.set-body")).display:null,aria:document.querySelector("#ww43-card h2")?.getAttribute("aria-expanded")},journal:{exists:!!document.getElementById("ww331-card"),collapsed:document.getElementById("ww331-card")?.classList.contains("collapsed"),bodyDisplay:document.querySelector("#ww331-card>.set-body")?getComputedStyle(document.querySelector("#ww331-card>.set-body")).display:null,aria:document.querySelector("#ww331-card h2")?.getAttribute("aria-expanded")},flag:localStorage.getItem("ww51_settings_collapsed_v1"),saved:S.settings.setOpen||{},version:WW_VERSION};});
 console.log("INITIAL",JSON.stringify(await snap(),null,1));
 await p.screenshot({path:"/data/a351-settings-all-collapsed.png",fullPage:true});

 // Отчёт раскрывается и после полного renderSettings остаётся раскрытым.
 await p.locator("#ww43-card h2").click();await p.waitForTimeout(250);
 console.log("REPORT_OPEN",JSON.stringify(await snap()));
 await p.evaluate(()=>renderSettings());await p.waitForTimeout(1100);
 console.log("REPORT_AFTER_RENDER",JSON.stringify(await snap()));
 // Закрываем обратно.
 await p.locator("#ww43-card h2").click();await p.waitForTimeout(250);

 // Журнал тоже раскрывается, получает set-body и закрывается обратно.
 await p.locator("#ww331-card h2").click();await p.waitForTimeout(250);
 console.log("JOURNAL_OPEN",JSON.stringify(await snap()));
 await p.locator("#ww331-card h2").press("Enter");await p.waitForTimeout(250);
 console.log("ALL_CLOSED_AGAIN",JSON.stringify(await snap()));

 // Повторный вход: флаг уже есть, сохранённое закрытое состояние сохраняется.
 await p.reload();await p.waitForTimeout(1600);await p.evaluate(()=>nav("settings"));await p.waitForTimeout(1200);
 console.log("RELOAD",JSON.stringify(await snap()));
 await c.close();

 const m=await make({width:390,height:844},true);await m.p.screenshot({path:"/data/a351-settings-mobile.png",fullPage:true});console.log("MOBILE",JSON.stringify(await m.p.evaluate(()=>({visible:[].filter.call(document.querySelectorAll("#page-settings .card"),x=>getComputedStyle(x).display!=="none").length,open:[].filter.call(document.querySelectorAll("#page-settings .card"),x=>getComputedStyle(x).display!=="none"&&!x.classList.contains("collapsed")).length,report:document.getElementById("ww43-card").classList.contains("collapsed"),journal:document.getElementById("ww331-card").classList.contains("collapsed"),scrollW:document.documentElement.scrollWidth,clientW:document.documentElement.clientWidth}))));await m.c.close();
 console.log("ERRORS",JSON.stringify(errors));await browser.close();
})();
