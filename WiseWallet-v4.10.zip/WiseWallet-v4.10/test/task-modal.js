/* Тесты v3.60: тип задачи, время, заметка, повтор, экспорт в календарь iPhone */
const { chromium } = require('playwright');
const FILE = process.env.WW_APP || 'file://' + require('path').resolve(__dirname, '../index.html');
const fails = [];
function check(name, cond, extra) {
  console.log((cond ? '  ok   ' : '  FAIL ') + name + (extra !== undefined ? '  -> ' + JSON.stringify(extra) : ''));
  if (!cond) fails.push(name);
}

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 }, acceptDownloads: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text())) errors.push('CONSOLE: ' + m.text()); });

  await page.goto(FILE);
  await page.evaluate(() => localStorage.setItem('ww_session_v2', JSON.stringify({ access_token: 'x.y.z', refresh_token: 'r', expires_at: Date.now() + 3600e3, user_id: '00000000-0000-4000-8000-000000000001', email: 't360@test.local' })));
  await page.goto(FILE);
  await page.waitForTimeout(1800);

  check('версия задана', /^\d+\.\d+$/.test(String(await page.evaluate(() => WW_VERSION))), await page.evaluate(() => WW_VERSION));
  check('нет битых символов', !(await page.evaluate(() => document.documentElement.innerHTML.indexOf('\uFFFD') !== -1)));

  /* ---------- форма новой задачи ---------- */
  const form = await page.evaluate(async () => {
    nav('planner');
    await new Promise(r => setTimeout(r, 300));
    openTaskModal('', 'today');
    await new Promise(r => setTimeout(r, 400));
    const g = id => document.getElementById(id);
    const labelFor = id => { const l = document.querySelector('label[for="' + id + '"]'); return l ? l.textContent.trim() : null; };
    return {
      type: !!g('ww60-type'),
      typeOpts: g('ww60-type') ? Array.from(g('ww60-type').options).map(o => o.textContent.trim()) : [],
      text: !!g('tk-text'),
      textLabel: labelFor('tk-text'),
      date: !!g('tk-date'),
      time: !!g('ww60-time'),
      timeType: g('ww60-time') ? g('ww60-time').type : null,
      timeLabel: labelFor('ww60-time'),
      rep: !!g('ww60-rep'),
      repOpts: g('ww60-rep') ? Array.from(g('ww60-rep').options).map(o => o.value) : [],
      note: !!g('ww60-note'),
      noteTag: g('ww60-note') ? g('ww60-note').tagName : null,
      noteLabel: labelFor('ww60-note'),
      who: !!g('tk-who'),
      prio: !!g('tk-prio')
    };
  });
  check('в окне есть выбор типа Задача/Звонок/Встреча', form.type && form.typeOpts.join(',') === 'Задача,Звонок,Встреча', form.typeOpts);
  check('поле «Что нужно сделать» сохранено', form.text && /Что нужно сделать/.test(form.textLabel || ''), form.textLabel);
  check('есть выбор времени рядом с датой', form.date && form.time && form.timeType === 'time' && /Время/.test(form.timeLabel || ''), { time: form.time, t: form.timeType, l: form.timeLabel });
  check('есть выбор повтора', form.rep && form.repOpts.indexOf('weekly') !== -1 && form.repOpts.indexOf('monthly') !== -1, form.repOpts);
  check('есть поле заметки (многострочное)', form.note && form.noteTag === 'TEXTAREA' && /Заметка/.test(form.noteLabel || ''), { tag: form.noteTag, l: form.noteLabel });
  check('Кто и Приоритет на месте', form.who && form.prio);

  /* ---------- сохранение новых полей ---------- */
  const saved = await page.evaluate(async () => {
    S.tasks = [];
    save();
    openTaskModal('', 'today');
    await new Promise(r => setTimeout(r, 350));
    document.getElementById('ww60-type').value = 'call';
    document.getElementById('tk-text').value = 'Позвонить в банк';
    document.getElementById('tk-date').value = todayStr();
    document.getElementById('ww60-time').value = '14:30';
    document.getElementById('ww60-rep').value = 'weekly';
    document.getElementById('ww60-note').value = 'Уточнить ставку и срок кредита';
    saveTask('');
    await new Promise(r => setTimeout(r, 450));
    const t = S.tasks[0] || {};
    return { n: S.tasks.length, ttype: t.ttype, time: t.time, repeat: t.repeat, note: t.note, text: t.text, date: t.date, id: t.id, modalOpen: !!document.querySelector('.modal.open, #overlay.open') };
  });
  check('задача сохранила тип, время, повтор и заметку',
    saved.n === 1 && saved.ttype === 'call' && saved.time === '14:30' && saved.repeat === 'weekly' && /ставку/i.test(saved.note || '') && saved.text === 'Позвонить в банк', saved);

  /* ---------- карточка показывает новые данные ---------- */
  const card = await page.evaluate(() => {
    renderPlanner();
    const c = document.querySelector('.task-card');
    if (!c) return { found: false };
    const meta = c.querySelector('.task-meta');
    return {
      found: true,
      metaText: meta ? meta.textContent.replace(/\s+/g, ' ').trim() : '',
      typeChip: !!c.querySelector('.ww60-t-call'),
      timeChip: !!c.querySelector('.ww60-time-chip'),
      repChip: !!c.querySelector('.ww60-rep-chip'),
      noteChip: !!c.querySelector('.ww60-note-chip'),
      svgs: c.querySelectorAll('.task-meta svg').length,
      noTofu: c.textContent.indexOf('\uFFFD') === -1
    };
  });
  check('на карточке видны тип «Звонок», время и повтор',
    card.found && card.typeChip && card.timeChip && card.repChip && card.noteChip && /Звонок/.test(card.metaText) && /14:30/.test(card.metaText) && card.svgs >= 3 && card.noTofu, card);

  /* ---------- редактирование: поля подставляются ---------- */
  const edit = await page.evaluate(async () => {
    const id = S.tasks[0].id;
    openTaskModal(id);
    await new Promise(r => setTimeout(r, 400));
    const g = i => document.getElementById(i);
    const pre = { type: g('ww60-type').value, time: g('ww60-time').value, rep: g('ww60-rep').value, note: g('ww60-note').value, text: g('tk-text').value, ics: !!document.querySelector('button[onclick*="ww60TaskIcs"]') };
    g('ww60-type').value = 'meeting';
    g('ww60-time').value = '09:05';
    g('ww60-rep').value = 'monthly';
    g('ww60-note').value = 'Переговоры в офисе';
    saveTask(id);
    await new Promise(r => setTimeout(r, 400));
    const t = S.tasks.find(x => x.id === id);
    return { pre, post: { ttype: t.ttype, time: t.time, repeat: t.repeat, note: t.note } };
  });
  check('при редактировании поля заполнены текущими значениями',
    edit.pre.type === 'call' && edit.pre.time === '14:30' && edit.pre.rep === 'weekly' && /ставку/i.test(edit.pre.note) && edit.pre.ics, edit.pre);
  check('изменения сохраняются',
    edit.post.ttype === 'meeting' && edit.post.time === '09:05' && edit.post.repeat === 'monthly' && /офисе/.test(edit.post.note), edit.post);

  /* ---------- повтор: при выполнении создаётся следующая ---------- */
  const nextd = await page.evaluate(() => ({
    daily: ww60NextDate('2026-08-20', 'daily'),
    weekly: ww60NextDate('2026-08-20', 'weekly'),
    biweekly: ww60NextDate('2026-08-20', 'biweekly'),
    monthly: ww60NextDate('2026-08-31', 'monthly'),
    yearly: ww60NextDate('2026-08-20', 'yearly'),
    weekdays: ww60NextDate('2026-08-21', 'weekdays'),
    none: ww60NextDate('2026-08-20', 'none')
  }));
  check('даты повтора считаются верно',
    nextd.daily === '2026-08-21' && nextd.weekly === '2026-08-27' && nextd.biweekly === '2026-09-03' &&
    nextd.monthly === '2026-09-30' && nextd.yearly === '2027-08-20' && nextd.weekdays === '2026-08-24' && nextd.none === null, nextd);

  const rep = await page.evaluate(async () => {
    S.tasks = [{ id: 'rt1', text: 'Оплатить коммуналку', who: 'me', prio: 'mid', date: '2026-08-20', ttype: 'task', time: '10:00', repeat: 'monthly', note: 'По счёту', done: false, created: Date.now() }];
    save();
    renderPlanner();
    toggleTask('rt1');
    await new Promise(r => setTimeout(r, 500));
    const nw = S.tasks.filter(t => t.id !== 'rt1');
    return { n: S.tasks.length, doneOld: !!S.tasks.find(t => t.id === 'rt1').done, next: nw[0] ? { date: nw[0].date, time: nw[0].time, repeat: nw[0].repeat, note: nw[0].note, ttype: nw[0].ttype, done: nw[0].done, text: nw[0].text } : null };
  });
  check('повторяющаяся задача создаёт следующую копию',
    rep.n === 2 && rep.doneOld && rep.next && rep.next.date === '2026-09-20' && rep.next.time === '10:00' && rep.next.repeat === 'monthly' && rep.next.done === false && /счёту/.test(rep.next.note), rep);

  const noRep = await page.evaluate(async () => {
    S.tasks = [{ id: 'nr1', text: 'Разовая', who: 'me', prio: 'mid', date: '2026-08-20', ttype: 'task', time: '', repeat: 'none', note: '', done: false, created: Date.now() }];
    save(); renderPlanner();
    toggleTask('nr1');
    await new Promise(r => setTimeout(r, 400));
    return S.tasks.length;
  });
  check('без повтора копия не создаётся', noRep === 1, noRep);

  /* ---------- экспорт в календарь iPhone ---------- */
  const ics = await page.evaluate(() => {
    S.tasks = [
      { id: 'i1', text: 'Звонок клиенту', who: 'me', prio: 'high', date: '2026-08-21', ttype: 'call', time: '14:30', repeat: 'weekly', note: 'Детали; с запятой, и текст', done: false, created: Date.now() },
      { id: 'i2', text: 'Задача на день', who: 'me', prio: 'mid', date: '2026-08-22', ttype: 'task', time: '', repeat: 'none', note: '', done: false, created: Date.now() },
      { id: 'i3', text: 'Выполненная', who: 'me', prio: 'mid', date: '2026-08-22', ttype: 'task', time: '', repeat: 'none', note: '', done: true, created: Date.now() }
    ];
    save();
    const text = ww60BuildIcs();
    return {
      events: (text.match(/BEGIN:VEVENT/g) || []).length,
      timed: /DTSTART:20260821T143000/.test(text),
      allday: /DTSTART;VALUE=DATE:20260822/.test(text),
      rrule: /RRULE:FREQ=WEEKLY/.test(text),
      alarm: (text.match(/BEGIN:VALARM/g) || []).length,
      summary: /SUMMARY:Звонок: Звонок клиенту/.test(text),
      escaped: /Детали\\;/.test(text) && /запятой\\,/.test(text),
      crlf: text.indexOf('\r\n') !== -1,
      wrap: /^BEGIN:VCALENDAR/.test(text) && /END:VCALENDAR$/.test(text)
    };
  });
  check('.ics собирается только из активных задач с датой', ics.events === 2, ics);
  check('в .ics есть точное время, весь день, повтор, напоминания',
    ics.timed && ics.allday && ics.rrule && ics.alarm === 2 && ics.summary && ics.escaped && ics.crlf && ics.wrap, ics);

  const dl = await (async () => {
    const p = page.waitForEvent('download', { timeout: 8000 }).catch(() => null);
    await page.evaluate(() => ww60ExportTasksIcs());
    const d = await p;
    if (!d) return null;
    let body = '';
    try {
      const fsx = require('fs');
      const path = await d.path();
      if (path) body = fsx.readFileSync(path, 'utf8');
    } catch (e) {}
    return { name: d.suggestedFilename(), head: body.slice(0, 40), events: (body.match(/BEGIN:VEVENT/g) || []).length };
  })();
  check('кнопка экспорта отдаёт файл календаря', !!dl && /BEGIN:VCALENDAR/.test(dl.head) && dl.events >= 1, dl);

  const setBtn = await page.evaluate(async () => {
    nav('settings');
    await new Promise(r => setTimeout(r, 600));
    const b = document.querySelector('#page-settings .ww60-exp');
    return { found: !!b, text: b ? b.textContent.trim() : null };
  });
  check('в настройках есть экспорт задач в календарь', setBtn.found && /\.ics/.test(setBtn.text || ''), setBtn);

  /* ---------- старые задачи без новых полей ---------- */
  const mig = await page.evaluate(async () => {
    S.tasks = [{ id: 'old1', text: 'Старая', who: 'me', prio: 'mid', date: '2026-08-25', done: false, created: Date.now() }];
    save();
    ww60Migrate();
    await new Promise(r => setTimeout(r, 200));
    const t = S.tasks[0];
    nav('planner');
    await new Promise(r => setTimeout(r, 300));
    const c = document.querySelector('.task-card');
    return { ttype: t.ttype, time: t.time, repeat: t.repeat, note: t.note, chip: c ? !!c.querySelector('.ww60-t-task') : false };
  });
  check('старые задачи становятся обычными «Задачами»',
    mig.ttype === 'task' && mig.time === '' && mig.repeat === 'none' && mig.note === '' && mig.chip, mig);

  /* ---------- перезагрузка сохраняет данные ---------- */
  await page.evaluate(async () => {
    S.tasks = [{ id: 'p1', text: 'Встреча с банком', who: 'me', prio: 'high', date: todayStr(), ttype: 'meeting', time: '16:45', repeat: 'weekly', note: 'Взять документы', done: false, created: Date.now() }];
    save();
  });
  await page.goto('about:blank');
  await page.goto(FILE);
  await page.waitForTimeout(1600);
  const after = await page.evaluate(async () => {
    nav('planner');
    await new Promise(r => setTimeout(r, 400));
    const t = S.tasks.find(x => x.id === 'p1') || {};
    const c = document.querySelector('.task-card');
    return { ttype: t.ttype, time: t.time, repeat: t.repeat, note: t.note, meta: c ? c.querySelector('.task-meta').textContent.replace(/\s+/g, ' ').trim() : null };
  });
  check('после перезагрузки всё на месте',
    after.ttype === 'meeting' && after.time === '16:45' && after.repeat === 'weekly' && /документы/.test(after.note || '') && /Встреча/.test(after.meta || '') && /16:45/.test(after.meta || ''), after);

  console.log('\nERRORS', JSON.stringify(errors));
  if (errors.length) fails.push('ошибки в консоли');
  await browser.close();
  console.log(fails.length ? '\nПРОВАЛЫ: ' + JSON.stringify(fails) : '\nВсе проверки прошли');
  process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
