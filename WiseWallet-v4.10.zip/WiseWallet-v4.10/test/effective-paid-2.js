/* Тесты v3.72: продолжение проверки задвоения «оплачено».
   Первая партия мест (дашборд, «К оплате») закрыта в test/effective-paid.js.
   Здесь — второй проход: страница «Расходы и доходы», PDF-отчёт, Календарь,
   а также самое важное — что частичное покрытие больше не даёт переплатить. */
const { chromium } = require('playwright');
const path = require('path');
const FILE = 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const p = await (await b.newContext({ viewport: { width: 1440, height: 900 } })).newPage();
  const errors = [];
  p.on('pageerror', e => errors.push(e.message));
  p.on('console', m => { if (m.type() === 'error' && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text())) errors.push(m.text()); });
  await p.goto(FILE);
  await p.waitForTimeout(1600);
  await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
  await p.evaluate(() => { window.print = function () {}; });

  const setup = async () => p.evaluate(() => {
    const cat = S.categories.find(c => c.type === 'expense').id;
    const t = todayStr();
    S.recurring = [{ id: 'r1', name: 'Бытовые расходы', type: 'expense', amount: 50000, categoryId: cat, day: +t.slice(8, 10) }];
    S.credits = [{ id: 'c1', name: 'Тестовый кредит', type: 'П', lender: '', initial: 0, balance: 100000, balanceFull: 100000, payment: 15000, rate: 0, payDay: +t.slice(8, 10), start: '2025-01-01', end: '', status: 'active' }];
    S.transactions = [
      { id: 'e1', date: t, type: 'expense', amount: 50000, accountId: S.accounts[0].id, categoryId: cat, note: '', tags: [], createdAt: 1 },
      { id: 'ct1', date: t, type: 'expense', amount: 15000, accountId: S.accounts[0].id, categoryId: 'c_credit', note: 'Тестовый кредит', tags: [], createdAt: 2 },
    ];
    S.posted = {}; S.ww30Tx = {}; S.ww30Cr = {};
    save();
    return cat;
  });

  // === 1. Переключатели на странице «Расходы и доходы» (список) ===
  await setup();
  await p.evaluate(() => nav('credits'));
  await p.waitForTimeout(700);
  const listSwitches = await p.evaluate(() => ({
    recur: document.querySelector('[data-sid="r1"] .ww30-sw')?.classList.contains('on'),
    credit: document.querySelector('[data-sid="c1"] .ww30-sw')?.classList.contains('on'),
  }));
  check('переключатель регулярного платежа в списке видит покрытие', listSwitches.recur === true, listSwitches);
  check('переключатель кредита в списке видит покрытие', listSwitches.credit === true, listSwitches);

  // === 2. Карточный вид кредитов ===
  await p.evaluate(() => { try { setViewMode('credits', 'cards'); } catch (e) {} });
  await p.waitForTimeout(600);
  const cardSwitch = await p.evaluate(() => document.querySelector('.credit-card[data-sid="c1"] .ww30-sw')?.classList.contains('on'));
  check('переключатель кредита в карточном виде видит покрытие', cardSwitch === true, cardSwitch);

  // === 3. Календарь: раскраска ===
  await p.evaluate(() => nav('calendar'));
  await p.waitForTimeout(700);
  const calClasses = await p.evaluate(() => [...document.querySelectorAll('.cal-ev')].map(e => e.className));
  const hasPaidExp = calClasses.some(c => /\bexp\b/.test(c) && /\bpaid\b/.test(c));
  const hasPaidPay = calClasses.some(c => /\bpay\b/.test(c) && /\bpaid\b/.test(c));
  check('регулярный платёж в календаре покрашен как оплаченный', hasPaidExp, calClasses);
  check('кредит в календаре покрашен как оплаченный', hasPaidPay, calClasses);

  // === 4. PDF-отчёт: «ещё предстоит оплатить» не включает уже покрытое ===
  await setup(); // сумма покрыта полностью, дата платежа = сегодня (в диапазоне периода)
  await p.evaluate(() => { try { ww43ToPdf(); } catch (e) {} });
  await p.waitForTimeout(600);
  const dueText = await p.evaluate(() => {
    const el = document.querySelector('#ww43-print');
    return el ? el.innerText : '';
  });
  check('PDF не показывает «Тестовый кредит» как ещё предстоящий (уже оплачен)', /оплачивать больше нечего/.test(dueText), (dueText.match(/Ещё предстоит[\s\S]{0,60}/) || [''])[0]);
  check('«Итого к оплате» равно нулю (оба пункта уже покрыты)', /Итого к оплате\s*0\s*₽/.test(dueText.replace(/\u00a0/g,' ')));

  // === 5. ГЛАВНОЕ: частичное покрытие не даёт переплатить ===
  await p.evaluate(() => {
    const cat = S.categories.find(c => c.type === 'expense').id;
    const t = todayStr();
    S.recurring = [{ id: 'r1', name: 'Бытовые расходы', type: 'expense', amount: 50000, categoryId: cat, day: 1 }];
    S.credits = [];
    // покрыто только частично: 9700 из 50000
    S.transactions = [{ id: 'e1', date: t, type: 'expense', amount: 9700, accountId: S.accounts[0].id, categoryId: cat, note: '', tags: [], createdAt: 1 }];
    S.posted = {}; S.ww30Tx = {}; S.ww30Cr = {};
    save(); nav('credits');
  });
  await p.waitForTimeout(700);
  await p.evaluate(() => document.querySelector('[data-sid="r1"] .ww30-sw').click());
  await p.waitForTimeout(500);
  const promptDefault = await p.evaluate(() => document.getElementById('ww32-amt')?.value);
  check('окно предлагает доплатить именно остаток (50000-9700=40300), а не всю сумму', promptDefault === '40300', promptDefault);

  await p.evaluate(() => ww32ConfirmPay());
  await p.waitForTimeout(500);
  const totalAfter = await p.evaluate(() => {
    const cat = S.categories.find(c => c.type === 'expense' && c.id === S.recurring[0].categoryId).id;
    return S.transactions.filter(t => t.categoryId === cat).reduce((s, t) => s + t.amount, 0);
  });
  check('итоговая сумма операций равна ровно плану (50000, без переплаты)', totalAfter === 50000, totalAfter);
  const postedNow = await p.evaluate(() => S.posted['r1:' + todayStr().slice(0, 7)]);
  check('S.posted корректно отражает полную сумму (50000)', postedNow === 50000, postedNow);

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));
  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})();
