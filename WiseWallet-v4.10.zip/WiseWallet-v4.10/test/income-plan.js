/* Тесты v3.89: помесячное планирование регулярного дохода во вкладке
   «Доходы» — редактируемая сумма на будущие месяцы, по умолчанию пропуск. */
const { chromium } = require('playwright');
const path = require('path');
const FILE = 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const p = await (await b.newContext({ viewport: { width: 1400, height: 950 } })).newPage();
  const errors = [];
  p.on('pageerror', e => errors.push(e.message));
  p.on('console', m => { if (m.type() === 'error' && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text())) errors.push(m.text()); });
  await p.goto(FILE);
  await p.waitForTimeout(1600);
  await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
  await p.evaluate(() => {
    S.recurring = [{ id: 'r_sal', name: 'Зарплата', type: 'income', amount: 150000, categoryId: S.categories.find(c => c.type === 'income').id, day: 5 }];
    S.recurIncomeAmt = {};
    save(); nav('credits');
  });
  await p.waitForTimeout(500);
  await p.evaluate(() => { const b = [...document.querySelectorAll('[data-tab]')].find(x => x.dataset.tab === 'inc'); if (b) b.click(); });
  await p.waitForTimeout(500);

  // === Текущий месяц: сумма правится в строке и НЕ трогает шаблон (v3.98) ===
  // Раньше здесь проверялось обратное — что поля правки нет. Сумма регулярного
  // дохода нестабильна (премии, подработки), поэтому теперь её можно задать
  // отдельно на любой месяц, включая текущий; шаблон при этом не меняется.
  const cur = await p.evaluate(() => {
    const inp = document.querySelector('.ww89-plan');
    return { input: !!inp, ym: inp && inp.dataset.ym, value: inp && inp.value, tpl: S.recurring.find(r => r.id === 'r_sal').amount };
  });
  check('текущий месяц: сумма правится в строке, поле заполнено суммой шаблона',
    /* v4.10: сумма показывается с разделителями разрядов («150 000»),
       поэтому перед сравнением их снимаем. */
    cur.input === true && cur.ym === new Date().toISOString().slice(0, 7)
      && +String(cur.value).replace(/[\u202F\u00A0\s]/g, '') === 150000, cur);

  const curEdit = await p.evaluate(() => {
    const inp = document.querySelector('.ww89-plan');
    inp.value = '250000';
    inp.dispatchEvent(new Event('change', { bubbles: true }));
    return null;
  });
  await p.waitForTimeout(500);
  const curAfter = await p.evaluate(() => ({
    tpl: S.recurring.find(r => r.id === 'r_sal').amount,
    stored: S.recurIncomeAmt[Object.keys(S.recurIncomeAmt)[0]],
    keys: Object.keys(S.recurIncomeAmt),
  }));
  check('правка в текущем месяце не меняет шаблон (не разъезжается по всем месяцам)',
    curAfter.tpl === 150000 && curAfter.stored === 250000 && curAfter.keys.length === 1, curAfter);

  // вернуть исходное состояние для остальных проверок
  await p.evaluate(() => { S.recurIncomeAmt = {}; save(); ww63Tab('inc'); });
  await p.waitForTimeout(400);

  // === Будущий месяц: поле есть, пусто по умолчанию, итог = 0 ===
  await p.evaluate(() => ww26ShiftMonth(1));
  await p.waitForTimeout(500);
  const fut = await p.evaluate(() => {
    const inp = document.querySelector('.ww89-plan');
    return { has: !!inp, empty: inp && inp.value === '', placeholder: inp && inp.placeholder, total: document.getElementById('ww63-recur-total')?.textContent };
  });
  check('будущий месяц: появляется редактируемое поле', fut.has === true, fut);
  check('КЛЮЧЕВОЕ: по умолчанию поле пустое (пропуск, не сумма шаблона)', fut.empty === true, fut);
  check('плейсхолдер — тире, намекает на пропуск', fut.placeholder === '—', fut.placeholder);
  check('итог за месяц = 0, пока ничего не указано', /^\+?0/.test((fut.total || '').replace(/\u00a0/g, ' ').trim()), fut.total);

  const nowYm = await p.evaluate(() => todayStr().slice(0, 7));
  const futureYm = await p.evaluate(() => ww316Ym());
  check('действительно просматриваем будущий месяц', futureYm > nowYm, { nowYm, futureYm });

  const beforeSet = await p.evaluate(ym => monthPlanFull(ym).income, futureYm);
  check('прогноз дохода на этот месяц = 0 без указания', beforeSet === 0, beforeSet);

  // === Ввод суммы сохраняется и попадает в прогноз ===
  await p.evaluate(() => { const i = document.querySelector('.ww89-plan'); i.value = '175000'; i.dispatchEvent(new Event('change', { bubbles: true })); });
  await p.waitForTimeout(400);
  const afterSet = await p.evaluate(ym => ({ stored: S.recurIncomeAmt[`r_sal:${ym}`], total: document.getElementById('ww63-recur-total')?.textContent, plan: monthPlanFull(ym).income }), futureYm);
  check('сумма сохранена под правильный месяц', afterSet.stored === 175000, afterSet);
  check('итог строки обновился', /175.?000/.test((afterSet.total || '').replace(/\u00a0/g, ' ')), afterSet.total);
  check('прогноз «Финансового планирования» теперь учитывает введённую сумму', afterSet.plan === 175000, afterSet.plan);

  // === Очистка поля возвращает пропуск ===
  await p.evaluate(() => { const i = document.querySelector('.ww89-plan'); i.value = ''; i.dispatchEvent(new Event('change', { bubbles: true })); });
  await p.waitForTimeout(400);
  const afterClear = await p.evaluate(ym => ({ stored: Object.prototype.hasOwnProperty.call(S.recurIncomeAmt, `r_sal:${ym}`), plan: monthPlanFull(ym).income }), futureYm);
  check('очистка поля убирает запись целиком (не сохраняет 0)', afterClear.stored === false, afterClear);
  check('прогноз снова 0 после очистки', afterClear.plan === 0, afterClear);

  // === Соседний будущий месяц не затронут введённым значением ===
  await p.evaluate(() => { const i = document.querySelector('.ww89-plan'); i.value = '175000'; i.dispatchEvent(new Event('change', { bubbles: true })); });
  await p.waitForTimeout(400);
  await p.evaluate(() => ww26ShiftMonth(1));
  await p.waitForTimeout(500);
  const nextMonth = await p.evaluate(() => { const inp = document.querySelector('.ww89-plan'); return { empty: inp && inp.value === '' }; });
  check('соседний месяц не унаследовал введённую сумму (у каждого месяца свой план)', nextMonth.empty === true, nextMonth);

  // === Прошлый/текущий месяц: обычный no-arg planIncomeMonth() не задет изменениями ===
  const baseline = await p.evaluate(() => planIncomeMonth());
  check('общий «план дохода/мес» (не по конкретному месяцу) остался прежним', baseline === 150000, baseline);

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));
  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})();
