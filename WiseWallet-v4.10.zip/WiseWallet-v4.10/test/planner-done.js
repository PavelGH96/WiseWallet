/* Тесты v3.58: вкладка «Выполнено» в планировщике */
const { chromium } = require('playwright');
const FILE = process.env.WW_APP || 'file://' + require('path').resolve(__dirname, '../index.html');
const fails = [];
function check(name, cond, extra) {
  console.log((cond ? '  ok   ' : '  FAIL ') + name + (extra !== undefined ? '  -> ' + JSON.stringify(extra) : ''));
  if (!cond) fails.push(name);
}
const TITLE = "(c) => { const e = c.querySelector('.kb-title > span:first-child') || c.querySelector('.kb-head > span:first-child'); return e ? e.textContent.trim() : null; }";

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text())) errors.push('CONSOLE: ' + m.text()); });

  await page.goto(FILE);
  await page.evaluate(() => localStorage.setItem('ww_session_v2', JSON.stringify({ access_token: 'x.y.z', refresh_token: 'r', expires_at: Date.now() + 3600e3, user_id: '00000000-0000-4000-8000-000000000001', email: 't358@test.local' })));
  await page.goto(FILE);
  await page.waitForTimeout(1800);

  check('версия приложения задана', /^\d+\.\d+$/.test(String(await page.evaluate(() => WW_VERSION))), await page.evaluate(() => WW_VERSION));

  /* засев задач */
  await page.evaluate(() => {
    const T = todayStr();
    const d = new Date(); d.setDate(d.getDate() + 1);
    const TM = d.toISOString().slice(0, 10);
    S.tasks = [
      { id: 'A1', text: 'Купить молоко', who: 'me', date: T, prio: 'mid', done: false, created: Date.now() },
      { id: 'A2', text: 'Заплатить за свет', who: 'both', date: TM, prio: 'high', done: false, created: Date.now() },
      { id: 'A3', text: 'Записаться к врачу', who: 'me', date: '', prio: 'low', done: false, created: Date.now() }
    ];
    save();
    nav('planner');
  });
  await page.waitForTimeout(700);

  const cols = await page.evaluate((tf) => {
    const title = eval(tf);
    return Array.from(document.querySelectorAll('#kanban .kb-col')).map(c => ({ title: title(c), count: (c.querySelector('.kb-count') || {}).textContent }));
  }, TITLE);
  check('в канбане появилась 5-я вкладка «Выполнено»', cols.length === 5 && cols[4].title === 'Выполнено', cols);
  check('прежние вкладки сохранились', cols.slice(0, 4).map(c => c.title).join('|') === 'Сегодня и просроченные|Завтра|Неделя|Отложенные', cols.map(c => c.title));
  check('пустая вкладка сообщает, что задач нет',
    await page.evaluate(() => /Выполненных задач пока нет/.test(document.querySelectorAll('#kanban .kb-col')[4].textContent)));
  check('нижняя карточка «Выполнено» скрыта в режиме колонок',
    await page.evaluate(() => getComputedStyle(document.getElementById('tasks-done').closest('.section.card')).display === 'none'));

  /* отметка выполненной из колонки «Сегодня» */
  await page.evaluate(() => document.querySelectorAll('#kanban .kb-col')[0].querySelector('.task-check').click());
  await page.waitForTimeout(600);
  const moved = await page.evaluate(() => {
    const cs = document.querySelectorAll('#kanban .kb-col');
    return {
      todayCount: (cs[0].querySelector('.kb-count') || {}).textContent,
      doneCount: (cs[4].querySelector('.kb-count') || {}).textContent,
      doneText: cs[4].textContent.indexOf('Купить молоко') !== -1,
      todayHas: cs[0].textContent.indexOf('Купить молоко') !== -1,
      strike: !!cs[4].querySelector('.ww58-text'),
      when: (cs[4].querySelector('.ww58-when') || {}).textContent,
      stored: S.tasks.find(t => t.id === 'A1').done
    };
  });
  check('выполненная задача переехала во вкладку «Выполнено»', moved.doneText && !moved.todayHas && moved.doneCount === '1' && moved.stored === true, moved);
  check('карточка зачёркнута и показывает время', moved.strike && /сегодня в \d\d:\d\d/.test(moved.when || ''), moved.when);

  /* восстановление галочкой */
  await page.evaluate(() => document.querySelectorAll('#kanban .kb-col')[4].querySelector('.ww58-check').click());
  await page.waitForTimeout(600);
  const back = await page.evaluate(() => {
    const cs = document.querySelectorAll('#kanban .kb-col');
    return { todayHas: cs[0].textContent.indexOf('Купить молоко') !== -1, doneCount: (cs[4].querySelector('.kb-count') || {}).textContent, task: S.tasks.find(t => t.id === 'A1') };
  });
  check('галочка возвращает задачу в невыполненные', back.todayHas && back.doneCount === '0' && back.task.done === false && !back.task.doneAt, back);

  /* восстановление кнопкой ↺ */
  await page.evaluate(() => ww58Complete('A2'));
  await page.waitForTimeout(500);
  await page.evaluate(() => document.querySelectorAll('#kanban .kb-col')[4].querySelector('.ww58-acts [data-ww58-act="restore"]').click());
  await page.waitForTimeout(600);
  check('кнопка ↺ тоже возвращает задачу',
    await page.evaluate(() => S.tasks.find(t => t.id === 'A2').done === false && document.querySelectorAll('#kanban .kb-col')[1].textContent.indexOf('Заплатить за свет') !== -1));

  /* drag&drop в обе стороны */
  const drops = await page.evaluate(() => {
    const fake = () => ({ preventDefault() {}, currentTarget: { classList: { remove() {} } } });
    _dragTaskId = 'A3';
    taskDrop(fake(), 'done');
    const wasDone = !!S.tasks.find(t => t.id === 'A3').done;
    _dragTaskId = 'A3';
    taskDrop(fake(), 'today');
    const t = S.tasks.find(t2 => t2.id === 'A3');
    return { wasDone, nowDone: !!t.done, date: t.date, today: todayStr() };
  });
  check('перетаскивание в «Выполнено» отмечает задачу', drops.wasDone === true, drops);
  check('перетаскивание обратно снимает отметку', drops.nowDone === false && drops.date === drops.today, drops);

  /* кнопки колонки */
  await page.evaluate(() => { ww58Complete('A1'); ww58Complete('A2'); ww58Complete('A3'); });
  await page.waitForTimeout(600);
  const btns = await page.evaluate(() => {
    const c = document.querySelectorAll('#kanban .kb-col')[4];
    return { count: (c.querySelector('.kb-count') || {}).textContent, add: (c.querySelector('.kb-add') || {}).textContent, restoreAll: !!c.querySelector('.ww58-restore-all'), cards: c.querySelectorAll('[data-ww58]').length };
  });
  check('все выполненные видны в одной вкладке', btns.count === '3' && btns.cards === 3, btns);
  check('есть кнопки «Вернуть всё» и «Очистить выполненные»', btns.restoreAll && /Очистить/.test(btns.add || ''), btns);

  await page.evaluate(() => document.querySelector('.ww58-restore-all').click());
  await page.waitForTimeout(700);
  const restoredAll = await page.evaluate(() => ({ done: S.tasks.filter(t => t.done).length, doneCount: (document.querySelectorAll('#kanban .kb-col')[4].querySelector('.kb-count') || {}).textContent }));
  check('«Вернуть всё в работу» возвращает все задачи', restoredAll.done === 0 && restoredAll.doneCount === '0', restoredAll);

  /* фильтр по исполнителю */
  const filtered = await page.evaluate(async () => {
    ww58Complete('A1'); ww58Complete('A2');
    setTaskWho('me');
    await new Promise(r => setTimeout(r, 300));
    const c = document.querySelectorAll('#kanban .kb-col')[4];
    const res = { me: (c.querySelector('.kb-count') || {}).textContent, text: c.textContent.indexOf('Заплатить за свет') !== -1 };
    setTaskWho('all');
    await new Promise(r => setTimeout(r, 300));
    res.all = (document.querySelectorAll('#kanban .kb-col')[4].querySelector('.kb-count') || {}).textContent;
    return res;
  });
  check('фильтр «Кто» действует и на выполненные', filtered.me === '1' && filtered.text === false && filtered.all === '2', filtered);

  /* списочный режим */
  const listMode = await page.evaluate(async () => {
    setViewMode('planner', 'list');
    await new Promise(r => setTimeout(r, 500));
    const sec = document.getElementById('tasks-done').closest('.section.card');
    const vis = getComputedStyle(sec).display !== 'none';
    const has = sec.textContent.indexOf('Купить молоко') !== -1;
    setViewMode('planner', 'grid');
    await new Promise(r => setTimeout(r, 500));
    return { vis, has, hiddenAgain: getComputedStyle(document.getElementById('tasks-done').closest('.section.card')).display === 'none', cols: document.querySelectorAll('#kanban .kb-col').length };
  });
  check('в списочном режиме выполненные видны ниже', listMode.vis && listMode.has, listMode);
  check('в режиме колонок снова только вкладка', listMode.hiddenAgain && listMode.cols === 5, listMode);

  /* перезагрузка */
  await page.goto('about:blank');
  await page.goto(FILE);
  await page.waitForTimeout(1800);
  await page.evaluate(() => nav('planner'));
  await page.waitForTimeout(700);
  const afterReload = await page.evaluate((tf) => {
    const title = eval(tf);
    const cs = document.querySelectorAll('#kanban .kb-col');
    return { n: cs.length, title: title(cs[4]), count: (cs[4].querySelector('.kb-count') || {}).textContent };
  }, TITLE);
  check('вкладка и её содержимое сохраняются после перезагрузки', afterReload.n === 5 && afterReload.title === 'Выполнено' && afterReload.count === '2', afterReload);

  /* сворачивание колонки */
  const collapse = await page.evaluate(async () => {
    const c = document.querySelectorAll('#kanban .kb-col')[4];
    c.querySelector('.kb-head').click();
    await new Promise(r => setTimeout(r, 300));
    const on = c.classList.contains('ww54-collapsed');
    c.querySelector('.kb-head').click();
    await new Promise(r => setTimeout(r, 300));
    return { on, off: !c.classList.contains('ww54-collapsed') };
  });
  check('новая вкладка тоже сворачивается', collapse.on && collapse.off, collapse);

  /* мобильный вид */
  const m = await ctx.newPage();
  const mErr = [];
  m.on('pageerror', e => mErr.push('PAGEERROR: ' + e.message));
  await m.setViewportSize({ width: 390, height: 844 });
  await m.goto(FILE);
  await m.waitForTimeout(1800);
  await m.evaluate(() => nav('planner'));
  await m.waitForTimeout(700);
  const mob = await m.evaluate((tf) => {
    const title = eval(tf);
    const kb = document.getElementById('kanban');
    const cs = kb.querySelectorAll('.kb-col');
    const last = cs[cs.length - 1];
    return { n: cs.length, scrollable: kb.scrollWidth > kb.clientWidth + 10, title: title(last), w: Math.round(last.getBoundingClientRect().width) };
  }, TITLE);
  check('на телефоне вкладка листается свайпом последней', mob.n === 5 && mob.scrollable && mob.title === 'Выполнено' && mob.w > 200, mob);

  console.log('\nERRORS', JSON.stringify(errors.concat(mErr)));
  if (errors.length || mErr.length) fails.push('ошибки в консоли');
  await browser.close();
  console.log(fails.length ? '\nПРОВАЛЫ: ' + JSON.stringify(fails) : '\nВсе проверки прошли');
  process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
