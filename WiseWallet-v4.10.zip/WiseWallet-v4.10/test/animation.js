const { chromium } = require('playwright');
const path = require('path');
const FILE = 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails=[];
const check=(n,ok,d)=>{console.log((ok?'  ok   ':'  FAIL ')+n+(d===undefined?'':'  -> '+JSON.stringify(d))); if(!ok) fails.push(n);};
(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH, args:['--no-sandbox'] });

  // --- обычный режим ---
  const ctx = await b.newContext({ viewport:{width:1440,height:900} });
  const p = await ctx.newPage();
  const errs=[]; p.on('pageerror',e=>errs.push(e.message));
  await p.goto('file://' + require('path').resolve(__dirname,'..','index.html') + ''); await p.waitForTimeout(1600);
  await p.evaluate(()=>{['ww-splash','ww-lock','ww-auth','ww332-gate'].forEach(i=>{const e=document.getElementById(i);if(e)e.remove();});});
  await p.waitForTimeout(400);

  await p.evaluate(()=>{try{nav('goals')}catch(e){}}); await p.waitForTimeout(500);
  const st = await p.evaluate(()=>{
    const g=s=>{const el=document.querySelector(s); return el?getComputedStyle(el):null;};
    return {
      прогресс: g('.progress i')?.transitionProperty,
      карточка: g('.card')?.transitionProperty,
      кнопка: g('.btn')?.transitionProperty,
      цифра: g('.stat .val')?.animationName,
      тумблер: g('.ww30-sw .knob')?.transitionProperty,
    };
  });
  check('полоска прогресса анимируется', /width/.test(st.прогресс||''), st.прогресс);
  check('карточка реагирует на наведение', /box-shadow|transform/.test(st.карточка||''), st.карточка);
  check('кнопка имеет отклик нажатия', /transform/.test(st.кнопка||''), st.кнопка);
  await p.evaluate(()=>{try{nav('dashboard')}catch(e){}}); await p.waitForTimeout(500);
  const цифра = await p.evaluate(()=>{const el=document.querySelector('.stat .val'); return el?getComputedStyle(el).animationName:null;});
  check('цифры дашборда появляются с анимацией', цифра==='wwStatIn', цифра);

  // ключевое: анимация не должна ломать жесты и раскладку
  const before = await p.evaluate(()=>document.documentElement.scrollWidth);
  await p.evaluate(()=>nav('ops')); await p.waitForTimeout(500);
  const after = await p.evaluate(()=>document.documentElement.scrollWidth);
  check('переходы не создают горизонтального переполнения', before===after && after<=1440, {before,after});

  // проверяем, что «продавливание» кнопки не смещает соседей (transform не влияет на поток)
  const layout = await p.evaluate(()=>{
    const btn=document.querySelector('.btn'); if(!btn) return null;
    const r1=btn.getBoundingClientRect();
    btn.style.transform='scale(.97)';
    const r2=btn.getBoundingClientRect();
    btn.style.transform='';
    return { сдвигЛевого: Math.abs(r1.left-r2.left)<3, местоТоЖе: Math.abs(r1.top-r2.top)<3 };
  });
  check('нажатие не сдвигает соседние элементы', layout && layout.местоТоЖе, layout);
  check('ошибок нет', errs.length===0, errs.slice(0,3));
  await ctx.close();

  // --- режим «уменьшить движение» ---
  const ctx2 = await b.newContext({ viewport:{width:1440,height:900}, reducedMotion:'reduce' });
  const p2 = await ctx2.newPage();
  await p2.goto('file://' + require('path').resolve(__dirname,'..','index.html') + ''); await p2.waitForTimeout(1600);
  await p2.evaluate(()=>{['ww-splash','ww-lock','ww-auth','ww332-gate'].forEach(i=>{const e=document.getElementById(i);if(e)e.remove();});});
  await p2.waitForTimeout(400);
  await p2.evaluate(()=>{try{nav('goals')}catch(e){}}); await p2.waitForTimeout(500);
  const rm = await p2.evaluate(()=>{
    const g=s=>{const el=document.querySelector(s); return el?getComputedStyle(el):null;};
    return { прогресс:g('.progress i')?.transitionDuration, цифра:g('.stat .val')?.animationName, карточка:g('.card')?.transitionDuration };
  });
  check('при «уменьшить движение» переходы выключены', rm.прогресс==='0s', rm.прогресс);
  check('при «уменьшить движение» анимация цифр выключена', rm.цифра==='none', rm.цифра);
  await ctx2.close();

  await b.close();
  console.log('\n'+(fails.length?'ПРОВАЛЫ: '+fails.join(', '):'все проверки прошли'));
  process.exit(fails.length?1:0);
})();
