/* Тест v4.0: «Динамика категорий» — множественный выбор и вариант «Все». */
const { chromium } = require('playwright');
const path = require('path');
const FILE = process.env.WW_APP || 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

/* v4.05: диаграмма анимируется при появлении на экране — прокручиваем к ней
   и ждём конца анимации перед замером пикселей. */
const painted = async (p) => {
  await p.evaluate(() => { const c = document.getElementById('ww23-an-trend'); if (c) c.scrollIntoView({ block: 'center' }); });
  await p.waitForTimeout(900);
  return p.evaluate(() => {
  const cv = document.getElementById('ww23-an-trend');
  const ctx = cv.getContext('2d');
  const d = ctx.getImageData(0, 0, cv.width, cv.height).data;
  const cols = new Set();
  let filled = 0;
  for (let i = 0; i < d.length; i += 4) {
    if (d[i + 3] > 10) { filled++; cols.add(d[i] + ',' + d[i + 1] + ',' + d[i + 2]); }
  }
  return { filled, colors: cols.size };
  });
};

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const p = await (await b.newContext({ viewport: { width: 1500, height: 950 } })).newPage();
  const errors = [];
  p.on('pageerror', e => errors.push(e.message));

  await p.goto(FILE);
  await p.waitForTimeout(1600);
  await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
  await p.waitForTimeout(400);

  await p.evaluate(() => {
    S.categories = S.categories.filter(c => c.type !== 'expense').concat(
      ['Кладовка', 'Бензин', 'Обеды', 'Связь'].map((n, i) => ({ id: 'dc' + i, name: n, type: 'expense', icon: '📌' }))
    );
    S.transactions = [];
    const now = new Date();
    for (let m = 0; m < 6; m++) {
      const d = new Date(now.getFullYear(), now.getMonth() - m, 10);
      const ds = d.toISOString().slice(0, 10);
      [1000, 2000, 3000, 4000].forEach((amt, i) => {
        S.transactions.push({ id: 't' + m + i, type: 'expense', categoryId: 'dc' + i, amount: amt + m * 100, date: ds, accountId: (S.accounts[0] || {}).id || 'a1' });
      });
    }
    save(); nav('analytics');
  });
  await p.waitForTimeout(1000);

  const btn = await p.evaluate(() => {
    const b = document.getElementById('ww23-an-cat');
    return { tag: b && b.tagName, text: b && b.textContent };
  });
  check('вместо выпадающего списка — кнопка выбора', btn.tag === 'BUTTON', btn);

  const one = await painted(p);
  check('по умолчанию выбрана одна категория, диаграмма нарисована', one.filled > 0, one);

  // открыть лист выбора и включить «Все категории»
  await p.evaluate(() => ww23CatSheet());
  await p.waitForTimeout(300);
  const sheetRows = await p.evaluate(() => document.querySelectorAll('#ww23-cat-sheet .opt').length);
  check('в листе выбора есть строки категорий и пункт «Все»', sheetRows >= 6, sheetRows);

  await p.evaluate(() => ww23CatToggle('__all__'));
  await p.waitForTimeout(400);
  const allState = await p.evaluate(() => ({ label: document.getElementById('ww23-an-cat').textContent, all: ww23CatsAll(), n: ww23CatsResolved().length }));
  check('КЛЮЧЕВОЕ: работает вариант «Все категории»', allState.all === true && /Все категории/.test(allState.label), allState);

  const many = await painted(p);
  check('при выборе нескольких категорий столбцы стали разноцветными', many.colors > one.colors, { one: one.colors, many: many.colors });

  const legend = await p.evaluate(() => document.getElementById('ww23-an-trend-leg').textContent);
  check('под диаграммой появилась легенда с названиями категорий', /Кладовка/.test(legend) && /Бензин/.test(legend), legend.slice(0, 80));

  // снять одну из «всех» → остаётся явный список без неё
  await p.evaluate(() => ww23CatToggle('dc0'));
  await p.waitForTimeout(400);
  const minusOne = await p.evaluate(() => ({ all: ww23CatsAll(), ids: ww23CatsResolved(), total: S.categories.length, label: document.getElementById('ww23-an-cat').textContent }));
  check('КЛЮЧЕВОЕ: снятие галочки в режиме «Все» = все, кроме неё',
    minusOne.all === false && minusOne.ids.indexOf('dc0') === -1 && minusOne.ids.length === minusOne.total - 1, minusOne);

  // снять всё → подсказка, не пустая диаграмма
  await p.evaluate(() => ww23CatClear());
  await p.waitForTimeout(400);
  const none = await p.evaluate(() => document.getElementById('ww23-an-trend-sub').textContent);
  check('когда ничего не выбрано, показана подсказка', /не выбраны/.test(none), none);

  // вернуть одну категорию — снова обычный одноцветный график
  await p.evaluate(() => { ww23CatToggle('dc1'); closeModal(); });
  await p.waitForTimeout(400);
  const back = await p.evaluate(() => ({
    label: document.getElementById('ww23-an-cat').textContent,
    leg: document.getElementById('ww23-an-trend-leg').textContent,
    sub: document.getElementById('ww23-an-trend-sub').textContent,
  }));
  check('одна категория — название в кнопке, легенда скрыта', /Бензин/.test(back.label) && back.leg.trim() === '' && /За 12 месяцев/.test(back.sub), back);

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));
  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
