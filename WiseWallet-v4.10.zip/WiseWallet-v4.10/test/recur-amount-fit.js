/* Тест v4.08: поле суммы регулярного дохода вмещает сумму, а строка не
   схлопывает название.

   Что ловим (всё измерено до правки):
   1. У поля была жёсткая ширина 104 px. «200000» требует 99 px — запас 5 px,
      и его съедал любой шрифт пошире; с семи знаков («1500000» — 107 px)
      обрезало гарантированно.
   2. Обёртка голосового ввода .ww61-wrap объявлена как width:100% (она
      рассчитана на полноширинные поля формы). Вокруг компактного поля суммы
      внутри строки она забирала 207 px из 334 и выдавливала название
      категории ровно в 0 px на всех телефонах. */
const { chromium } = require('playwright');
const path = require('path');
const FILE = process.env.WW_APP || 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

const seed = () => {
  S.recurring = (S.recurring || []).filter(r => r.type !== 'income');
  const c = (S.categories || []).find(x => x.type === 'income') || { id: 'ic1' };
  S.recurring.push({ id: 'ri1', type: 'income', name: 'Заработная плата', categoryId: c.id, amount: 200000, day: 15 });
  S.recurring.push({ id: 'ri2', type: 'income', name: 'Премия квартальная', categoryId: c.id, amount: 1500000, day: 20 });
  S.recurring.push({ id: 'ri3', type: 'income', name: 'Заработная плата основная', categoryId: c.id, amount: 12345678, day: 25 });
  S.recurIncomeAmt = {};
  save(); nav('credits');
};

/* сколько пикселей реально нужно тексту в поле, с учётом отступов */
const measure = (p, id) => p.evaluate((rid) => {
  const i = document.querySelector('#ww63-recur input.ww89-plan[data-id="' + rid + '"]');
  if (!i) return null;
  const cs = getComputedStyle(i);
  const cv = document.createElement('canvas').getContext('2d');
  cv.font = cs.fontWeight + ' ' + cs.fontSize + ' ' + cs.fontFamily;
  const need = Math.ceil(cv.measureText(i.value).width) + parseFloat(cs.paddingLeft) + parseFloat(cs.paddingRight) + 2;
  const row = i.closest('.row');
  const main = row.querySelector('.rmain');
  const title = main.querySelector('.rt');
  return {
    value: i.value,
    boxW: Math.round(i.getBoundingClientRect().width),
    needW: need,
    clipped: i.scrollWidth > i.clientWidth + 1,
    nameW: Math.round(main.getBoundingClientRect().width),
    titleClipped: title ? title.scrollWidth > title.clientWidth + 1 : null,
    insideViewport: Math.round(i.getBoundingClientRect().right) <= window.innerWidth,
  };
}, id);

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const errors = [];

  for (const [w, mobile] of [[360, true], [390, true], [430, true], [1400, false]]) {
    const p = await (await b.newContext({ viewport: { width: w, height: 900 }, isMobile: mobile, hasTouch: mobile })).newPage();
    p.on('pageerror', e => errors.push(w + 'px: ' + e.message));
    await p.goto(FILE); await p.waitForTimeout(1500);
    await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
    await p.evaluate(seed);
    await p.waitForTimeout(400);
    await p.evaluate(() => ww63Tab('inc'));
    await p.waitForTimeout(800);

    for (const [id, label] of [['ri1', '200 000'], ['ri2', '1 500 000'], ['ri3', '12 345 678']]) {
      const r = await measure(p, id);
      check('КЛЮЧЕВОЕ: сумма ' + label + ' не обрезана на ' + w + 'px', r && r.clipped === false, r);
      /* needW считается через canvas и отличается от внутреннего замера
         браузера на пиксель-другой, поэтому даём допуск; решающая проверка —
         clipped выше, она сравнивает scrollWidth с clientWidth. */
      check('поле шире, чем нужно тексту (' + label + ', ' + w + 'px)', r && r.boxW >= r.needW - 2, r && { boxW: r.boxW, needW: r.needW });
      check('поле не вылезает за экран (' + label + ', ' + w + 'px)', r && r.insideViewport === true, r && r.insideViewport);
    }

    /* название категории должно иметь место — раньше было ровно 0 px */
    const nameRoom = await measure(p, 'ri3');
    check('КЛЮЧЕВОЕ: названию осталось место на ' + w + 'px (было 0)', nameRoom.nameW >= 50, nameRoom.nameW);

    const hs = await p.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1);
    check('нет горизонтальной прокрутки на ' + w + 'px', hs === false);
    await p.context().close();
  }

  /* на телефоне действия свёрнуты в «⋮», на десктопе — обе кнопки */
  const pm = await (await b.newContext({ viewport: { width: 390, height: 900 }, isMobile: true, hasTouch: true })).newPage();
  pm.on('pageerror', e => errors.push('menu: ' + e.message));
  await pm.goto(FILE); await pm.waitForTimeout(1500);
  await pm.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
  await pm.evaluate(seed); await pm.waitForTimeout(400);
  await pm.evaluate(() => ww63Tab('inc')); await pm.waitForTimeout(800);
  const vis = await pm.evaluate(() => {
    const row = document.querySelector('#ww63-recur input.ww89-plan[data-id="ri1"]').closest('.row');
    /* микрофон голосового ввода — тоже <button>, но это не действие со
       строкой: считаем только кнопки действий. */
    return [...row.querySelectorAll('button')].filter(x => x.offsetParent !== null && !x.classList.contains('ww61-mic')).length;
  });
  check('на телефоне в строке одна кнопка действий', vis === 1, vis);

  const menu = await pm.evaluate(() => {
    ww408RecurMenu('ri1');
    const sheet = document.querySelector('.ww26-sheet');
    return { opts: sheet ? sheet.querySelectorAll('.opt').length : 0, txt: sheet ? sheet.textContent : '' };
  });
  check('меню даёт правку шаблона и удаление', menu.opts === 2 && /Изменить/.test(menu.txt) && /Удалить/.test(menu.txt), menu);
  await pm.evaluate(() => closeModal());

  /* правка суммы по-прежнему работает и остаётся помесячной */
  const edit = await pm.evaluate(() => {
    const i = document.querySelector('#ww63-recur input.ww89-plan[data-id="ri1"]');
    i.value = '250000';
    i.dispatchEvent(new Event('change', { bubbles: true }));
    return { tpl: S.recurring.find(r => r.id === 'ri1').amount, keys: Object.keys(S.recurIncomeAmt || {}).length };
  });
  check('правка суммы по-прежнему помесячная, шаблон не тронут', edit.tpl === 200000 && edit.keys === 1, edit);

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));
  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
