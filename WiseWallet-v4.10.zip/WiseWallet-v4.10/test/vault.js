const path = require("path");
const { chromium } = require("playwright");

const FILE = "file://" + path.resolve(__dirname, "../index.html");
const SESSION = {
  access_token: "smoke.jwt.token", refresh_token: "smoke.refresh",
  expires_at: Date.now() + 3600e3,
  user_id: "00000000-0000-4000-8000-000000000001", email: "smoke@example.com",
};

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ["--no-sandbox"] });
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 950 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push("PAGEERROR: " + e.message));
  page.on("console", (m) => { if (m.type() === "error" && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text())) errors.push("CONSOLE: " + m.text()); });

  await page.goto(FILE);
  await page.waitForTimeout(700);
  // старая идея в состоянии — проверим перенос в заметки
  await page.evaluate((s) => {
    localStorage.setItem("ww_session_v2", JSON.stringify(s));
    const st = JSON.parse(localStorage.getItem("ww_state_v1") || "{}");
    st.ideas = [{ id: "old1", title: "Старая идея", note: "текст идеи", category: "Накопления", status: "work", created: Date.now() }];
    localStorage.setItem("ww_state_v1", JSON.stringify(st));
  }, SESSION);
  await page.goto(FILE);
  await page.waitForTimeout(2000);

  console.log("VERSION", await page.evaluate(() => WW_VERSION));
  console.log("TABS", JSON.stringify(await page.evaluate(() => {
    nav("vault");
    return { tabs: WW40_TABS, labels: WW40_TAB_LABEL, hasIdeaFns: typeof window.renderIdeas };
  })));

  console.log("MIGRATION", JSON.stringify(await page.evaluate(async () => {
    nav("notes");
    await new Promise((r) => setTimeout(r, 600));
    return {
      notes: (S.notes || []).map((n) => ({ body: n.body, folder: n.folder })),
      ideasKey: "ideas" in S,
      folders: S.noteFolders,
      rows: document.querySelectorAll("#notes-list .row").length,
      tabLabel: (document.querySelector('.ww40-tab[data-tab="notes"]') || {}).textContent,
      panelH1: (document.querySelector("#ww40-panel-notes h1") || {}).textContent,
    };
  }, null)));

  // создание + автосохранение (печатаем как пользователь)
  await page.evaluate(() => ww41New());
  await page.waitForTimeout(400);
  await page.fill("#ww41-body", "Список покупок\nНадо купить к выходным");
  await page.waitForTimeout(900);
  console.log("AUTOSAVE", JSON.stringify(await page.evaluate(() => ({
    saved: (S.notes[0] || {}).body,
    badge: (document.getElementById("ww41-saved") || {}).textContent,
    hasSaveBtn: !!document.querySelector("#modal .btn-primary") && document.querySelector("#modal .btn-primary").textContent,
    inStorage: (JSON.parse(localStorage.getItem("ww_state_v1")).notes || []).length,
  }))));

  // чек-лист через панель форматирования + тап по галочке
  const check = await page.evaluate(async () => {
    const wait = (ms) => new Promise((r) => setTimeout(r, ms));
    const ta = document.getElementById("ww41-body");
    ta.value = "Список покупок\nМолоко\nХлеб";
    ta.selectionStart = ta.selectionEnd = ta.value.indexOf("Молоко") + 2;
    ww41Fmt("check"); await wait(700);
    ta.selectionStart = ta.selectionEnd = ta.value.indexOf("Хлеб") + 2;
    ww41Fmt("check"); await wait(700);
    const items = document.querySelectorAll("#ww41-check .it").length;
    document.querySelectorAll("#ww41-check .it")[0].click(); await wait(500);
    const afterTap = { body: S.notes[0].body, on: document.querySelectorAll("#ww41-check .it.on").length, progress: (document.querySelector("#ww41-check .sub") || {}).textContent };
    ta.selectionStart = ta.selectionEnd = 2;
    ww41Fmt("h"); await wait(600);
    const head = S.notes[0].body.split("\n")[0];
    ww41Pin(S.notes[0].id, 1); await wait(300);
    const pinBtn = (document.getElementById("ww41-pin-btn") || {}).textContent;
    document.getElementById("ww41-folder").value = "Накопления";
    ww41MoveNote(); await wait(300);
    ww41Done(); await wait(500);
    return { items, afterTap, head, pinBtn, folder: S.notes[0].folder, modalClosed: !document.querySelector("#modal.on, #modal[style*='display: flex']"), title: ww41Title(S.notes[0]) };
  });
  console.log("EDITOR", JSON.stringify(check, null, 1));

  // список: закреплённые сверху, поиск, галерея, папки, корзина
  const list = await page.evaluate(async () => {
    const wait = (ms) => new Promise((r) => setTimeout(r, ms));
    renderNotes(); await wait(300);
    const order = [...document.querySelectorAll("#notes-list .row .rt")].map((e) => e.textContent.trim());
    document.getElementById("note-q").value = "молоко"; renderNotes(); await wait(300);
    const found = document.querySelectorAll("#notes-list .row").length;
    document.getElementById("note-q").value = "зззнеттакого"; renderNotes(); await wait(300);
    const none = (document.querySelector("#notes-list .empty") || {}).textContent;
    document.getElementById("note-q").value = ""; renderNotes(); await wait(200);
    ww41ToggleView(); await wait(300);
    const grid = { cards: document.querySelectorAll("#ww41-grid .ww41-card").length, btn: (document.getElementById("note-view") || {}).textContent };
    ww41ToggleView(); await wait(300);
    const chips = [...document.querySelectorAll("#note-chips .chip")].map((c) => c.textContent.trim());
    ww41SetFolder("Накопления"); await wait(300);
    const inFolder = document.querySelectorAll("#notes-list .row").length;
    ww41SetFolder("all"); await wait(200);
    const id = S.notes.find((n) => !n.trashed).id;
    ww41Delete(id); await wait(400);
    const afterDel = { visible: document.querySelectorAll("#notes-list .row").length, trashed: !!S.notes.find((n) => n.id === id).trashed, tabCount: (document.querySelector('.ww40-tab[data-tab="notes"] .cnt') || {}).textContent };
    ww41SetFolder("trash"); await wait(300);
    const trash = { rows: document.querySelectorAll("#notes-list .row").length, sub: (document.getElementById("note-sub") || {}).textContent };
    ww41Restore(id); await wait(300);
    const restored = !S.notes.find((n) => n.id === id).trashed;
    ww41SetFolder("all"); await wait(200);
    return { order, found, none, grid, chips, inFolder, afterDel, trash, restored };
  });
  console.log("LIST", JSON.stringify(list, null, 1));

  // журнал/undo видит заметки + вес состояния
  console.log("AUDIT", JSON.stringify(await page.evaluate(() => ({
    col: WW331_COLS.find((c) => c.key === "notes"),
    name: (WW331_COLS.find((c) => c.key === "notes") || {}).name?.(S.notes[0]),
    weight: wwPayloadWeight({ notes: S.notes }),
  }))));

  // дашборд: правка суммы дохода
  await page.evaluate(() => nav("dashboard"));
  await page.waitForTimeout(900);
  console.log("INC_BTNS", JSON.stringify(await page.evaluate(() => ({
    coins: document.querySelectorAll("#coins-inc .coin.inc").length,
    btns: document.querySelectorAll("#coins-inc .ww41-inc-btn").length,
    accBtns: document.querySelectorAll("#coins-acc .coin-menu-btn").length,
  }))));

  // меню → «Изменить сумму»: с нуля, потом правка единственной операции, потом вниз
  const money1 = await page.evaluate(async () => {
    const wait = (ms) => new Promise((r) => setTimeout(r, ms));
    const inp = () => document.getElementById("ww-dlg-in");
    const ok = () => document.getElementById("ww-dlg-ok");
    const out = {};
    const catId = S.categories.find((c) => c.type === "income").id;
    out.catId = catId;
    document.querySelector(`#coins-inc .coin[data-inc="${catId}"] .ww41-inc-btn`).click();
    await wait(300);
    out.menu = [...document.querySelectorAll("#ww41-inc-menu .view-menu-item")].map((b) => b.textContent.trim());
    ww41EditIncome(catId); await wait(400);
    out.menuClosed = !document.getElementById("ww41-inc-menu");
    out.dlgTitle = (document.querySelector("#ww-dlg h3") || {}).textContent;
    out.defaultVal = inp().value;
    inp().value = "50000"; ok().click(); await wait(800);
    out.after1 = {
      total: ww41IncTotal(catId),
      txs: S.transactions.filter((t) => t.categoryId === catId).length,
      coin: (document.querySelector(`#coins-inc .coin[data-inc="${catId}"] .camt`) || {}).textContent,
      incTotal: (document.getElementById("ww26-inc-total") || {}).textContent,
      btnKept: !!document.querySelector(`#coins-inc .coin[data-inc="${catId}"] .ww41-inc-btn`),
    };
    ww41EditIncome(catId); await wait(400);
    out.reopenDefault = inp().value;
    inp().value = "75000"; ok().click(); await wait(800);
    out.after2 = { total: ww41IncTotal(catId), txs: S.transactions.filter((t) => t.categoryId === catId).length, amounts: S.transactions.filter((t) => t.categoryId === catId).map((t) => t.amount) };
    ww41EditIncome(catId); await wait(400);
    inp().value = "20000"; ok().click(); await wait(800);
    out.after3 = { total: ww41IncTotal(catId), txs: S.transactions.filter((t) => t.categoryId === catId).length, neg: S.transactions.filter((t) => t.amount < 0).length };
    ww41EditIncome(catId); await wait(400);
    inp().value = "0"; ok().click(); await wait(800);
    out.after4 = { total: ww41IncTotal(catId), txs: S.transactions.filter((t) => t.categoryId === catId).length };
    ww41EditIncome(catId); await wait(400);
    inp().value = "-5"; ok().click(); await wait(400);
    out.negative = { stillOpen: !!inp(), err: (document.getElementById("ww-dlg-err") || {}).textContent };
    document.getElementById("ww-dlg-cancel").click(); await wait(400);
    ww41EditIncome(catId); await wait(400);
    inp().value = "31500"; ok().click(); await wait(800);
    out.after5 = { total: ww41IncTotal(catId), txs: S.transactions.filter((t) => t.categoryId === catId).length, dates: S.transactions.filter((t) => t.categoryId === catId).map((t) => t.date) };
    document.querySelector(`#coins-inc .coin[data-inc="${catId}"] .ww41-inc-btn`).click(); await wait(250);
    ww41RenameIncome(catId); await wait(400);
    inp().value = "Основная зарплата"; ok().click(); await wait(600);
    out.renamed = cat(catId).name;
    out.coinLabel = (document.querySelector(`#coins-inc .coin[data-inc="${catId}"]`) || {}).textContent;
    out.balances = S.accounts.map((a) => accBalance(a.id));
    out.observer = await (async () => {
      const open = () => document.getElementById("ww-dlg-ov").classList.contains("open");
      S.settings.observerMode = true;
      const before = S.notes.length;
      ww41EditIncome(catId); await wait(350);
      const incBlocked = !open();
      ww41New(); await wait(250);
      const noteBlocked = S.notes.length === before;
      ww41Delete(S.notes[0].id); await wait(250);
      const delBlocked = !S.notes[0].trashed;
      S.settings.observerMode = false;
      return { incBlocked, noteBlocked, delBlocked };
    })();
    return out;
  });
  console.log("INCOME", JSON.stringify(money1, null, 1));

  // перезагрузка: заметки и правки на месте
  await page.goto(FILE);
  await page.waitForTimeout(2000);
  console.log("PERSIST", JSON.stringify(await page.evaluate(() => ({
    notes: (S.notes || []).length,
    firstTitle: S.notes && S.notes[0] ? ww41Title(S.notes[0]) : null,
    folders: S.noteFolders,
    incName: (S.categories.find((c) => c.name === "Основная зарплата") || {}).name,
  }))));

  // мобильный вид
  const m = await ctx.newPage();
  m.on("pageerror", (e) => errors.push("MOBILE PAGEERROR: " + e.message));
  await m.setViewportSize({ width: 390, height: 844 });
  await m.goto(FILE);
  await m.waitForTimeout(2000);
  await m.evaluate(() => nav("notes"));
  await m.waitForTimeout(700);
  console.log("MOBILE", JSON.stringify(await m.evaluate(() => ({
    scrollW: document.documentElement.scrollWidth, clientW: document.documentElement.clientWidth,
    rows: document.querySelectorAll("#notes-list .row").length,
    tab: (document.querySelector(".ww40-tab.active") || {}).dataset?.tab,
  }))));
  await m.screenshot({ path: "/tmp/a339-notes.png" });
  await m.evaluate(async () => { ww41Open(S.notes[0].id); });
  await m.waitForTimeout(600);
  await m.screenshot({ path: "/tmp/a339-editor.png" });
  await m.evaluate(() => { ww41Done(); nav("dashboard"); });
  await m.waitForTimeout(900);
  await m.screenshot({ path: "/tmp/a339-dash.png" });

  console.log("ERRORS", JSON.stringify(errors.slice(0, 8)));
  await browser.close();
})();
