/* Тесты v3.80: обязательное поле «Чей расход» (Паша / Катя / Соня / Другое). */
const { chromium } = require('playwright');
const path = require('path');
const FILE = 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const p = await (await b.newContext({ viewport: { width: 1400, height: 950 } })).newPage();
  const errors = [];
  p.on('pageerror', e => errors.push(e.message));
  p.on('console', m => { if (m.type() === 'error' && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text())) errors.push(m.text()); });
  await p.goto(FILE);
  await p.waitForTimeout(1600);
  await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
  await p.evaluate(() => { S.transactions = []; save(); nav('dashboard'); });
  await p.waitForTimeout(400);

  await p.evaluate(() => openTxModal());
  await p.waitForTimeout(400);
  const opts = await p.evaluate(() => [...document.querySelectorAll('#tx-whose button')].map(x => x.textContent));
  check('варианты идут в заданном порядке: Паша, Катя, Соня, Другое',
    JSON.stringify(opts) === JSON.stringify(['Паша', 'Катя', 'Соня', 'Другое']), opts);

  await p.fill('#tx-amount', '1500');
  await p.evaluate(() => saveTx());
  await p.waitForTimeout(400);
  const blocked = await p.evaluate(() => ({
    saved: S.transactions.length,
    marked: document.getElementById('tx-whose').classList.contains('need'),
    err: !!document.getElementById('tx-whose-err'),
    open: document.getElementById('overlay').classList.contains('open'),
  }));
  check('без выбора расход НЕ сохраняется', blocked.saved === 0, blocked);
  check('поле подсвечивается и показывает пояснение', blocked.marked && blocked.err, blocked);
  check('форма остаётся открытой (данные не теряются)', blocked.open, blocked);

  await p.evaluate(() => ww80PickWhose('katya', document.querySelector('#tx-whose button[data-whose="katya"]')));
  await p.evaluate(() => saveTx());
  await p.waitForTimeout(500);
  const saved = await p.evaluate(() => S.transactions.map(t => ({ a: t.amount, w: t.whose })));
  check('после выбора расход сохраняется с пометкой', saved.length === 1 && saved[0].w === 'katya', saved);

  // доход — поле не требуется
  await p.evaluate(() => openTxModal());
  await p.waitForTimeout(300);
  await p.evaluate(() => { const inc = [...document.querySelectorAll('#tx-seg button')].find(x => /Доход/.test(x.textContent)); setTxType('income', inc); });
  await p.waitForTimeout(300);
  const incHidden = await p.evaluate(() => { const fg = document.getElementById('tx-whose-fg'); return !fg || getComputedStyle(fg).display === 'none'; });
  check('на доходе поле скрыто', incHidden);
  await p.fill('#tx-amount', '5000');
  await p.evaluate(() => saveTx());
  await p.waitForTimeout(400);
  check('доход сохраняется без указания «чей»', await p.evaluate(() => S.transactions.length) === 2);

  // переключение обратно на расход возвращает поле
  await p.evaluate(() => openTxModal());
  await p.waitForTimeout(300);
  await p.evaluate(() => { const inc = [...document.querySelectorAll('#tx-seg button')].find(x => /Доход/.test(x.textContent)); setTxType('income', inc); });
  await p.waitForTimeout(200);
  await p.evaluate(() => { const ex = [...document.querySelectorAll('#tx-seg button')].find(x => /Расход/.test(x.textContent)); setTxType('expense', ex); });
  await p.waitForTimeout(300);
  const backVisible = await p.evaluate(() => { const fg = document.getElementById('tx-whose-fg'); return !!fg && getComputedStyle(fg).display !== 'none'; });
  check('при возврате к расходу поле снова появляется', backVisible);
  await p.evaluate(() => closeModal());

  // быстрый ввод с дашборда тоже требует поле
  await p.waitForTimeout(300);
  // экран входа мог появиться заново после сохранений — убираем
  await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
  await p.waitForTimeout(200);
  await p.click('.coin.acc'); await p.waitForTimeout(250);
  await p.click('.coin.cat'); await p.waitForTimeout(500);
  check('в быстром вводе поле присутствует', await p.evaluate(() => !!document.getElementById('tx-whose')));
  await p.fill('#tx-amount', '777');
  await p.evaluate(() => saveTx());
  await p.waitForTimeout(300);
  check('быстрый ввод тоже не сохраняет без выбора', await p.evaluate(() => S.transactions.length) === 2);
  await p.evaluate(() => ww80PickWhose('sonya', document.querySelector('#tx-whose button[data-whose="sonya"]')));
  await p.evaluate(() => saveTx());
  await p.waitForTimeout(400);
  const last = await p.evaluate(() => S.transactions[S.transactions.length - 1]);
  check('быстрый ввод сохраняет пометку', last.whose === 'sonya', { whose: last.whose });

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));
  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})();
