/* Тесты v3.94: два независимых исправления перетаскивания мышью.
   1) В боковом меню пункт «Хранилище» создаётся отдельной функцией уже
      после того, как остальным пунктам расставили data-sid — сам он этот
      атрибут не получал и был невидим для системы сортировки: нельзя было
      ни встать на его место, ни утащить его. Из-за этого дотащить что-либо
      до самого низа списка не получалось.
   2) Иконки на дашборде: фоновая пересборка списка (например, после
      синхронизации) могла случиться прямо во время перетаскивания и
      уничтожить DOM-элемент, за который «держится» жест — перетаскивание
      обрывалось без видимой причины, что выглядело как «иногда срабатывает,
      иногда нет». */
const { chromium } = require('playwright');
const path = require('path');
const FILE = 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

async function dragMouse(page, fromX, fromY, toX, toY, steps = 12) {
  await page.mouse.move(fromX, fromY);
  await page.mouse.down();
  for (let i = 1; i <= steps; i++) {
    await page.mouse.move(fromX + (toX - fromX) * i / steps, fromY + (toY - fromY) * i / steps);
    await page.waitForTimeout(15);
  }
  await page.mouse.up();
}

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const errors = [];

  console.log('--- 1. Боковое меню: можно опустить пункт в самый низ ---');
  {
    const p = await (await b.newContext({ viewport: { width: 1400, height: 900 } })).newPage();
    p.on('pageerror', e => errors.push(e.message));
    await p.goto(FILE);
    await p.waitForTimeout(1600);
    await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
    await p.waitForTimeout(400);

    const vaultHasSid = await p.evaluate(() => { const el = document.querySelector('.rail-item[data-nav="vault"]'); return el ? !!el.dataset.sid : null; });
    check('КЛЮЧЕВОЕ: у пункта «Хранилище» теперь есть data-sid', vaultHasSid === true, vaultHasSid);

    let boxes = await p.evaluate(() => [...document.querySelectorAll('.rail-item[data-nav]')].map(x => { const r = x.getBoundingClientRect(); return { nav: x.dataset.nav, x: r.left + r.width / 2, y: r.top + r.height / 2 }; }));
    const settingsBox = boxes.find(x => x.nav === 'settings');
    await dragMouse(p, settingsBox.x, settingsBox.y, boxes[1].x, boxes[1].y);
    await p.waitForTimeout(300);

    boxes = await p.evaluate(() => [...document.querySelectorAll('.rail-item[data-nav]')].map(x => { const r = x.getBoundingClientRect(); return { nav: x.dataset.nav, x: r.left + r.width / 2, y: r.top + r.height / 2, bottom: r.bottom }; }));
    const settingsBox2 = boxes.find(x => x.nav === 'settings');
    const lastBox = boxes[boxes.length - 1];
    await dragMouse(p, settingsBox2.x, settingsBox2.y, settingsBox2.x, lastBox.bottom + 20);
    await p.waitForTimeout(300);
    const order = await p.evaluate(() => [...document.querySelectorAll('.rail-item[data-nav]')].map(x => x.dataset.nav));
    check('«Настройки» удалось опустить в самый низ списка', order[order.length - 1] === 'settings', order);
    await p.close();
  }

  console.log('\n--- 2. Иконки дашборда: перетаскивание переживает фоновую пересборку ---');
  {
    const p = await (await b.newContext({ viewport: { width: 1400, height: 900 } })).newPage();
    p.on('pageerror', e => errors.push(e.message));
    await p.goto(FILE);
    await p.waitForTimeout(1600);
    await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
    const names = ['Коммуналка', 'Бытовые расходы', 'Сотовая связь', 'Платежи по кредитам', 'Катя', 'Бензин', 'Кладовка', 'Интернет', 'Прочее'];
    await p.evaluate((names) => {
      S.categories = S.categories.filter(c => c.type !== 'expense');
      names.forEach((n, i) => S.categories.push({ id: 'ec' + i, name: n, type: 'expense', icon: '📌' }));
      save(); nav('dashboard');
    }, names);
    await p.waitForTimeout(700);

    const g = await p.evaluate(() => { const r = document.querySelector('.coin.cat[data-cat="ec8"]').getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; });
    await p.mouse.move(g.x, g.y);
    await p.mouse.down();
    await p.mouse.move(g.x + 20, g.y);
    await p.waitForTimeout(30);

    const survivedGuard = await p.evaluate(() => { const before = !!document.querySelector('.ww26-ghost'); renderCoins(); const after = !!document.querySelector('.ww26-ghost'); return before && after; });
    check('КЛЮЧЕВОЕ: пересборка списка НЕ прерывает начатое перетаскивание', survivedGuard === true, survivedGuard);

    // «Прочее» — последний элемент списка, тащить есть смысл только влево
    for (const dx of [-20, -40, -60, -90]) { await p.mouse.move(g.x + dx, g.y); await p.waitForTimeout(20); }
    await p.mouse.up();
    await p.waitForTimeout(300);
    const inData = await p.evaluate(() => S.categories.filter(c => c.type === 'expense').map(c => c.id).indexOf('ec8'));
    check('перетаскивание после вмешательства всё равно применилось и сохранилось', inData !== 8 && inData !== -1, inData);
    await p.close();
  }

  check('ошибок в консоли за оба сценария нет', errors.length === 0, errors.slice(0, 3));
  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})();
