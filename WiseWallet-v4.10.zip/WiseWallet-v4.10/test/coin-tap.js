/* Тесты: нажатие по ярлыку кошелька не должно попадать в кнопку «⋮».
   В v3.67 зона нажатия кнопки меню расширялась симметрично (inset:-12px) и
   перехватывала 31% площади иконки — попасть по самому ярлыку было трудно. */
const { chromium } = require('playwright');
const path = require('path');
const FILE = 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const ctx = await b.newContext({ viewport: { width: 430, height: 932 }, isMobile: true, hasTouch: true, deviceScaleFactor: 3 });
  const p = await ctx.newPage();
  const errors = [];
  p.on('pageerror', e => errors.push(e.message));
  p.on('console', m => { if (m.type() === 'error' && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text())) errors.push(m.text()); });
  await p.goto(FILE);
  await p.waitForTimeout(1600);
  await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
  await p.waitForTimeout(500);

  // 1. Кнопка меню не должна закрывать заметную часть иконки
  const share = await p.evaluate(() => {
    const disc = document.querySelector('.coin.acc .disc');
    const db = disc.getBoundingClientRect();
    let hit = 0, total = 0;
    for (let y = Math.round(db.top); y < db.bottom; y += 3)
      for (let x = Math.round(db.left); x < db.right; x += 3) {
        const dx = x - (db.left + db.width / 2), dy = y - (db.top + db.height / 2);
        if (Math.sqrt(dx * dx + dy * dy) > db.width / 2) continue;
        total++;
        const el = document.elementFromPoint(x, y);
        if (el && el.closest && el.closest('.coin-menu-btn')) hit++;
      }
    return Math.round(hit / total * 100);
  });
  check('кнопка «⋮» закрывает не более 15% иконки', share <= 15, share + '%');

  // 2. Тап по центру иконки выделяет ярлык, а не открывает меню
  const c = await p.evaluate(() => { const d = document.querySelector('.coin.acc .disc').getBoundingClientRect(); return { x: Math.round(d.left + d.width / 2), y: Math.round(d.top + d.height / 2) }; });
  await p.touchscreen.tap(c.x, c.y);
  await p.waitForTimeout(400);
  check('тап по иконке выделяет кошелёк', await p.evaluate(() => !!document.querySelector('.coin.ww26-sel')));
  check('тап по иконке НЕ открывает меню', !(await p.evaluate(() => !!document.getElementById('ww26-acc-menu'))));
  await p.evaluate(() => { try { ww26ClearSel(); } catch (e) {} });

  // 3. Тап по самой кнопке «⋮» открывает меню
  const bb = await p.evaluate(() => { const b = document.querySelector('.coin.acc .coin-menu-btn').getBoundingClientRect(); return { x: Math.round(b.left + b.width / 2), y: Math.round(b.top + b.height / 2) }; });
  await p.touchscreen.tap(bb.x, bb.y);
  await p.waitForTimeout(400);
  check('тап по «⋮» открывает меню', await p.evaluate(() => !!document.getElementById('ww26-acc-menu')));

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));
  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})();
