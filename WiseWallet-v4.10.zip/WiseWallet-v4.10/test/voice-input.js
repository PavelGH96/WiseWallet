/* Тесты v3.61: голосовой набор во всех полях (с эмуляцией микрофона) */
const { chromium } = require('playwright');
const FILE = process.env.WW_APP || 'file://' + require('path').resolve(__dirname, '../index.html');
const fails = [];
function check(name, cond, extra) {
  console.log((cond ? '  ok   ' : '  FAIL ') + name + (extra !== undefined ? '  -> ' + JSON.stringify(extra) : ''));
  if (!cond) fails.push(name);
}

/* поддельный SpeechRecognition: отдаёт window.__voiceText при start() */
const STUB = `
(function () {
  window.__voiceText = 'тестовая фраза';
  window.__voiceStarts = 0;
  function Fake() { this.lang = ''; this.interimResults = false; this.maxAlternatives = 1; this.continuous = false; }
  Fake.prototype.start = function () {
    window.__voiceStarts++;
    var self = this;
    setTimeout(function () {
      var t = window.__voiceText;
      if (t !== null && self.onresult) {
        self.onresult({ resultIndex: 0, results: [Object.assign([{ transcript: t }], { isFinal: true, length: 1 })] });
      }
      if (self.onend) self.onend();
    }, 30);
  };
  Fake.prototype.stop = function () { if (this.onend) this.onend(); };
  Fake.prototype.abort = function () { if (this.onend) this.onend(); };
  window.SpeechRecognition = Fake;
})();
`;

const HAS_MIC = `(function(el){
  const w = el.parentElement;
  if (!w || !w.classList.contains('ww61-wrap')) return false;
  return Array.prototype.some.call(w.children, c => c.classList && c.classList.contains('ww61-mic'));
})`;

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  await ctx.addInitScript(STUB);
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text())) errors.push('CONSOLE: ' + m.text()); });

  await page.goto(FILE);
  await page.evaluate(() => localStorage.setItem('ww_session_v2', JSON.stringify({ access_token: 'x.y.z', refresh_token: 'r', expires_at: Date.now() + 3600e3, user_id: '00000000-0000-4000-8000-000000000001', email: 't361@test.local' })));
  await page.goto(FILE);
  await page.waitForTimeout(1800);

  check('версия задана', /^\d+\.\d+$/.test(String(await page.evaluate(() => WW_VERSION))), await page.evaluate(() => WW_VERSION));
  check('нет битых символов', !(await page.evaluate(() => document.documentElement.innerHTML.indexOf('\uFFFD') !== -1)));
  check('голосовой движок доступен', await page.evaluate(() => typeof ww61Dictate === 'function' && ww61SpeechOk() === true));

  /* ---------- микрофон в поиске операций и на страницах ---------- */
  const pages = await page.evaluate(async () => {
    const res = {};
    const list = ['ops', 'planner', 'goals', 'vault', 'settings', 'credits'];
    for (const p of list) {
      nav(p);
      await new Promise(r => setTimeout(r, 450));
      const host = document.getElementById('page-' + p) || document.body;
      const fields = Array.from(host.querySelectorAll('input, textarea')).filter(el => {
        const t = (el.type || 'text').toLowerCase();
        const r = el.getBoundingClientRect();
        return ['text', 'search', 'number', 'textarea'].indexOf(el.tagName === 'TEXTAREA' ? 'textarea' : t) !== -1 && r.width >= 70;
      });
      /* v4.10: в полях, куда вводят только сумму, диктовка отключена —
         исключаем их из ожидания «у каждого поля есть микрофон». */
      const isNum = (el) => {
        if ((el.type || '').toLowerCase() === 'number') return true;
        const im = (el.getAttribute('inputmode') || '').toLowerCase();
        if (im === 'decimal' || im === 'numeric') return true;
        if (el.classList.contains('ww89-plan') || el.classList.contains('amount-in')) return true;
        return /amount|sum|-bal|balance|price/i.test(el.id || '');
      };
      const own = fields.filter(el => ['ops-q', 'tx-quick', 'tx-note'].indexOf(el.id) === -1 && !isNum(el));
      const withMic = own.filter(el => {
        const w = el.parentElement;
        return !!(w && w.classList.contains('ww61-wrap') && Array.prototype.some.call(w.children, c => c.classList && c.classList.contains('ww61-mic')));
      });
      res[p] = { fields: own.length, mic: withMic.length, skippedOld: fields.length - own.length };
    }
    return res;
  });
  const allCovered = Object.keys(pages).every(k => pages[k].fields === 0 || pages[k].mic === pages[k].fields);
  check('на всех страницах текстовые поля получили микрофон', allCovered, pages);

  /* ---------- окно задачи: текст и заметка ---------- */
  const taskMics = await page.evaluate(async () => {
    nav('planner');
    await new Promise(r => setTimeout(r, 300));
    openTaskModal('', 'today');
    await new Promise(r => setTimeout(r, 500));
    const mic = id => { const el = document.getElementById(id); return !!(el && el.parentElement && el.parentElement.querySelector('.ww61-mic')); };
    return { text: mic('tk-text'), note: mic('ww60-note'), date: mic('tk-date'), time: mic('ww60-time') };
  });
  check('в окне задачи микрофон есть у текста и заметки, и нет у даты/времени',
    taskMics.text && taskMics.note && !taskMics.date && !taskMics.time, taskMics);

  /* диктовка в поле задачи и дописывание в заметку */
  const dictated = await page.evaluate(async () => {
    window.__voiceText = 'Позвонить в банк';
    document.getElementById('tk-text').parentElement.querySelector('.ww61-mic').click();
    await new Promise(r => setTimeout(r, 200));
    const text1 = document.getElementById('tk-text').value;

    const note = document.getElementById('ww60-note');
    note.value = 'Первая строка';
    window.__voiceText = 'вторая часть';
    note.parentElement.querySelector('.ww61-mic').click();
    await new Promise(r => setTimeout(r, 200));
    const noteVal = note.value;

    window.__voiceText = 'ещё дополнение';
    note.parentElement.querySelector('.ww61-mic').click();
    await new Promise(r => setTimeout(r, 200));
    return { text1, noteVal, noteVal2: note.value };
  });
  check('голос заполняет обычное поле', dictated.text1 === 'Позвонить в банк', dictated.text1);
  check('в заметке текст дописывается, а не стирается',
    dictated.noteVal === 'Первая строка вторая часть' && /ещё дополнение$/.test(dictated.noteVal2), dictated);

  /* сохранённая голосом задача попадает в список */
  const savedByVoice = await page.evaluate(async () => {
    document.getElementById('tk-date').value = todayStr();
    saveTask('');
    await new Promise(r => setTimeout(r, 400));
    const t = S.tasks[S.tasks.length - 1] || {};
    return { text: t.text, note: t.note };
  });
  check('надиктованная задача сохраняется',
    savedByVoice.text === 'Позвонить в банк' && /дополнение/.test(savedByVoice.note || ''), savedByVoice);

  /* ---------- поля суммы: микрофона нет ---------- */
  /* v4.10: раньше здесь проверялось, что голос в поле суммы превращается в
     число. Требование изменилось: в полях, куда вводят только сумму, диктовка
     не нужна — цифры быстрее набрать руками, а микрофон занимал место в строке.
     Теперь проверяем обратное: микрофона там быть не должно. */
  const amount = await page.evaluate(async () => {
    closeModal();
    await new Promise(r => setTimeout(r, 200));
    openTxModal();
    await new Promise(r => setTimeout(r, 500));
    const amt = document.getElementById('tx-amount');
    if (!amt) return { found: false };
    const wrap = amt.parentElement;
    return {
      found: true,
      mic: !!(wrap && wrap.querySelector && wrap.querySelector('.ww61-mic')),
      noteMic: !!(document.getElementById('tx-note') || {}).parentElement,
    };
  });
  check('КЛЮЧЕВОЕ: в поле суммы операции микрофона нет', amount.found && amount.mic === false, amount);

  /* ---------- пароли и служебные поля — без микрофона ---------- */
  const pw = await page.evaluate(async () => {
    closeModal();
    await new Promise(r => setTimeout(r, 250));
    const all = Array.from(document.querySelectorAll('input'));
    const bad = all.filter(el => {
      const t = (el.type || '').toLowerCase();
      if (['password', 'date', 'time', 'checkbox', 'radio', 'file', 'color', 'range', 'hidden'].indexOf(t) === -1) return false;
      const w = el.parentElement;
      return !!(w && w.classList.contains('ww61-wrap') && Array.prototype.some.call(w.children, c => c.classList && c.classList.contains('ww61-mic')));
    }).map(el => el.type + '#' + el.id);
    return { bad, pwCount: all.filter(el => el.type === 'password').length };
  });
  check('у паролей, дат, времени и галочек микрофона нет', pw.bad.length === 0, pw);

  /* ---------- поиск и палитра ⌘K ---------- */
  const search = await page.evaluate(async () => {
    nav('ops');
    await new Promise(r => setTimeout(r, 450));
    const q = document.getElementById('ops-q');
    const oldMic = !!document.getElementById('ww331-opsmic');
    const newMic = !!(q && q.parentElement && q.parentElement.querySelector('.ww61-mic'));
    let pal = null;
    if (typeof ww57SearchToggle === 'function') { ww57SearchToggle(); await new Promise(r => setTimeout(r, 400)); }
    const pq = document.getElementById('ww57-q');
    if (pq) {
      const b = pq.parentElement.querySelector('.ww61-mic');
      pal = { mic: !!b, val: null };
      if (b) { window.__voiceText = 'коммуналка'; b.click(); await new Promise(r => setTimeout(r, 250)); pal.val = pq.value; }
    }
    return { oldMic, newMic, pal };
  });
  check('в поиске операций микрофон не дублируется', search.oldMic && !search.newMic, search);
  check('в глобальном поиске ⌘K есть голосовой ввод',
    !!search.pal && search.pal.mic && search.pal.val === 'коммуналка', search.pal);

  /* ---------- нет дублей после повторных отрисовок ---------- */
  const dup = await page.evaluate(async () => {
    if (typeof _dlgClose === 'function') { try { _dlgClose(); } catch (e) {} }
    closeModal();
    nav('ops');
    await new Promise(r => setTimeout(r, 300));
    for (let i = 0; i < 3; i++) { render('ops'); ww61Scan(); await new Promise(r => setTimeout(r, 120)); }
    const q = document.getElementById('ops-q');
    const perField = Array.from(document.querySelectorAll('.ww61-wrap')).map(w => w.querySelectorAll('.ww61-mic').length);
    return { max: perField.length ? Math.max.apply(null, perField) : 0, wraps: perField.length, opsq: q ? q.parentElement.querySelectorAll('.ww61-mic').length : -1 };
  });
  check('микрофоны не дублируются при перерисовке', dup.max === 1 && dup.wraps > 0, dup);

  /* ---------- горячая клавиша Alt+V в активное поле ---------- */
  const hk = await page.evaluate(async () => {
    const q = document.getElementById('ops-q');
    q.value = '';
    q.focus();
    window.__voiceText = 'такси';
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'v', altKey: true, bubbles: true }));
    await new Promise(r => setTimeout(r, 250));
    return q.value;
  });
  check('Alt+V диктует в активное поле', hk === 'такси', hk);

  /* ---------- когда браузер не умеет — кнопки не мешают ---------- */
  const noSpeech = await ctx.newPage();
  await noSpeech.addInitScript(`(function(){ try { delete window.SpeechRecognition; } catch(e){} window.SpeechRecognition = undefined; window.webkitSpeechRecognition = undefined; })();`);
  await noSpeech.goto(FILE);
  await noSpeech.waitForTimeout(1500);
  const off = await noSpeech.evaluate(async () => {
    nav('ops');
    await new Promise(r => setTimeout(r, 400));
    const mics = Array.from(document.querySelectorAll('.ww61-mic'));
    const visible = mics.filter(b => b.getBoundingClientRect().width > 0);
    return { total: mics.length, visible: visible.length, ok: typeof ww61SpeechOk === 'function' ? ww61SpeechOk() : null };
  });
  await noSpeech.close();
  check('без поддержки распознавания кнопки скрыты', off.ok === false && off.visible === 0, off);

  /* ---------- верстка не сломана ---------- */
  const layout = await page.evaluate(async () => {
    nav('ops');
    await new Promise(r => setTimeout(r, 400));
    const q = document.getElementById('ops-q');
    const w = q.getBoundingClientRect();
    const mic = Array.from(document.querySelectorAll('.ww61-mic')).filter(b => b.getBoundingClientRect().width > 0)[0];
    const m = mic ? mic.getBoundingClientRect() : null;
    return { fieldW: Math.round(w.width), fieldVisible: w.width > 80 && w.height > 20, micSize: m ? [Math.round(m.width), Math.round(m.height)] : null, hScroll: document.documentElement.scrollWidth > document.documentElement.clientWidth + 2 };
  });
  check('поля не сьехали и нет горизонтальной прокрутки',
    layout.fieldVisible && !layout.hScroll && layout.micSize && layout.micSize[0] >= 20, layout);

  console.log('\nERRORS', JSON.stringify(errors));
  if (errors.length) fails.push('ошибки в консоли');
  await browser.close();
  console.log(fails.length ? '\nПРОВАЛЫ: ' + JSON.stringify(fails) : '\nВсе проверки прошли');
  process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
