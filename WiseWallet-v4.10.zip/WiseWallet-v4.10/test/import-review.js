/* Тесты v3.78: разбор банковской выписки перед импортом.
   Главное требование: ни одна операция не попадает в приложение, пока
   человек не подтвердил категорию. Строка без категории не импортируется. */
const { chromium } = require('playwright');
const path = require('path');
const FILE = 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

const CSV = ['Дата;Описание;Сумма',
  '01.08.2026;Магнит у дома;-1250,40',
  '02.08.2026;ЗАРПЛАТА ЗА ИЮЛЬ;+150000,00',
  '03.08.2026;АЗС Лукойл 234;-2300,00',
  '05.08.2026;Перевод Иванову И.И.;-5000,00',
  '07.08.2026;Аптека Ригла;-870,50',
  '09.08.2026;NETFLIX.COM;-799,00'].join('\n');

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const p = await (await b.newContext({ viewport: { width: 1400, height: 900 } })).newPage();
  const errors = [];
  p.on('pageerror', e => errors.push(e.message));
  p.on('console', m => { if (m.type() === 'error' && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text())) errors.push(m.text()); });
  await p.goto(FILE);
  await p.waitForTimeout(1600);
  await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
  await p.evaluate(() => { S.transactions = []; save(); });

  await p.evaluate(t => ww23CsvParse(t), CSV);
  await p.waitForTimeout(400);
  check('шаг 1: открылось сопоставление колонок', await p.evaluate(() => !!document.getElementById('csv-date')));

  await p.evaluate(() => ww23CsvReview());
  await p.waitForTimeout(500);
  const rev = await p.evaluate(() => ({
    rows: document.querySelectorAll('.ww23-rev-row').length,
    txInApp: S.transactions.length,
    hasSelects: document.querySelectorAll('.ww23-rev-cat select').length,
  }));
  check('шаг 2: показаны все 6 операций отдельными строками', rev.rows === 6, rev);
  check('у каждой строки есть выбор категории', rev.hasSelects === 6, rev);
  check('КЛЮЧЕВОЕ: до подтверждения в приложение ничего не записано', rev.txInApp === 0, rev);

  // догадки подставлены как подсказка, но их можно менять
  const guesses = await p.evaluate(() => [...document.querySelectorAll('.ww23-rev-cat select')].map(s => s.value));
  check('категории предзаполнены догадками (экономит время)', guesses.filter(Boolean).length >= 4, guesses.length);

  // меняем неверную догадку, снимаем одну строку, одну оставляем без категории
  await p.evaluate(() => { const inc = S.categories.filter(c => c.type === 'income'); ww23RevCat(1, inc[0].id); });
  await p.evaluate(() => ww23RevToggle(3, false));
  await p.evaluate(() => ww23RevCat(5, ''));
  // v3.81: расход теперь требует и пометку «чей» — проставляем всем разом
  await p.evaluate(() => ww23RevWhoseAll('pasha'));
  await p.waitForTimeout(300);
  const foot = await p.evaluate(() => document.getElementById('ww23-rev-foot').textContent);
  check('подвал предупреждает о строках без категории', /без категории: 1/.test(foot), foot);
  const btn = await p.evaluate(() => document.getElementById('ww23-rev-go').textContent);
  check('кнопка показывает точное число к импорту (4)', /\(4\)/.test(btn), btn);

  p.evaluate(() => ww23ReviewImport());
  await p.waitForTimeout(600);
  // одна строка намеренно оставлена без категории -> приложение спросит подтверждение
  await p.evaluate(() => {
    const ok = [...document.querySelectorAll('#ww-dlg button')].find(b => /Импортировать/.test(b.textContent));
    if (ok) ok.click();
  });
  await p.waitForTimeout(600);
  const res = await p.evaluate(() => ({
    n: S.transactions.length,
    cats: S.transactions.map(t => (cat(t.categoryId) || {}).name),
    notes: S.transactions.map(t => t.note),
    tagged: S.transactions.every(t => (t.tags || []).includes('импорт')),
    allHaveCat: S.transactions.every(t => !!t.categoryId),
  }));
  check('импортировано ровно 4 операции', res.n === 4, res);
  check('строка без категории НЕ импортирована', !res.notes.includes('NETFLIX.COM'), res.notes);
  check('снятая галочкой строка НЕ импортирована', !res.notes.some(n => /Перевод Иванову/.test(n)), res.notes);
  check('исправленная вручную категория применилась', res.cats[1] === 'Заработная плата', res.cats);
  check('у всех импортированных есть категория', res.allHaveCat, res);
  check('импортированные помечены меткой «импорт»', res.tagged, res);

  // === Редактирование суммы и типа (v3.79) ===
  await p.evaluate(() => { S.transactions = []; save(); });
  await p.evaluate(t => ww23CsvParse(t), CSV);
  await p.waitForTimeout(400);
  await p.evaluate(() => ww23CsvReview());
  await p.waitForTimeout(500);
  check('поле суммы можно редактировать в каждой строке', await p.evaluate(() => document.querySelectorAll('.ww23-rev-amt input').length) === 6);

  await p.evaluate(() => ww23RevAmt(0, '999,90'));
  await p.waitForTimeout(200);
  const edited = await p.evaluate(() => ({
    val: ww23Review.items[0].amount,
    flagged: ww23Review.items[0].edited,
    foot: document.getElementById('ww23-rev-foot').textContent,
  }));
  check('изменённая сумма сохраняется (999.90)', edited.val === 999.9, edited);
  check('правка помечена и видна в подвале', edited.flagged && /сумм изменено: 1/.test(edited.foot), edited);

  await p.evaluate(() => ww23RevType(0));
  await p.waitForTimeout(200);
  const flipped = await p.evaluate(() => ({
    type: ww23Review.items[0].type,
    catReset: ww23Review.items[0].categoryId === '',
    opts: [...document.querySelectorAll('.ww23-rev-row[data-i="0"] select option')].slice(1, 2).map(o => o.textContent),
  }));
  check('расход можно переключить в доход', flipped.type === 'income', flipped);
  check('при смене типа категория сбрасывается (списки разные)', flipped.catReset, flipped);

  // === Импорт из Excel идёт через тот же экран разбора (v3.79) ===
  await p.evaluate(() => { closeModal(); S.transactions = []; save(); });
  await p.evaluate(() => {
    window.XLSX = {
      read: () => ({ SheetNames: ['Л'], Sheets: { 'Л': {} } }),
      utils: { sheet_to_json: () => ([
        ['Дата', 'Описание', 'Сумма'],
        ['04.08.2026', 'Пятёрочка №123', '-2340,10'],
        ['', '', ''],
        ['05.08.2026', 'Перевод от Петрова', '+7000,00'],
      ]) },
    };
    const dt = new DataTransfer();
    dt.items.add(new File([new Uint8Array([1])], 'v.xlsx', { type: 'application/vnd.ms-excel' }));
    let inp = document.getElementById('ww23-csv-file');
    if (!inp) { document.body.insertAdjacentHTML('beforeend', '<input type="file" id="ww23-csv-file" style="display:none">'); inp = document.getElementById('ww23-csv-file'); }
    inp.files = dt.files;
    ww23CsvPick(inp);
  });
  await p.waitForTimeout(700);
  await p.evaluate(() => ww23CsvReview());
  await p.waitForTimeout(500);
  const xl = await p.evaluate(() => ({
    rows: document.querySelectorAll('.ww23-rev-row').length,
    txInApp: S.transactions.length,
  }));
  check('Excel-файл проходит через тот же экран разбора', xl.rows === 2, xl);
  check('пустые строки Excel отфильтрованы', xl.rows === 2, xl);
  check('из Excel тоже ничего не записано до подтверждения', xl.txInApp === 0, xl);

  // === Колонка «Чей расход» в импорте (v3.81) ===
  await p.evaluate(() => { closeModal(); S.transactions = []; save(); });
  await p.evaluate(t => ww23CsvParse(t), CSV);
  await p.waitForTimeout(400);
  await p.evaluate(() => ww23CsvReview());
  await p.waitForTimeout(500);
  const head = await p.evaluate(() => [...document.querySelectorAll('.ww23-rev-table thead th')].map(t => t.textContent));
  check('в таблице появилась колонка «Чей расход»', head.includes('Чей расход'), head);
  const shape = await p.evaluate(() => [...document.querySelectorAll('.ww23-rev-row')].map(tr => ({
    sign: tr.querySelector('.ww23-sign').textContent,
    hasSelect: !!tr.querySelector('.ww23-rev-whose select'),
  })));
  check('у расходов есть выбор, у доходов — прочерк',
    shape.every(r => (r.sign === '−') === r.hasSelect), shape);

  // импорт при незаполненных «чей» — спрашивает подтверждение
  p.evaluate(() => ww23ReviewImport());
  await p.waitForTimeout(600);
  const warn = await p.evaluate(() => {
    const t = document.querySelector('#ww-dlg h3');
    return { open: !!t, title: t ? t.textContent : '' };
  });
  check('перед импортом предупреждает о незаполненных строках', warn.open && /только заполненные/.test(warn.title), warn);
  await p.evaluate(() => { const c = [...document.querySelectorAll('#ww-dlg button')].find(b => /Отмен/.test(b.textContent)); if (c) c.click(); });
  await p.waitForTimeout(400);
  check('после отмены ничего не импортировано и экран цел',
    (await p.evaluate(() => S.transactions.length)) === 0 && (await p.evaluate(() => document.querySelectorAll('.ww23-rev-row').length)) === 6);

  // массовое проставление + ручная правка
  await p.evaluate(() => ww23RevWhoseAll('pasha'));
  await p.waitForTimeout(300);
  const afterBulk = await p.evaluate(() => ww23Review.items.filter(x => x.type === 'expense').map(x => x.whose));
  check('кнопка «Всем расходам» проставляет всем сразу', afterBulk.every(w => w === 'pasha'), afterBulk);
  await p.evaluate(() => ww23RevWhose(2, 'sonya'));
  await p.waitForTimeout(200);
  check('ручной выбор перебивает массовый', await p.evaluate(() => ww23Review.items[2].whose) === 'sonya');

  await p.evaluate(() => { const inc = S.categories.filter(c => c.type === 'income'); ww23RevCat(1, inc[0].id); ww23RevCat(5, S.categories.find(c => c.type === 'expense').id); });
  await p.waitForTimeout(300);
  await p.evaluate(() => ww23ReviewImport());
  await p.waitForTimeout(600);
  const imported = await p.evaluate(() => S.transactions.map(t => ({ type: t.type, whose: t.whose || '' })));
  check('все импортированные расходы имеют пометку «чей»',
    imported.filter(t => t.type === 'expense').every(t => !!t.whose), imported);
  check('у доходов пометка пустая', imported.filter(t => t.type === 'income').every(t => !t.whose), imported);

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));
  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})();
