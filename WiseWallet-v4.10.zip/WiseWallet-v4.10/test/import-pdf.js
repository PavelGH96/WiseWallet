/* Тесты v3.82: разбор PDF-выписки (формат Тинькофф).
   Проверяем сам разбор строк — загрузку pdf.js тут не трогаем, она требует сети.
   Данные взяты из реальной выписки (суммы изменены не были, операции никуда
   не импортируются — только парсинг). */
const { chromium } = require('playwright');
const path = require('path');
const FILE = 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

const LINES = [
  '30.08.26',
  'ДЕМЕНЬШИН ПАВЕЛ МАКСИМОВИЧ',
  'Выписка по договору №5452357238',
  'Баланс на 11.07.26 51.34 ₽',
  '• Поступления 113 350.00 ₽',
  'Операции по карте № 220070******4670 ИМЯ ФАМИЛИЯ',
  'Расходы: 112 001.21 ₽',
  '15.07.26 15.07.26 Пополнение. Сбербанк Онлайн + 90 000.00 ₽ + 90 000.00 ₽',
  '15.07.26 15.07.26 Внутренний перевод на договор 90 000.00 ₽ 90 000.00 ₽',
  '5367056818',
  '18.07.26 18.07.26 Плата за партнерскую подписку 149.00 ₽ 149.00 ₽',
  '28.07.26 28.07.26 Внешний перевод по номеру телефона 720.00 ₽ 720.00 ₽',
  '+79122795079',
  '10.08.26 22:29 10.08.26 Кэшбэк за покупки по акциям + 29.80 ₽ + 29.80 ₽',
  'Операции по карте № 220070******7322 ИМЯ ФАМИЛИЯ',
  '27.07.26 17:34 27.07.26 Оплата в BURGER KING 0573 Ekaterinburg 64.99 ₽ 64.99 ₽',
  'RUS',
  '30.07.26 18:37 30.07.26 Оплата в urent G. MOSKVA RU 5.49 ₽ 5.49 ₽',
];

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const p = await (await b.newContext({ viewport: { width: 1400, height: 900 } })).newPage();
  const errors = [];
  p.on('pageerror', e => errors.push(e.message));
  await p.goto(FILE);
  await p.waitForTimeout(1600);
  await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });

  check('функции разбора PDF доступны', await p.evaluate(() => typeof ww23PdfRowsFromLines === 'function' && typeof ww23PdfLines === 'function' && typeof ww23PdfPick === 'function'));

  const rows = await p.evaluate(L => ww23PdfRowsFromLines(L), LINES);
  check('распознаны все 7 операций, шапка и заголовки пропущены', rows.length === 7, rows.length);

  const byNote = {};
  rows.forEach(r => { byNote[r[1]] = r[2]; });

  check('поступление распознано со знаком +', byNote['Пополнение. Сбербанк Онлайн'] === '+90000.00', byNote);
  check('расход распознан со знаком −', byNote['Плата за партнерскую подписку'] === '-149.00', byNote);
  check('пробелы в разрядах разобраны верно (90 000.00)', rows.some(r => r[2] === '-90000.00'), rows.map(r => r[2]));
  check('строка с временем (22:29) разобрана', byNote['Кэшбэк за покупки по акциям'] === '+29.80', byNote);

  // перенос описания на следующую строку
  check('перенесённый номер договора приклеен к описанию',
    !!byNote['Внутренний перевод на договор 5367056818'], Object.keys(byNote));
  check('перенесённый номер телефона приклеен к описанию',
    !!byNote['Внешний перевод по номеру телефона +79122795079'], Object.keys(byNote));
  check('перенесённое «RUS» приклеено к описанию',
    !!byNote['Оплата в BURGER KING 0573 Ekaterinburg RUS'], Object.keys(byNote));

  // заголовок секции НЕ должен прилипать (в JS \b не работает с кириллицей)
  check('заголовок секции не попал в описание операции',
    !Object.keys(byNote).some(k => /Операции по карте/.test(k)), Object.keys(byNote));

  // даты приводятся к внутреннему формату существующим разборщиком
  const dates = await p.evaluate(L => ww23PdfRowsFromLines(L).map(r => ww23ParseDate(r[0])), LINES);
  check('двузначный год разобран верно (15.07.26 → 2026-07-15)', dates[0] === '2026-07-15', dates.slice(0, 3));
  check('все даты распознаны', dates.every(Boolean), dates);

  // суммы читаются существующим разборщиком
  const amts = await p.evaluate(L => ww23PdfRowsFromLines(L).map(r => ww23ParseAmt(r[2])), LINES);
  check('все суммы читаются штатным разборщиком', amts.every(a => a !== null && a !== 0), amts);

  // ===== Выписка Сбербанка (v3.83): другой формат — операция в двух строках =====
  const SBER = [
    'Выписка по счёту дебетовой карты',
    'Остаток на 01.08.2026 12 681,48',
    'Пополнение 487 071,04',
    'ДАТА ОПЕРАЦИИ (МСК)',
    'ОСТАТОК СРЕДСТВ',
    '29.08.2026 08:34 Прочие операции 749,00 133 657,73',
    '29.08.2026 215811 brzh. Операция по карте ****5393',
    '28.08.2026 19:46 Супермаркеты 2 128,00 145 985,73',
    '28.08.2026 270207 MAGNUM-VINOTEKA EKATERINBURG RUS. Операция по',
    'карте ****5393',
    '28.08.2026 14:38 Перевод на карту +3 000,00 149 208,61',
    '28.08.2026 697663 Перевод от С. Надежда Никифоровна. Операция по карте',
    '****5393',
    'Продолжение на следующей странице',
    'Выписка по счёту дебетовой карты Страница 2 из 10',
    '28.08.2026 10:53 Прочие операции +18 641,33 123 372,61',
    '28.08.2026 225828 Заработная плата. Операция по карте ****5393',
  ];
  const sber = await p.evaluate(L => ww23PdfRowsFromLines(L), SBER);
  check('выписка Сбербанка распознана (4 операции)', sber.length === 4, sber.length);

  const sberMap = {};
  sber.forEach(r => { sberMap[r[1]] = r[2]; });
  check('взята сумма операции, а не остаток на счёте',
    sber.some(r => r[2] === '-749.00') && !sber.some(r => /133657/.test(r[2])), sber.map(r => r[2]));
  check('запятая как разделитель дробной части разобрана (2 128,00)',
    sber.some(r => r[2] === '-2128.00'), sber.map(r => r[2]));
  check('поступление со знаком + распознано', sber.some(r => r[2] === '+3000.00'), sber.map(r => r[2]));
  check('зарплата распознана как доход', sber.some(r => r[2] === '+18641.33'), sber.map(r => r[2]));
  check('служебный хвост «Операция по карте ****» вычищен',
    !Object.keys(sberMap).some(k => /Операция по карте/.test(k)), Object.keys(sberMap));
  check('перенос описания на следующую строку склеен',
    Object.keys(sberMap).some(k => /MAGNUM-VINOTEKA EKATERINBURG RUS/.test(k)), Object.keys(sberMap));
  check('собственная категория банка добавлена (помогает угадыванию)',
    Object.keys(sberMap).some(k => /· Супермаркеты/.test(k)), Object.keys(sberMap));
  check('строки «Продолжение» и «Страница N» не попали в операции',
    !Object.keys(sberMap).some(k => /Продолжение|Страница/.test(k)), Object.keys(sberMap));

  const sberDates = await p.evaluate(L => ww23PdfRowsFromLines(L).map(r => ww23ParseDate(r[0])), SBER);
  check('четырёхзначный год разобран верно (29.08.2026)', sberDates[0] === '2026-08-29', sberDates);

  // форматы не мешают друг другу
  const tin = await p.evaluate(L => ww23PdfRowsFromLines(L).length, LINES);
  check('выписка Тинькофф по-прежнему разбирается своим правилом', tin === 7, tin);

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));
  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})();
