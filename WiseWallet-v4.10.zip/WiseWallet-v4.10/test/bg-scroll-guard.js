/* Тесты v3.91: жёсткая JS-блокировка «резинового» эффекта фона на iOS.
   Симптом держался после двух прошлых CSS-исправлений (v3.86, v3.88) — это
   известное ограничение Safari, CSS сам по себе не всегда его гасит. Здесь
   проверяем сам механизм перехвата жеста, а не только CSS-классы. */
const { chromium } = require('playwright');
const path = require('path');
const FILE = 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

function fireInPage(selector, type, y) {
  const target = document.querySelector(selector) || document.body;
  const t = new Touch({ identifier: 1, target, clientX: 100, clientY: y });
  const ev = new TouchEvent(type, { touches: type === 'touchend' ? [] : [t], changedTouches: [t], bubbles: true, cancelable: true });
  target.dispatchEvent(ev);
  return ev.defaultPrevented;
}

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const ctx = await b.newContext({ viewport: { width: 430, height: 932 }, isMobile: true, hasTouch: true, deviceScaleFactor: 3 });
  const p = await ctx.newPage();
  const errors = [];
  p.on('pageerror', e => errors.push(e.message));
  p.on('console', m => { if (m.type() === 'error' && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text())) errors.push(m.text()); });
  await p.goto(FILE);
  await p.waitForTimeout(1600);
  await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
  await p.evaluate(() => {
    const long = Array.from({ length: 60 }, (_, i) => 'Строка ' + (i + 1) + ' с текстом.').join('\n');
    S.notes = [{ id: 'n1', body: long, folder: 'Заметки', updated: Date.now(), created: Date.now() }];
    S.links = [{ id: 'l1', title: 'Тест', category: 'Финансы', url: 'https://e.com', created: Date.now() }];
    save(); nav('links');
  });
  await p.waitForTimeout(400);

  const FIRE = fireInPage.toString();

  const idle = await p.evaluate((fireSrc) => {
    const fireInPage = new Function('return ' + fireSrc)();
    fireInPage('body', 'touchstart', 300);
    return fireInPage('body', 'touchmove', 250);
  }, FIRE);
  check('без открытого окна фон прокручивается свободно (нет лишней блокировки)', idle === false, idle);

  await p.evaluate(() => openLinkModal('l1'));
  await p.waitForTimeout(400);
  const short = await p.evaluate((fireSrc) => {
    const fireInPage = new Function('return ' + fireSrc)();
    const modal = document.getElementById('modal');
    const fits = modal.scrollHeight <= modal.clientHeight + 1;
    fireInPage('#modal', 'touchstart', 300);
    const prevented = fireInPage('#modal', 'touchmove', 250);
    return { fits, prevented };
  }, FIRE);
  check('короткая форма ссылки помещается целиком', short.fits === true, short);
  check('КЛЮЧЕВОЕ: движение по короткому окну блокируется (фон не сдвинется)', short.prevented === true, short);

  const bgWhileOpen = await p.evaluate((fireSrc) => {
    const fireInPage = new Function('return ' + fireSrc)();
    fireInPage('#page-links', 'touchstart', 300);
    return fireInPage('#page-links', 'touchmove', 250);
  }, FIRE);
  check('касание фона позади открытого окна блокируется', bgWhileOpen === true, bgWhileOpen);
  await p.evaluate(() => closeModal());
  await p.waitForTimeout(300);

  await p.evaluate(() => ww41Open('n1'));
  await p.waitForTimeout(400);
  const note = await p.evaluate((fireSrc) => {
    const fireInPage = new Function('return ' + fireSrc)();
    const ta = document.getElementById('ww41-body');

    ta.scrollTop = 200;
    fireInPage('#ww41-body', 'touchstart', 400);
    const middleOk = !fireInPage('#ww41-body', 'touchmove', 380);

    ta.scrollTop = 0;
    fireInPage('#ww41-body', 'touchstart', 300);
    const topBlocked = fireInPage('#ww41-body', 'touchmove', 400);

    ta.scrollTop = ta.scrollHeight;
    fireInPage('#ww41-body', 'touchstart', 400);
    const bottomBlocked = fireInPage('#ww41-body', 'touchmove', 300);

    return { middleOk, topBlocked, bottomBlocked };
  }, FIRE);
  check('обычная прокрутка внутри заметки НЕ блокируется', note.middleOk === true, note);
  check('отскок сверху (текст уже в начале) блокируется', note.topBlocked === true, note);
  check('отскок снизу (текст уже в конце) блокируется', note.bottomBlocked === true, note);

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));
  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})();
