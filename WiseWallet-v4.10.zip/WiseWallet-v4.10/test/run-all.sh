#!/bin/bash
# Единый прогон всех тестов: bash test/run-all.sh
cd "$(dirname "$0")/.." || exit 1
if [ ! -d node_modules/playwright ] && ! node -e "require('playwright')" 2>/dev/null; then
  echo "Устанавливаю playwright…"
  npm install --no-save playwright || exit 1
fi
exec node test/run-all.js "$@"
