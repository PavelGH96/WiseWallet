/* Тесты v3.62: компактное поле заметки + нижняя панель всегда внизу */
const { chromium } = require('playwright');
const FILE = process.env.WW_APP || 'file://' + require('path').resolve(__dirname, '../index.html');
const fails = [];
function check(name, cond, extra) {
  console.log((cond ? '  ok   ' : '  FAIL ') + name + (extra !== undefined ? '  -> ' + JSON.stringify(extra) : ''));
  if (!cond) fails.push(name);
}

const SESSION = { access_token: 'x.y.z', refresh_token: 'r', expires_at: Date.now() + 3600e3, user_id: '00000000-0000-4000-8000-000000000001', email: 't362@test.local' };

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  /* мобильный экран — нижняя панель видна только там */
  const ctx = await browser.newContext({ viewport: { width: 390, height: 780 }, isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text())) errors.push('CONSOLE: ' + m.text()); });

  await page.goto(FILE);
  await page.evaluate(s => localStorage.setItem('ww_session_v2', JSON.stringify(s)), SESSION);
  await page.goto(FILE);
  await page.waitForTimeout(1800);

  check('версия задана', /^\d+\.\d+$/.test(String(await page.evaluate(() => WW_VERSION))), await page.evaluate(() => WW_VERSION));
  check('нет битых символов', !(await page.evaluate(() => document.documentElement.innerHTML.indexOf('\uFFFD') !== -1)));

  /* ================= 1. Заметки: компактное поле ================= */
  const shortNote = await page.evaluate(async () => {
    S.notes = [];
    save();
    ww41New();
    await new Promise(r => setTimeout(r, 600));
    const ta = document.getElementById('ww41-body');
    if (!ta) return { found: false };
    const r = ta.getBoundingClientRect();
    return { found: true, h: Math.round(r.height), vh: window.innerHeight, share: +(r.height / window.innerHeight).toFixed(2) };
  });
  check('пустое поле заметки компактное (не полэкрана)',
    shortNote.found && shortNote.h >= 70 && shortNote.h <= 150, shortNote);

  const grow = await page.evaluate(async () => {
    const ta = document.getElementById('ww41-body');
    const h0 = Math.round(ta.getBoundingClientRect().height);
    ta.value = Array.from({ length: 6 }, (_, i) => 'Строка заметки номер ' + (i + 1)).join('\n');
    ta.dispatchEvent(new Event('input', { bubbles: true }));
    await new Promise(r => setTimeout(r, 200));
    const h1 = Math.round(ta.getBoundingClientRect().height);
    ta.value = Array.from({ length: 80 }, (_, i) => 'Очень длинная строка заметки номер ' + (i + 1)).join('\n');
    ta.dispatchEvent(new Event('input', { bubbles: true }));
    await new Promise(r => setTimeout(r, 250));
    const h2 = Math.round(ta.getBoundingClientRect().height);
    const ov = getComputedStyle(ta).overflowY;
    return { h0, h1, h2, vh: window.innerHeight, ov, cap: +(h2 / window.innerHeight).toFixed(2) };
  });
  check('поле растёт по тексту', grow.h1 > grow.h0, grow);
  check('рост ограничен и включается своя прокрутка',
    grow.h2 <= Math.round(grow.vh * 0.4) && grow.ov === 'auto', grow);

  const saved = await page.evaluate(async () => {
    const ta = document.getElementById('ww41-body');
    ta.value = 'Купить лампу\nДля бабушки';
    ta.dispatchEvent(new Event('input', { bubbles: true }));
    await new Promise(r => setTimeout(r, 700));
    ww41Done();
    await new Promise(r => setTimeout(r, 400));
    const n = (S.notes || [])[0] || {};
    return { body: n.body, count: (S.notes || []).length };
  });
  check('текст заметки сохраняется как раньше', /Купить лампу/.test(saved.body || ''), saved);

  const reopen = await page.evaluate(async () => {
    const id = (S.notes || [])[0].id;
    ww41Open(id);
    await new Promise(r => setTimeout(r, 600));
    const ta = document.getElementById('ww41-body');
    const h = Math.round(ta.getBoundingClientRect().height);
    const btn = Array.from(document.querySelectorAll('#overlay button, .modal button')).filter(b => /Готово/.test(b.textContent))[0];
    const bt = btn ? Math.round(btn.getBoundingClientRect().top) : null;
    ww41Done();
    await new Promise(r => setTimeout(r, 300));
    return { h, doneVisible: bt !== null && bt < window.innerHeight, doneTop: bt, vh: window.innerHeight };
  });
  check('при открытии заполненной заметки кнопка «Готово» в пределах экрана',
    reopen.h <= Math.round(reopen.vh * 0.4) && reopen.doneVisible, reopen);

  /* ================= 2. Нижняя панель ================= */
  const noShift = await page.evaluate(() => ({
    state: ww62NavState(),
    stubbed: !!(window.ww48PinBottomNav && window.ww48PinBottomNav.__ww62)
  }));
  check('старая компенсация сдвига отключена',
    noShift.stubbed && noShift.state && /none|matrix\(1, 0, 0, 1, 0, 0\)/.test(noShift.state.transform) && noShift.state.shift === '0px', noShift);

  /* прокрутка во всех разделах */
  const pagesList = ['dash', 'planner', 'ops', 'vault', 'settings', 'credits', 'goals'];
  const perPage = {};
  for (const p of pagesList) {
    const exists = await page.evaluate(async (pg) => {
      try { nav(pg); } catch (e) { return false; }
      await new Promise(r => setTimeout(r, 450));
      return true;
    }, p);
    if (!exists) continue;
    /* три разных положения прокрутки: верх, середина, низ */
    const gaps = [];
    for (const frac of [0, 0.5, 1]) {
      await page.evaluate(async (f) => {
        const max = Math.max(0, document.documentElement.scrollHeight - window.innerHeight);
        window.scrollTo(0, Math.round(max * f));
        await new Promise(r => setTimeout(r, 260));
      }, frac);
      const st = await page.evaluate(() => ww62NavState());
      gaps.push(st ? { gap: st.bottomGap, pos: st.position, hidden: st.hidden } : null);
    }
    /* и тач-прокрутка свайпом вверх */
    await page.mouse.move(200, 500);
    await page.mouse.wheel(0, 600);
    await page.waitForTimeout(300);
    const afterWheel = await page.evaluate(() => ww62NavState());
    perPage[p] = { gaps, afterWheel: afterWheel ? afterWheel.bottomGap : null };
  }
  const allPinned = Object.keys(perPage).every(k => {
    const v = perPage[k];
    return v.gaps.every(g => g && !g.hidden && g.pos === 'fixed' && Math.abs(g.gap) <= 1) && Math.abs(v.afterWheel) <= 1;
  });
  check('панель разделов прибита к низу во всех разделах и на любой прокрутке', allPinned, perPage);

  /* во вкладках раздела «Хранилище» */
  const vaultTabs = await page.evaluate(async () => {
    nav('vault');
    await new Promise(r => setTimeout(r, 400));
    const out = {};
    const tabs = (typeof WW40_TABS !== 'undefined' ? WW40_TABS : []).map(t => t.key || t);
    for (const t of tabs) {
      try { ww40Tab(t); } catch (e) { continue; }
      await new Promise(r => setTimeout(r, 320));
      const max = Math.max(0, document.documentElement.scrollHeight - window.innerHeight);
      window.scrollTo(0, Math.round(max * 0.6));
      await new Promise(r => setTimeout(r, 260));
      const st = ww62NavState();
      out[t] = st ? st.bottomGap : null;
    }
    return out;
  });
  const tabKeys = Object.keys(vaultTabs);
  check('во всех вкладках Хранилища панель тоже внизу',
    tabKeys.length > 0 && tabKeys.every(k => Math.abs(vaultTabs[k]) <= 1), vaultTabs);

  /* планировщик: горизонтальный свайп по колонкам не сбивает панель */
  const plannerScroll = await page.evaluate(async () => {
    nav('planner');
    await new Promise(r => setTimeout(r, 450));
    S.tasks = Array.from({ length: 14 }, (_, i) => ({ id: 'p' + i, text: 'Задача ' + (i + 1), who: 'me', date: todayStr(), prio: 'mid', done: false, created: Date.now() }));
    save();
    renderPlanner();
    await new Promise(r => setTimeout(r, 400));
    const kb = document.getElementById('kanban');
    if (kb) { kb.scrollLeft = 400; kb.dispatchEvent(new Event('scroll')); }
    const max = Math.max(0, document.documentElement.scrollHeight - window.innerHeight);
    const res = [];
    for (const y of [0, Math.round(max / 2), max]) {
      window.scrollTo(0, y);
      await new Promise(r => setTimeout(r, 260));
      const st = ww62NavState();
      res.push({ y, gap: st.bottomGap, pos: st.position });
    }
    return { res, max, tasks: S.tasks.length };
  });
  check('в планировщике с длинным списком панель не уезжает вверх',
    plannerScroll.max > 100 && plannerScroll.res.every(r => Math.abs(r.gap) <= 1 && r.pos === 'fixed'), plannerScroll);

  /* панель перекрывает контент? проверяем отступ снизу */
  const bottomRoom = await page.evaluate(async () => {
    const max = Math.max(0, document.documentElement.scrollHeight - window.innerHeight);
    window.scrollTo(0, max);
    await new Promise(r => setTimeout(r, 300));
    const navEl = document.querySelector('.bottom-nav');
    const nr = navEl.getBoundingClientRect();
    const cards = Array.from(document.querySelectorAll('#kanban .task-card, .ww58-card'));
    const last = cards[cards.length - 1];
    return { navTop: Math.round(nr.top), lastBottom: last ? Math.round(last.getBoundingClientRect().bottom) : null, cards: cards.length };
  });
  check('последнюю карточку не закрывает панель',
    bottomRoom.lastBottom === null || bottomRoom.lastBottom <= bottomRoom.navTop + 2, bottomRoom);

  /* клавиатура: при сжатом visualViewport панель не висит посередине */
  const kb = await page.evaluate(async () => {
    document.body.classList.add('ww62-kb');
    await new Promise(r => setTimeout(r, 120));
    const hidden = getComputedStyle(document.querySelector('.bottom-nav')).display === 'none';
    document.body.classList.remove('ww62-kb');
    await new Promise(r => setTimeout(r, 120));
    const back = getComputedStyle(document.querySelector('.bottom-nav')).display !== 'none';
    return { hidden, back };
  });
  check('при открытой клавиатуре панель прячется и возвращается', kb.hidden && kb.back, kb);

  /* на ПК панели нет — левое меню, ничего не сломалось */
  const desk = await ctx.browser().newContext({ viewport: { width: 1280, height: 900 } });
  const dp = await desk.newPage();
  await dp.goto(FILE);
  await dp.evaluate(s => localStorage.setItem('ww_session_v2', JSON.stringify(s)), SESSION);
  await dp.goto(FILE);
  await dp.waitForTimeout(1600);
  const deskState = await dp.evaluate(async () => {
    nav('planner');
    await new Promise(r => setTimeout(r, 400));
    window.scrollTo(0, 300);
    await new Promise(r => setTimeout(r, 250));
    const navEl = document.querySelector('.bottom-nav');
    const cs = navEl ? getComputedStyle(navEl) : null;
    return { display: cs ? cs.display : null, rail: !!document.querySelector('.rail'), err: false };
  });
  await desk.close();
  check('на ПК нижняя панель скрыта, боковое меню на месте',
    deskState.rail && deskState.display === 'none', deskState);

  /* после открытия/закрытия окна панель на месте */
  const afterModal = await page.evaluate(async () => {
    nav('planner');
    await new Promise(r => setTimeout(r, 350));
    openTaskModal('', 'today');
    await new Promise(r => setTimeout(r, 500));
    closeModal();
    await new Promise(r => setTimeout(r, 400));
    window.scrollTo(0, 250);
    await new Promise(r => setTimeout(r, 260));
    return ww62NavState();
  });
  check('после закрытия окна панель остаётся внизу',
    afterModal && Math.abs(afterModal.bottomGap) <= 1 && !afterModal.hidden, afterModal);

  console.log('\nERRORS', JSON.stringify(errors));
  if (errors.length) fails.push('ошибки в консоли');
  await browser.close();
  console.log(fails.length ? '\nПРОВАЛЫ: ' + JSON.stringify(fails) : '\nВсе проверки прошли');
  process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
