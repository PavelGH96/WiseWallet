/* Тест v4.02: даты берутся по МЕСТНОМУ времени, а не по UTC.

   Регрессия, которую он ловит: todayStr() был
   `new Date().toISOString().slice(0,10)`, то есть возвращал UTC-дату.
   В поясах восточнее Гринвича (Екатеринбург — UTC+5) с 00:00 до 05:00
   по местному времени это давало ВЧЕРАШНЮЮ дату: ночная операция
   попадала во вчера, а в ночь на 1-е число — в прошлый месяц, мимо
   всей текущей отчётности.

   Берём UTC-момент 2026-09-14T21:30:00Z и смотрим в разных поясах:
   местная дата и todayStr() обязаны совпадать. */
const { chromium } = require('playwright');
const path = require('path');
const FILE = process.env.WW_APP || 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

const INSTANT = Date.UTC(2026, 8, 14, 21, 30);
/* Екатеринбург и Камчатка на этот момент уже в 15-м числе, остальные ещё в 14-м —
   то есть проверяются обе стороны от Гринвича. */
const ZONES = ['Asia/Yekaterinburg', 'Asia/Kamchatka', 'Europe/Berlin', 'America/New_York', 'Pacific/Honolulu'];

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const errors = [];

  for (const tz of ZONES) {
    const p = await (await b.newContext({ timezoneId: tz, viewport: { width: 1280, height: 900 } })).newPage();
    p.on('pageerror', e => errors.push(tz + ': ' + e.message));
    await p.addInitScript((t) => {
      const RealDate = Date;
      const F = function (...a) { return a.length ? new RealDate(...a) : new RealDate(t); };
      F.prototype = RealDate.prototype;
      F.now = () => t;
      F.UTC = RealDate.UTC; F.parse = RealDate.parse;
      window.Date = F;
    }, INSTANT);
    await p.goto(FILE);
    await p.waitForTimeout(1500);

    const r = await p.evaluate(() => {
      const d = new Date();
      const local = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
      return {
        local,
        todayStr: todayStr(),
        ymdLocal: ymdLocal(new Date()),
        dayOff0: dayOff(0),
        dayOff1: dayOff(1),
      };
    });
    check('todayStr() = местная дата в ' + tz, r.todayStr === r.local, r);
    check('ymdLocal() = местная дата в ' + tz, r.ymdLocal === r.local, r.ymdLocal);
    check('dayOff(0) = сегодня в ' + tz, r.dayOff0 === r.local, r.dayOff0);
    await p.context().close();
  }

  /* Новая операция без явной даты должна датироваться сегодняшним МЕСТНЫМ днём */
  const p2 = await (await b.newContext({ timezoneId: 'Asia/Yekaterinburg', viewport: { width: 1280, height: 900 } })).newPage();
  p2.on('pageerror', e => errors.push('tx: ' + e.message));
  await p2.addInitScript((t) => {
    const RealDate = Date;
    const F = function (...a) { return a.length ? new RealDate(...a) : new RealDate(t); };
    F.prototype = RealDate.prototype; F.now = () => t; F.UTC = RealDate.UTC; F.parse = RealDate.parse;
    window.Date = F;
  }, INSTANT);
  await p2.goto(FILE);
  await p2.waitForTimeout(1500);
  await p2.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
  const dflt = await p2.evaluate(() => {
    const d = new Date();
    const local = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    return { local, month: local.slice(0, 7), todayStr: todayStr() };
  });
  check('КЛЮЧЕВОЕ: ночью в Екатеринбурге «сегодня» — это уже новые сутки, а не вчера',
    dflt.todayStr === dflt.local && dflt.todayStr === '2026-09-15', dflt);
  check('и, значит, месяц отчётности тоже правильный', dflt.todayStr.slice(0, 7) === dflt.month, dflt.month);

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));
  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
