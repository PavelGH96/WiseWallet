const { chromium } = require('playwright');
const FILE = process.env.WW_APP || 'file://' + require('path').resolve(__dirname, '../index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

const SESSION = { access_token: 'aaa.bbb.ccc', refresh_token: 'rrr', expires_in: 3600, token_type: 'bearer', user: { id: '00000000-0000-4000-8000-000000000001', email: 'me@example.com' } };

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 860 } });
  const page = await ctx.newPage();
  const errors = [];
  const calls = [];
  page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text())) errors.push('CONSOLE: ' + m.text()); });

  let mailBroken = true;
  await ctx.route(/supabase\.co/, async route => {
    const req = route.request();
    const url = req.url();
    calls.push(req.method() + ' ' + url.replace(/^https:\/\/[^/]+/, '') + (req.postData() ? ' ' + req.postData() : ''));
    const CORS = {
      'access-control-allow-origin': '*',
      'access-control-allow-methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS',
      'access-control-allow-headers': '*',
      'access-control-max-age': '86400',
    };
    const json = (status, body) => route.fulfill({ status, contentType: 'application/json', headers: CORS, body: JSON.stringify(body) });
    if (req.method() === 'OPTIONS') return route.fulfill({ status: 204, headers: CORS, body: '' });
    if (/\/auth\/v1\/recover/.test(url)) {
      return mailBroken ? json(500, { msg: 'Error sending recovery email' }) : json(200, {});
    }
    if (/\/auth\/v1\/otp/.test(url)) return json(200, {});
    if (/\/auth\/v1\/verify/.test(url)) {
      const body = JSON.parse(req.postData() || '{}');
      if (body.type !== 'recovery') return json(400, { msg: 'Invalid token' });
      if (body.token && body.token !== '654321') return json(400, { msg: 'Token has expired' });
      return json(200, SESSION);
    }
    if (/\/auth\/v1\/user/.test(url)) return json(200, { id: SESSION.user.id, email: SESSION.user.email });
    if (/grant_type=password/.test(url)) return json(200, SESSION);
    if (/\/rest\/v1\//.test(url)) return json(200, []);
    return json(200, {});
  });

  await page.goto(FILE);
  await page.evaluate(() => { localStorage.removeItem('ww_session_v2'); });
  await page.goto(FILE);
  await page.waitForTimeout(2000);

  check('версия приложения задана', /^\d+\.\d+$/.test(await page.evaluate(() => WW_VERSION)));
  check('экран входа показан', await page.evaluate(() => { const g = document.getElementById('ww332-gate'); return !!g && g.classList.contains('on'); }));

  // разбор вставленного
  const parsed = await page.evaluate(() => ({
    code: ww56ParsePasted('654321'),
    link: ww56ParsePasted('https://app.local/#access_token=zzz&type=recovery'),
    hashLink: ww56ParsePasted('https://xxx.supabase.co/auth/v1/verify?token_hash=pkce_abc&type=recovery'),
    err: ww56ParsePasted('https://app.local/#error_description=Email+link+is+invalid+or+has+expired'),
    empty: ww56ParsePasted('  ')
  }));
  check('распознаёт код, ссылку и ошибку из письма',
    parsed.code.kind === 'otp' && parsed.link.kind === 'session' && parsed.hashLink.kind === 'hash' && parsed.err.kind === 'error' && parsed.empty === null, parsed);

  // открытие экрана восстановления по ссылке «Забыли пароль?»
  await page.evaluate(() => { document.getElementById('ww332-email').value = 'me@example.com'; document.getElementById('ww332-forgot').click(); });
  await page.waitForTimeout(400);
  const opened = await page.evaluate(() => ({
    mode: document.getElementById('ww332-gate').classList.contains('ww56-mode'),
    visible: !!document.getElementById('ww56-rec') && getComputedStyle(document.getElementById('ww56-rec')).display !== 'none',
    loginHidden: getComputedStyle(document.getElementById('ww332-go')).display === 'none',
    email: document.getElementById('ww56-email').value
  }));
  check('«Забыли пароль?» открывает экран восстановления с подставленным email',
    opened.mode && opened.visible && opened.loginHidden && opened.email === 'me@example.com', opened);

  // сбой отправки письма теперь виден
  await page.click('#ww56-send');
  await page.waitForTimeout(600);
  const failMsg = await page.evaluate(() => ({ msg: document.getElementById('ww56-msg').textContent, ok: document.getElementById('ww56-msg').classList.contains('ok'), help: document.getElementById('ww56-help').open }));
  check('ошибка отправки показана честно (а не «письмо отправлено»)',
    !failMsg.ok && /не смог отправить письмо/i.test(failMsg.msg) && failMsg.help === true, failMsg);
  check('в recover передаётся redirect_to на адрес приложения', calls.some(c => /POST \/auth\/v1\/recover\?redirect_to=/.test(c)), calls.filter(c => /recover/.test(c)));

  // успешная отправка
  mailBroken = false;
  await page.click('#ww56-send');
  await page.waitForTimeout(600);
  const okMsg = await page.evaluate(() => ({ msg: document.getElementById('ww56-msg').textContent, ok: document.getElementById('ww56-msg').classList.contains('ok') }));
  check('при успехе объясняет, что делать с кодом', okMsg.ok && /Спам/i.test(okMsg.msg), okMsg);

  // код для входа (OTP)
  await page.click('#ww56-otp');
  await page.waitForTimeout(500);
  check('кнопка «Код для входа» вызывает /otp', calls.some(c => /POST \/auth\/v1\/otp/.test(c)));

  // устаревший код → понятная ошибка
  await page.fill('#ww56-code', '111111');
  await page.fill('#ww56-pass', 'newpass123');
  await page.click('#ww56-apply');
  await page.waitForTimeout(700);
  const expired = await page.evaluate(() => document.getElementById('ww56-msg').textContent);
  check('устаревший код объясняется по-русски', /устарел|не подход/i.test(expired), expired);

  // короткий пароль
  await page.fill('#ww56-code', '654321');
  await page.fill('#ww56-pass', '123');
  await page.click('#ww56-apply');
  await page.waitForTimeout(300);
  check('короткий пароль отклоняется', /минимум 6/i.test(await page.evaluate(() => document.getElementById('ww56-msg').textContent)));

  // рабочая смена пароля
  await page.fill('#ww56-pass', 'newpass123');
  await page.click('#ww56-apply');
  await page.waitForTimeout(1800);
  const after = await page.evaluate(() => ({
    put: null,
    gateOn: document.getElementById('ww332-gate').classList.contains('on'),
    mode: document.getElementById('ww332-gate').classList.contains('ww56-mode'),
    sess: !!localStorage.getItem('ww_session_v2')
  }));
  const putCall = calls.find(c => c.startsWith('PUT /auth/v1/user'));
  check('пароль сохраняется через PUT /user с новым значением', !!putCall && /newpass123/.test(putCall), putCall);
  check('после смены пароля выполняется вход', calls.some(c => /grant_type=password/.test(c)) && after.sess, after);
  check('экран входа закрыт, приложение открыто', after.gateOn === false && after.mode === false, after);

  // вход сразу по ссылке из письма
  await page.evaluate(() => localStorage.removeItem('ww_session_v2'));
  await page.goto('about:blank');
  await page.goto(FILE + '#access_token=zzz&type=recovery&expires_in=3600');
  await page.waitForTimeout(2200);
  const auto = await page.evaluate(() => ({
    mode: document.getElementById('ww332-gate').classList.contains('ww56-mode'),
    code: (document.getElementById('ww56-code') || {}).value,
    msg: (document.getElementById('ww56-msg') || {}).textContent
  }));
  check('открытие по ссылке из письма сразу ведёт к смене пароля',
    auto.mode === true && auto.code === 'zzz' && /распознана/i.test(auto.msg || ''), auto);

  // кнопка «Назад ко входу»
  await page.click('#ww56-back');
  await page.waitForTimeout(300);
  check('кнопка «Назад ко входу» возвращает форму входа',
    await page.evaluate(() => !document.getElementById('ww332-gate').classList.contains('ww56-mode') && getComputedStyle(document.getElementById('ww332-go')).display !== 'none'));

  console.log('\nCALLS', JSON.stringify(calls.map(c => c.split(' ').slice(0, 2).join(' ')), null, 0));
  console.log('ERRORS', JSON.stringify(errors));
  if (errors.length) fails.push('ошибки в консоли');
  await browser.close();
  console.log(fails.length ? '\nПРОВАЛЫ: ' + JSON.stringify(fails) : '\nВсе проверки прошли');
  process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
