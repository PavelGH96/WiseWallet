/* Тесты v4.05: анимация графиков при появлении на экране.

   Предыстория: кольцевая диаграмма анимировалась и раньше, но на дашборде
   её карточка лежит внизу длинной страницы — пока пользователь доскроллит,
   550 мс проходят, и анимация отыгрывает вхолостую. Замер это подтвердил.
   Поэтому анимация теперь привязана не к моменту отрисовки, а к моменту,
   когда холст реально попал в поле зрения.

   Проверяем: (1) до появления холст не «дорисован», (2) при появлении
   картинка нарастает, (3) в конце совпадает с обычной отрисовкой,
   (4) после завершения не остаётся крутящихся кадров (нагрузка),
   (5) при prefers-reduced-motion сразу конечный кадр. */
const { chromium } = require('playwright');
const path = require('path');
const FILE = process.env.WW_APP || 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

const SEED = () => {
  S.categories = S.categories.filter(c => c.type === 'income').concat([
    { id: 'e1', name: 'Кредиты', type: 'expense', icon: '🏦' }, { id: 'e2', name: 'Катя', type: 'expense', icon: '💛' },
    { id: 'e3', name: 'Быт', type: 'expense', icon: '🛒' }, { id: 'e4', name: 'Кафе', type: 'expense', icon: '☕' }]);
  const acc = (S.accounts[0] || {}).id || 'a1'; S.transactions = [];
  for (let m = 0; m < 6; m++) {
    const d = new Date(); d.setMonth(d.getMonth() - m); d.setDate(10);
    [['e1', 112067], ['e2', 59050], ['e3', 9700], ['e4', 8950]].forEach(([c, a]) =>
      S.transactions.push({ id: uid(), type: 'expense', categoryId: c, amount: a, date: ymdLocal(d), accountId: acc, whose: 'me', tags: [] }));
    S.transactions.push({ id: uid(), type: 'income', categoryId: (S.categories.find(c => c.type === 'income') || {}).id, amount: 250000, date: ymdLocal(d), accountId: acc, tags: [] });
  }
  save();
};
/* доля непрозрачных пикселей — простой и устойчивый показатель «сколько нарисовано» */
const ink = (p, id) => p.evaluate((cid) => {
  const cv = document.getElementById(cid); if (!cv) return null;
  const d = cv.getContext('2d').getImageData(0, 0, cv.width, cv.height).data;
  let n = 0; for (let i = 3; i < d.length; i += 4) if (d[i] > 10) n++;
  return n;
}, id);

async function openClean(p) {
  await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
}

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const ctx = await b.newContext({ viewport: { width: 1400, height: 950 } });
  const p = await ctx.newPage();
  const errors = [];
  p.on('pageerror', e => errors.push(e.message));
  await p.goto(FILE); await p.waitForTimeout(1600);
  await openClean(p);
  await p.evaluate(SEED);

  /* ---- графики, которые лежат ниже сгиба ---- */
  for (const [page, id, name] of [
    ['dashboard', 'dash-donut', 'кольцо на дашборде'],
    ['analytics', 'ww23-an-trend', 'динамика категорий'],
  ]) {
    await p.evaluate((pg) => { window.scrollTo(0, 0); nav(pg); }, page);
    await p.waitForTimeout(150);
    await p.evaluate(() => window.scrollTo(0, 0));
    await p.waitForTimeout(600);

    const before = await ink(p, id);
    await p.evaluate((cid) => document.getElementById(cid).scrollIntoView({ block: 'center' }), id);
    const s = [];
    for (let t = 0; t < 10; t++) { await p.waitForTimeout(60); s.push(await ink(p, id)); }
    const grew = Math.max(...s) > Math.max(before, 1) * 1.3;
    const rising = s[0] < s[s.length - 1];
    check('КЛЮЧЕВОЕ: ' + name + ' ждёт появления, а не рисуется вхолостую', before < Math.max(...s) * 0.5, { before, max: Math.max(...s) });
    check(name + ' анимируется при попадании на экран', grew && rising, s.slice(0, 5));
  }

  /* ---- графики вверху страницы: анимируются сразу ---- */
  await p.evaluate(() => { window.scrollTo(0, 0); nav('analytics'); });
  const top = { 'chart-donut': [], 'chart-plan': [] };
  for (let t = 0; t < 10; t++) { await p.waitForTimeout(55); for (const k of Object.keys(top)) top[k].push(await ink(p, k)); }
  for (const [id, name] of [['chart-donut', 'кольцо в аналитике'], ['chart-plan', 'плановая нагрузка']]) {
    const s = top[id].filter(v => v !== null);
    check(name + ' анимируется сразу при открытии раздела', s.length > 2 && Math.max(...s) > Math.min(...s) * 1.15, s.slice(0, 5));
  }

  /* ---- нагрузка: после завершения не должно остаться работающих кадров ---- */
  await p.waitForTimeout(900);
  const idle = await p.evaluate(async () => {
    let frames = 0; let stop = false;
    const tick = () => { if (!stop) { frames++; requestAnimationFrame(tick); } };
    requestAnimationFrame(tick);
    const before = performance.now();
    await new Promise(r => setTimeout(r, 500));
    stop = true;
    const canvases = ['chart-donut', 'chart-plan', 'ww23-an-trend', 'chart-flow']
      .map(id => document.getElementById(id)).filter(Boolean);
    return { pendingRaf: canvases.filter(c => c._ww405raf).length, pendingDonut: canvases.filter(c => c._donutAnim).length };
  });
  check('КЛЮЧЕВОЕ: после анимации не остаётся работающих кадров (нет фоновой нагрузки)',
    idle.pendingRaf === 0 && idle.pendingDonut === 0, idle);

  /* ---- итоговая картинка совпадает с обычной отрисовкой ---- */
  const finalOk = await p.evaluate(async () => {
    const cv = document.getElementById('chart-plan');
    const a = cv.toDataURL();
    renderAnalytics();
    await new Promise(r => setTimeout(r, 1200));
    return { same: cv.toDataURL() === a };
  });
  check('после повторной отрисовки картинка та же (анимация ничего не теряет)', finalOk.same === true, finalOk);

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));
  await ctx.close();

  /* ---- prefers-reduced-motion: сразу конечный кадр, без анимации ---- */
  const ctx2 = await b.newContext({ viewport: { width: 1400, height: 950 }, reducedMotion: 'reduce' });
  const p2 = await ctx2.newPage();
  p2.on('pageerror', e => errors.push('rm: ' + e.message));
  await p2.goto(FILE); await p2.waitForTimeout(1600);
  await openClean(p2);
  await p2.evaluate(SEED);
  await p2.evaluate(() => { window.scrollTo(0, 0); nav('analytics'); });
  await p2.waitForTimeout(120);
  const rm = [];
  for (let t = 0; t < 4; t++) { await p2.waitForTimeout(50); rm.push(await ink(p2, 'chart-plan')); }
  check('при prefers-reduced-motion график сразу целиком, без нарастания',
    rm[0] > 0 && Math.max(...rm) <= rm[0] * 1.02, rm);

  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
