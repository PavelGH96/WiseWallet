const path=require("path");
const {chromium}=require("playwright");
const FILE = process.env.WW_APP || 'file://' + require('path').resolve(__dirname, '../index.html');
const SESSION={access_token:"smoke.jwt.token",refresh_token:"smoke.refresh",expires_at:Date.now()+3600e3,user_id:"00000000-0000-4000-8000-000000000001",email:"smoke@example.com"};
(async()=>{
 const browser=await chromium.launch({executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium',args:["--no-sandbox"]});
 const errors=[];
 const c=await browser.newContext({viewport:{width:390,height:844},hasTouch:true,isMobile:true,deviceScaleFactor:2});
 const p=await c.newPage();
 p.on("pageerror",e=>errors.push("PAGEERROR: "+e.message));
 p.on("console",m=>{if(m.type()==="error"&&!/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text()))errors.push("CONSOLE: "+m.text())});
 await p.goto(FILE);await p.evaluate(s=>localStorage.setItem("ww_session_v2",JSON.stringify(s)),SESSION);await p.reload();await p.waitForTimeout(1700);
 await p.evaluate(()=>{
  const now=Date.now();S.tasks=[];
  for(let i=0;i<48;i++)S.tasks.push({id:"long"+i,text:"Длинная задача планировщика "+(i+1),who:"me",date:i<16?todayStr():i<32?dayOff(3):dayOff(14),prio:i%3===0?"high":"mid",done:false,created:now+i});
  S.settings.viewMode=S.settings.viewMode||{};S.settings.viewMode.planner="list";save();nav("planner");
 });
 await p.waitForTimeout(700);
 const measure=()=>p.evaluate(()=>{const n=document.querySelector(".bottom-nav"),r=n.getBoundingClientRect(),vv=window.visualViewport;const target=vv?vv.offsetTop+vv.height:innerHeight;return{scrollY:Math.round(scrollY),docH:document.documentElement.scrollHeight,innerH:innerHeight,vvH:vv&&Math.round(vv.height),vvTop:vv&&Math.round(vv.offsetTop),top:Math.round(r.top),bottom:Math.round(r.bottom),height:Math.round(r.height),gap:Math.round(target-r.bottom),position:getComputedStyle(n).position,cssBottom:getComputedStyle(n).bottom,shift:getComputedStyle(document.documentElement).getPropertyValue("--ww48-shift").trim(),parent:n.parentElement.tagName,pinned:n.dataset.ww48Pinned,bodyFixed:document.body.classList.contains("no-scroll")};});
 const points=[];
 for(const y of [0,350,900,1800,99999]){await p.evaluate(y=>scrollTo(0,y),y);await p.waitForTimeout(220);points.push(await measure());}
 console.log("SCROLL_POINTS",JSON.stringify(points,null,1));

 // Имитируем именно дефект WebView: fixed превратился в absolute и панель уехала.
 const recovery=await p.evaluate(async()=>{const wait=ms=>new Promise(r=>setTimeout(r,ms));const n=document.querySelector(".bottom-nav");n.style.setProperty("position","absolute","important");n.style.setProperty("top","120px","important");n.style.setProperty("bottom","auto","important");document.documentElement.style.setProperty("--ww48-shift","-220px");await wait(80);const broken=n.getBoundingClientRect();window.dispatchEvent(new Event("scroll"));await wait(180);const fixed=n.getBoundingClientRect(),vv=visualViewport;return{brokenTop:Math.round(broken.top),brokenBottom:Math.round(broken.bottom),fixedTop:Math.round(fixed.top),fixedBottom:Math.round(fixed.bottom),target:Math.round(vv.offsetTop+vv.height),gap:Math.round(vv.offsetTop+vv.height-fixed.bottom),position:getComputedStyle(n).position,inlinePosition:n.style.getPropertyValue("position"),inlinePriority:n.style.getPropertyPriority("position")};});
 console.log("RECOVERY",JSON.stringify(recovery));

 // Открытие/закрытие формы задачи не должно оставлять body fixed и сдвигать навигацию.
 await p.evaluate(()=>{scrollTo(0,1000);openTaskModal();});await p.waitForTimeout(350);
 const modal=await p.evaluate(()=>({bodyFixed:document.body.classList.contains("no-scroll"),navBottom:Math.round(document.querySelector(".bottom-nav").getBoundingClientRect().bottom),vvBottom:Math.round(visualViewport.offsetTop+visualViewport.height)}));
 await p.evaluate(()=>closeModal());await p.waitForTimeout(350);
 const afterModal=await measure();
 console.log("MODAL",JSON.stringify({open:modal,closed:afterModal}));

 // Изменение visual viewport / поворот экрана.
 await p.setViewportSize({width:390,height:620});await p.waitForTimeout(450);
 const resized=await measure();console.log("RESIZED",JSON.stringify(resized));
 await p.screenshot({path:"/data/a348-planner-bottom.png"});

 // Вернуть высокий экран и проверить динамическую перестройку нижнего меню.
 await p.setViewportSize({width:390,height:844});await p.waitForTimeout(350);
 await p.evaluate(()=>{S.settings.navOrder=["planner","dashboard","ops","credits","calendar","vault","analytics","settings"];save();ww40ApplyOrder();ww48PinBottomNav();});await p.waitForTimeout(300);
 console.log("REORDER",JSON.stringify(Object.assign(await measure(),await p.evaluate(()=>({items:[].map.call(document.querySelectorAll(".bottom-nav [data-nav]"),x=>x.dataset.nav),active:(document.querySelector(".bottom-nav .active")||{}).dataset&&document.querySelector(".bottom-nav .active").dataset.nav,noHScroll:document.documentElement.scrollWidth<=document.documentElement.clientWidth,version:WW_VERSION})))));
 console.log("ERRORS",JSON.stringify(errors));
 await c.close();await browser.close();
})();
