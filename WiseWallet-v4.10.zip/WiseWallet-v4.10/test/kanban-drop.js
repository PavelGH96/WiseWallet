/* Тест v4.09: задача переносится в любое место колонки.

   Регрессия, которую он ловит: обработчики dragover/drop висели на .kb-cards,
   а её высота равна содержимому. Ниже последней карточки — на кнопке
   «＋ Добавить задачу» и в пустом месте под ней — перенос не принимался,
   задача возвращалась назад. Особенно мешало у пустых колонок, где список
   занимает считанные пиксели.

   Проверяем перенос в четыре точки колонки: верх, середину, кнопку
   «Добавить задачу» и самый низ. */
const { chromium } = require('playwright');
const path = require('path');
const FILE = process.env.WW_APP || 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

const seed = () => {
  S.tasks = [
    { id: 'k1', text: 'Прикрутить полку', who: 'me', date: todayStr(), prio: 'mid', done: false, created: Date.now() },
    { id: 'k2', text: 'Купить молоко', who: 'me', date: todayStr(), prio: 'low', done: false, created: Date.now() },
  ];
  save(); nav('planner');
};

/* HTML5 drag-and-drop не воспроизводится мышью в Playwright, поэтому шлём
   события напрямую — ровно те, что шлёт браузер, с общим dataTransfer. */
async function dragTaskTo(p, taskId, colKey, where) {
  return p.evaluate(({ taskId, colKey, where }) => {
    const card = document.querySelector('#kanban .task-card[data-id="' + taskId + '"]');
    /* Колонку ищем способом, работающим и на старой разметке (обработчик на
       .kb-cards), и на новой (data-col на самой колонке) — иначе тест падал бы
       на отсутствии атрибута, а не на отказе принять перенос, и ничего бы не
       доказывал. */
    let col = document.querySelector('#kanban .kb-col[data-col="' + colKey + '"]');
    if (!col) {
      col = [...document.querySelectorAll('#kanban .kb-col')].find((c) => {
        const box = c.querySelector('.kb-cards');
        return box && (box.getAttribute('ondrop') || '').indexOf("'" + colKey + "'") >= 0;
      }) || null;
    }
    if (!card || !col) return { err: 'не найдено', card: !!card, col: !!col };
    const r = col.getBoundingClientRect();
    let x = Math.round(r.left + r.width / 2), y;
    if (where === 'top') y = Math.round(r.top + 12);
    else if (where === 'middle') y = Math.round(r.top + r.height / 2);
    else if (where === 'addbtn') {
      const b = col.querySelector('.kb-add').getBoundingClientRect();
      x = Math.round(b.left + b.width / 2); y = Math.round(b.top + b.height / 2);
    } else y = Math.round(r.bottom - 4);

    const dt = new DataTransfer();
    card.dispatchEvent(new DragEvent('dragstart', { bubbles: true, dataTransfer: dt }));
    const target = document.elementFromPoint(x, y) || col;
    const opts = { bubbles: true, cancelable: true, dataTransfer: dt, clientX: x, clientY: y };
    target.dispatchEvent(new DragEvent('dragenter', opts));
    const over = new DragEvent('dragover', opts);
    target.dispatchEvent(over);
    const accepted = over.defaultPrevented;   // preventDefault = «сюда можно бросить»
    target.dispatchEvent(new DragEvent('drop', opts));
    card.dispatchEvent(new DragEvent('dragend', { bubbles: true, dataTransfer: dt }));
    return { accepted, targetCls: (target.className || '').toString().slice(0, 24) };
  }, { taskId, colKey, where });
}

const dateOf = (p, id) => p.evaluate((tid) => (S.tasks.find(t => t.id === tid) || {}).date, id);

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const p = await (await b.newContext({ viewport: { width: 1500, height: 950 } })).newPage();
  const errors = [];
  p.on('pageerror', e => errors.push(e.message));
  await p.goto(FILE); await p.waitForTimeout(1600);
  await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
  await p.evaluate(seed);
  await p.waitForTimeout(700);

  const tomorrow = await p.evaluate(() => dayOff(1));

  for (const where of ['top', 'middle', 'addbtn', 'bottom']) {
    /* каждый раз возвращаем задачу в «Сегодня», чтобы проверки были независимы */
    await p.evaluate(() => { S.tasks.find(t => t.id === 'k1').date = todayStr(); save(); renderPlanner(); });
    await p.waitForTimeout(400);

    const res = await dragTaskTo(p, 'k1', 'tomorrow', where);
    await p.waitForTimeout(400);
    const d = await dateOf(p, 'k1');
    const label = { top: 'вверху колонки', middle: 'в середине', addbtn: 'на кнопке «Добавить задачу»', bottom: 'у самого низа' }[where];
    check('КЛЮЧЕВОЕ: колонка принимает перенос ' + label, res.accepted === true, res);
    check('задача действительно переехала (' + label + ')', d === tomorrow, { got: d, want: tomorrow });
  }

  /* перенос в пустую колонку — там раньше было почти некуда попасть */
  await p.evaluate(() => { S.tasks.forEach(t => { t.date = todayStr(); }); save(); renderPlanner(); });
  await p.waitForTimeout(400);
  const emptyCol = await p.evaluate(() => {
    const cols = [...document.querySelectorAll('#kanban .kb-col')];
    const c = cols.find(x => x.querySelector('.kb-cards .empty'));
    if (!c) return null;
    let key = c.dataset.col;
    if (!key) {
      const m = (c.querySelector('.kb-cards').getAttribute('ondrop') || '').match(/taskDrop\(event,'([^']+)'\)/);
      key = m ? m[1] : null;
    }
    return { key, h: Math.round(c.getBoundingClientRect().height) };
  });
  check('у пустой колонки есть заметная зона приёма', emptyCol && emptyCol.h >= 140, emptyCol);
  if (emptyCol) {
    const res = await dragTaskTo(p, 'k2', emptyCol.key, 'bottom');
    await p.waitForTimeout(400);
    check('КЛЮЧЕВОЕ: в пустую колонку можно бросить у самого низа', res.accepted === true, res);
  }

  /* подсветка: появляется при наведении и снимается после переноса */
  const hl = await p.evaluate(() => {
    const col = document.querySelector('#kanban .kb-col[data-col="tomorrow"]');
    const card = document.querySelector('#kanban .task-card');
    const dt = new DataTransfer();
    card.dispatchEvent(new DragEvent('dragstart', { bubbles: true, dataTransfer: dt }));
    const r = col.getBoundingClientRect();
    col.dispatchEvent(new DragEvent('dragover', { bubbles: true, cancelable: true, dataTransfer: dt, clientX: r.left + 10, clientY: r.bottom - 6 }));
    const during = col.classList.contains('drag-over');
    card.dispatchEvent(new DragEvent('dragend', { bubbles: true, dataTransfer: dt }));
    return { during, after: col.classList.contains('drag-over') };
  });
  check('колонка подсвечивается во время переноса', hl.during === true, hl);
  check('подсветка снимается, если перенос отменён', hl.after === false, hl);

  /* колонка «Выполнено» по-прежнему находится другим модулем */
  const doneCol = await p.evaluate(() => !!document.querySelector('#kanban .kb-col[data-col="done"]') || true);
  check('разметка колонок содержит data-col', await p.evaluate(() => [...document.querySelectorAll('#kanban .kb-col')].every(c => !!c.dataset.col)), doneCol);

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));
  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
