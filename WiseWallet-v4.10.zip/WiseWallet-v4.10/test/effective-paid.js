/* Тесты v3.71: оплата регулярного платежа/кредита обычной операцией
   (без толчка «Оплатить») больше не задваивается с «ещё не оплачено». */
const { chromium } = require('playwright');
const path = require('path');
const FILE = 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const p = await (await b.newContext({ viewport: { width: 1440, height: 900 } })).newPage();
  const errors = [];
  p.on('pageerror', e => errors.push(e.message));
  p.on('console', m => { if (m.type() === 'error' && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text())) errors.push(m.text()); });
  await p.goto(FILE);
  await p.waitForTimeout(1600);
  await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });

  // === Регулярный расход, оплаченный обычной операцией ===
  await p.evaluate(() => {
    const cat = S.categories.find(c => c.type === 'expense').id;
    S.recurring = [{ id: 'r1', name: 'Бытовые расходы', type: 'expense', amount: 50000, categoryId: cat, day: 1 }];
    S.credits = [];
    const t = todayStr();
    S.transactions = [{ id: 'e1', date: t, type: 'expense', amount: 50000, accountId: S.accounts[0].id, categoryId: cat, note: '', tags: [], createdAt: 1 }];
    S.posted = {}; S.ww30Tx = {}; S.ww30Cr = {};
    save();
  });
  const d1 = await p.evaluate(() => ww30Data().exp[0]);
  check('панель «К оплате» видит покрытие обычной операцией', d1.paid === true && d1.posted === 50000, d1);
  const fig1 = await p.evaluate(() => monthDisplayFigures(todayStr().slice(0, 7)));
  check('итоговая цифра НЕ задвоена (50000, а не 100000)', fig1.expense === 50000, fig1);

  // частичная оплата — паид не должен стать true раньше времени
  await p.evaluate(() => { S.transactions[0].amount = 9700; save(); });
  const d2 = await p.evaluate(() => ww30Data().exp[0]);
  check('частичное покрытие НЕ считается оплаченным полностью', d2.paid === false && d2.posted === 9700, d2);
  check('остаток посчитан верно (50000-9700=40300)', d2.amount === 40300, d2.amount);
  const fig2 = await p.evaluate(() => monthDisplayFigures(todayStr().slice(0, 7)));
  check('при частичном покрытии сумма тоже не задваивается (=50000)', fig2.expense === 50000, fig2);

  // === Клик по уже «зелёному» переключателю не переспрашивает сумму ===
  await p.evaluate(() => { S.transactions[0].amount = 50000; save(); nav('credits'); });
  await p.waitForTimeout(600);
  await p.evaluate(() => ww30Toggle('recur', 'r1'));
  await p.waitForTimeout(400);
  const modalOpen = await p.evaluate(() => { const o = document.getElementById('overlay'); return !!(o && o.classList.contains('open')); });
  check('клик по уже покрытому пункту НЕ открывает форму суммы', !modalOpen);
  const posted = await p.evaluate(() => S.posted['r1:' + todayStr().slice(0, 7)]);
  const txIds = await p.evaluate(() => S.ww30Tx['r1:' + todayStr().slice(0, 7)]);
  check('операция зафиксирована в явной истории (можно отменить)', posted === 50000 && Array.isArray(txIds) && txIds.includes('e1'), { posted, txIds });

  // теперь отмена должна работать как обычно
  await p.evaluate(() => ww30Toggle('recur', 'r1'));
  await p.waitForTimeout(400);
  const afterUndo = await p.evaluate(() => ({ posted: S.posted['r1:' + todayStr().slice(0, 7)], txCount: S.transactions.length }));
  check('повторный клик отменяет отметку и убирает операцию', afterUndo.posted === 0 && afterUndo.txCount === 0, afterUndo);

  // === То же самое для кредита ===
  await p.evaluate(() => {
    S.credits = [{ id: 'c1', name: 'Тестовый кредит', type: 'П', lender: '', initial: 0, balance: 100000, balanceFull: 100000, payment: 15000, rate: 0, payDay: 5, start: '2025-01-01', end: '', status: 'active' }];
    const t = todayStr();
    S.transactions = [{ id: 'ct1', date: t, type: 'expense', amount: 15000, accountId: S.accounts[0].id, categoryId: 'c_credit', note: 'Тестовый кредит', tags: [], createdAt: 1 }];
    S.posted = {}; S.ww30Tx = {}; S.ww30Cr = {};
    save();
  });
  const dcr = await p.evaluate(() => ww30Data().cr[0]);
  check('кредит, оплаченный операцией с совпадающей заметкой, тоже виден как оплаченный', dcr && dcr.paid === true, dcr);

  await p.evaluate(() => nav('credits'));
  await p.waitForTimeout(600);
  await p.evaluate(() => ww30Toggle('credit', 'c1'));
  await p.waitForTimeout(400);
  const crRec = await p.evaluate(() => S.ww30Cr['c1:' + todayStr().slice(0, 7)]);
  check('кредит тоже зафиксирован в явной истории по клику', crRec && crRec.paid === 15000, crRec);

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));
  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})();
