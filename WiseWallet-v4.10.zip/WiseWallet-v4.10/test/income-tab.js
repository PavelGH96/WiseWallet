/* Тесты v3.63: вторая вкладка «Доходы» в разделе кредитов/расходов */
const { chromium } = require('playwright');
const FILE = process.env.WW_APP || 'file://' + require('path').resolve(__dirname, '../index.html');
const fails = [];
function check(name, cond, extra) {
  console.log((cond ? '  ok   ' : '  FAIL ') + name + (extra !== undefined ? '  -> ' + JSON.stringify(extra) : ''));
  if (!cond) fails.push(name);
}

const SESSION = { access_token: 'x.y.z', refresh_token: 'r', expires_at: Date.now() + 3600e3, user_id: '00000000-0000-4000-8000-000000000001', email: 't363@test.local' };

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  await ctx.route(/supabase\.co/, r => {
    if (r.request().method() === 'OPTIONS') return r.fulfill({ status: 204, headers: { 'access-control-allow-origin': '*' }, body: '' });
    return r.fulfill({ status: 200, headers: { 'access-control-allow-origin': '*', 'content-type': 'application/json' }, body: '[]' });
  });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text())) errors.push('CONSOLE: ' + m.text()); });

  await page.goto(FILE);
  await page.evaluate(s => localStorage.setItem('ww_session_v2', JSON.stringify(s)), SESSION);
  await page.goto(FILE);
  await page.waitForTimeout(1800);

  check('версия задана', /^\d+\.\d+$/.test(String(await page.evaluate(() => WW_VERSION))), await page.evaluate(() => WW_VERSION));
  check('нет битых символов', !(await page.evaluate(() => document.documentElement.innerHTML.indexOf('\uFFFD') !== -1)));

  /* ---------- готовим предсказуемые данные за текущий месяц ---------- */
  const seeded = await page.evaluate(async () => {
    const ym = todayStr().slice(0, 7);
    const d = n => ym + '-' + String(n).padStart(2, '0');
    const accId = (S.accounts[0] || {}).id || 'a1';
    S.transactions = [
      { id: 'i1', type: 'income', amount: 100000, categoryId: 'c_salary', accountId: accId, date: d(5), note: 'ЗП', createdAt: 1 },
      { id: 'i2', type: 'income', amount: 40000, categoryId: 'c_salary', accountId: accId, date: d(20), note: 'ЗП 2', createdAt: 2 },
      { id: 'i3', type: 'income', amount: 20000, categoryId: 'c_side', accountId: accId, date: d(12), note: 'такси', createdAt: 3 },
      { id: 'e1', type: 'expense', amount: 30000, categoryId: 'c_food', accountId: accId, date: d(7), note: 'еда', createdAt: 4 }
    ];
    save();
    ww26SetPeriod({ type: 'month', anchor: ym + '-01' });
    await new Promise(r => setTimeout(r, 500));
    nav('credits');
    await new Promise(r => setTimeout(r, 600));
    return { ym, txs: S.transactions.length };
  });

  /* ---------- 1. вкладки существуют ---------- */
  const tabs = await page.evaluate(() => {
    const bar = document.getElementById('ww63-tabs');
    return {
      exists: !!bar,
      titles: bar ? Array.prototype.map.call(bar.querySelectorAll('.ww40-tab'), b => b.textContent.trim()) : [],
      active: bar ? (bar.querySelector('.ww40-tab.active') || {}).dataset && bar.querySelector('.ww40-tab.active').dataset.tab : null,
      inSection: !!document.querySelector('#page-credits #ww63-tabs'),
      panes: [!!document.getElementById('ww63-pane-exp'), !!document.getElementById('ww63-pane-inc')]
    };
  });
  /* v4.07: раздел переименован в «Доходы и расходы», и порядок вкладок
     приведён в соответствие названию — «Доходы» идут первыми. */
  check('в разделе две вкладки: доходы и расходы/кредиты',
    tabs.exists && tabs.inSection && tabs.titles.length === 2 && /Доходы/i.test(tabs.titles[0]) && /Расходы/i.test(tabs.titles[1]) && tabs.panes[0] && tabs.panes[1], tabs);
  check('по умолчанию открыта вкладка «Доходы»', tabs.active === 'inc', tabs.active);

  /* ---------- 2. старое содержимое цело ---------- */
  /* v4.07: вкладка расходов больше не открыта по умолчанию — переключаемся
     на неё, прежде чем проверять её содержимое. */
  await page.evaluate(async () => { ww63Tab('exp'); await new Promise(r => setTimeout(r, 600)); });
  const oldKept = await page.evaluate(() => {
    const p = document.getElementById('ww63-pane-exp');
    const vis = el => !!el && el.getBoundingClientRect().height > 0;
    return {
      stats: !!p.querySelector('#credit-stats'),
      list: !!p.querySelector('#credit-list'),
      recur: !!p.querySelector('#recur-section'),
      statsVisible: vis(document.getElementById('credit-stats')),
      incHidden: document.getElementById('ww63-pane-inc').style.display === 'none'
    };
  });
  check('на вкладке расходов/кредитов всё прежнее на месте',
    oldKept.stats && oldKept.list && oldKept.recur && oldKept.statsVisible && oldKept.incHidden, oldKept);

  /* ---------- 3. переход на вкладку Доходы ---------- */
  const opened = await page.evaluate(async () => {
    ww63Tab('inc');
    await new Promise(r => setTimeout(r, 500));
    const pi = document.getElementById('ww63-pane-inc');
    const pe = document.getElementById('ww63-pane-exp');
    const txt = pi.textContent;
    return {
      incVisible: pi.getBoundingClientRect().height > 0,
      expHidden: pe.style.display === 'none',
      title: (document.querySelector('#page-credits .page-head h1') || {}).textContent,
      hasStats: !!pi.querySelector('#ww63-stats'),
      hasCats: !!pi.querySelector('#ww63-cats'),
      hasRecur: !!pi.querySelector('#ww63-recur'),
      hasTx: !!pi.querySelector('#ww63-tx'),
      hasPeriod: !!pi.querySelector('#ww63-period-btn'),
      hasAdd: !!document.getElementById('ww63-add-head') && getComputedStyle(document.getElementById('ww63-add-head')).display !== 'none',
      cards: pi.querySelectorAll('#ww63-stats .card.stat').length,
      sections: /Доходы по категориям/.test(txt) && /Регулярные доходы/.test(txt) && /Операции — доходы/.test(txt)
    };
  });
  check('вкладка «Доходы» открывается, прежняя скрывается',
    opened.incVisible && opened.expHidden, opened);
  check('интерфейс аналогичен расходному: статистика, категории, регулярные, операции',
    opened.hasStats && opened.hasCats && opened.hasRecur && opened.hasTx && opened.cards === 4 && opened.sections, opened);
  // v3.75: кнопка «+ Доход» переехала в шапку страницы (рядом с h1), чтобы
  // строка периода была центрирована так же, как на остальных страницах.
  check('есть переключатель периода и кнопка добавления в шапке',
    opened.hasPeriod && opened.hasAdd, opened);

  /* ---------- 4. цифры совпадают с дашбордом ---------- */
  const sync = await page.evaluate(async () => {
    const norm = s => String(s).replace(/[^0-9]/g, '');
    const d = ww63Data();
    const tabFact = norm(document.getElementById('ww63-fact').textContent);
    nav('dashboard');
    await new Promise(r => setTimeout(r, 700));
    const dashCard = document.querySelector('#dash-stats .card.stat[data-sid="income"] .val');
    const dashInc = norm(dashCard ? dashCard.textContent : '');
    nav('credits');
    await new Promise(r => setTimeout(r, 700));
    const again = norm((document.getElementById('ww63-fact') || {}).textContent || '');
    return { fact: d.fact, tabFact, dashInc, again, count: d.count };
  });
  check('сумма дохода = 160 000 и совпадает с дашбордом',
    sync.fact === 160000 && sync.tabFact === '160000' && sync.dashInc === '160000' && sync.again === '160000' && sync.count === 3, sync);

  const opsSync = await page.evaluate(async () => {
    const norm = s => String(s).replace(/[^0-9]/g, '');
    nav('ops');
    await new Promise(r => setTimeout(r, 800));
    const sum = document.getElementById('ops-summary');
    const txt = sum ? sum.textContent : '';
    const mm = txt.match(/Доходы\s*\+?([\d\s ]+)/);
    nav('credits');
    await new Promise(r => setTimeout(r, 600));
    return { ops: mm ? norm(mm[1]) : null, tab: norm(document.getElementById('ww63-fact').textContent) };
  });
  check('та же сумма в разделе «Операции»', opsSync.ops === opsSync.tab, opsSync);

  /* ---------- 5. категории и доли ---------- */
  const cats = await page.evaluate(() => {
    const rows = Array.prototype.map.call(document.querySelectorAll('#ww63-cats .ww63-catrow'), r => ({
      name: r.querySelector('.nm').textContent.trim(),
      amt: r.querySelector('.amt').textContent.replace(/[^0-9]/g, ''),
      share: r.querySelector('.shr').textContent.trim()
    }));
    return { rows, cats: ww63Data().cats.map(c => [c.name, c.sum]) };
  });
  check('доходы разбиты по категориям с долями',
    cats.rows.length === 2 && cats.rows[0].amt === '140000' && cats.rows[0].share === '88%' && cats.rows[1].amt === '20000' && cats.rows[1].share === '13%', cats);

  /* ---------- 6. список операций — только доходы ---------- */
  const txList = await page.evaluate(() => {
    const rows = document.querySelectorAll('#ww63-tx .row');
    const ids = Array.prototype.map.call(rows, r => r.dataset.sid);
    return { n: rows.length, ids, hasExpense: ids.indexOf('e1') !== -1, text: document.getElementById('ww63-tx').textContent };
  });
  check('в списке только доходные операции',
    txList.n === 3 && !txList.hasExpense && !/еда/.test(txList.text), txList);

  /* ---------- 7. регулярные доходы и план ---------- */
  const plan = await page.evaluate(() => {
    const norm = s => String(s).replace(/[^0-9]/g, '');
    return {
      planCard: norm(document.getElementById('ww63-plan').textContent),
      planFn: planIncomeMonth(),
      recurRows: document.querySelectorAll('#ww63-recur .row').length,
      recurTotal: norm((document.getElementById('ww63-recur-total') || {}).textContent || ''),
      pct: document.getElementById('ww63-pct').textContent.trim(),
      avg: norm(document.getElementById('ww63-avg').textContent)
    };
  });
  check('план доходов берётся из регулярных (как в плане на месяц)',
    plan.planCard === String(plan.planFn) && plan.recurTotal === String(plan.planFn) && plan.recurRows >= 2, plan);
  check('выполнение плана и средний доход посчитаны',
    /^\d+%$/.test(plan.pct) && plan.avg === '160000', plan);

  /* ---------- 8. смена периода пересчитывает вкладку ---------- */
  const shifted = await page.evaluate(async () => {
    const norm = s => String(s).replace(/[^0-9]/g, '');
    ww26ShiftMonth(-1);
    await new Promise(r => setTimeout(r, 800));
    const prev = norm(document.getElementById('ww63-fact').textContent);
    const prevLabel = document.getElementById('ww63-period-btn').textContent.trim();
    ww26ShiftMonth(1);
    await new Promise(r => setTimeout(r, 800));
    const back = norm(document.getElementById('ww63-fact').textContent);
    const label = document.getElementById('ww63-period-btn').textContent.trim();
    return { prev, prevLabel, back, label, dashLabel: (document.getElementById('ww26-period-btn') || {}).textContent };
  });
  check('смена периода пересчитывает доходы и синхронна с дашбордом',
    shifted.prev === '0' && shifted.back === '160000' && shifted.label === String(shifted.dashLabel).trim(), shifted);

  const allTime = await page.evaluate(async () => {
    const norm = s => String(s).replace(/[^0-9]/g, '');
    ww26SetPeriod({ type: 'all' });
    await new Promise(r => setTimeout(r, 800));
    const v = norm(document.getElementById('ww63-fact').textContent);
    const d = ww63Data();
    ww26SetPeriod({ type: 'month', anchor: todayStr().slice(0, 8) + '01' });
    await new Promise(r => setTimeout(r, 700));
    return { all: v, months: d.months, back: norm(document.getElementById('ww63-fact').textContent) };
  });
  check('режим «весь период» тоже работает', allTime.all === '160000' && allTime.back === '160000', allTime);

  /* ---------- 9. новая операция сразу видна обеим сторонам ---------- */
  const added = await page.evaluate(async () => {
    const norm = s => String(s).replace(/[^0-9]/g, '');
    const accId = (S.accounts[0] || {}).id || 'a1';
    S.transactions.push({ id: 'i4', type: 'income', amount: 5000, categoryId: 'c_inc_other', accountId: accId, date: todayStr(), note: 'подарок', createdAt: 9 });
    save();
    renderCredits();
    await new Promise(r => setTimeout(r, 600));
    const tab = norm(document.getElementById('ww63-fact').textContent);
    nav('dashboard');
    await new Promise(r => setTimeout(r, 700));
    const dash = norm(document.querySelector('#dash-stats .card.stat[data-sid="income"] .val').textContent);
    nav('credits');
    await new Promise(r => setTimeout(r, 700));
    return { tab, dash, rows: document.querySelectorAll('#ww63-tx .row').length };
  });
  check('новый доход сразу учтён и во вкладке, и на дашборде',
    added.tab === '165000' && added.dash === '165000' && added.rows === 4, added);

  /* ---------- 10. выбор вкладки запоминается ---------- */
  await page.reload();
  await page.waitForTimeout(1800);
  const remembered = await page.evaluate(async () => {
    nav('credits');
    await new Promise(r => setTimeout(r, 800));
    return {
      cur: ww63CurTab(),
      incVisible: document.getElementById('ww63-pane-inc').getBoundingClientRect().height > 0,
      active: (document.querySelector('#ww63-tabs .ww40-tab.active') || {}).dataset.tab
    };
  });
  check('выбранная вкладка сохраняется после перезагрузки',
    remembered.cur === 'inc' && remembered.incVisible && remembered.active === 'inc', remembered);

  const backExp = await page.evaluate(async () => {
    ww63Tab('exp');
    await new Promise(r => setTimeout(r, 600));
    return {
      cur: ww63CurTab(),
      creditStats: document.getElementById('credit-stats').getBoundingClientRect().height > 0,
      title: (document.querySelector('#page-credits .page-head h1') || {}).textContent,
      incHidden: document.getElementById('ww63-pane-inc').style.display === 'none'
    };
  });
  check('возврат на вкладку расходов/кредитов работает',
    backExp.cur === 'exp' && backExp.creditStats && backExp.incHidden && /Доходы и расходы/.test(backExp.title), backExp);

  /* ---------- 11. мобильный экран: вкладки + панель внизу ---------- */
  const mctx = await browser.newContext({ viewport: { width: 390, height: 780 }, isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
  const mpage = await mctx.newPage();
  const merrors = [];
  mpage.on('pageerror', e => merrors.push('PAGEERROR: ' + e.message));
  await mpage.goto(FILE);
  await mpage.evaluate(s => localStorage.setItem('ww_session_v2', JSON.stringify(s)), SESSION);
  await mpage.goto(FILE);
  await mpage.waitForTimeout(1800);
  const mob = await mpage.evaluate(async () => {
    const accId = (S.accounts[0] || {}).id || 'a1';
    S.transactions = [{ id: 'm1', type: 'income', amount: 70000, categoryId: 'c_salary', accountId: accId, date: todayStr(), note: 'ЗП', createdAt: 1 }];
    save();
    nav('credits');
    await new Promise(r => setTimeout(r, 500));
    ww63Tab('inc');
    await new Promise(r => setTimeout(r, 700));
    window.scrollTo(0, document.body.scrollHeight);
    await new Promise(r => setTimeout(r, 500));
    const st = typeof ww62NavState === 'function' ? ww62NavState() : null;
    const bar = document.getElementById('ww63-tabs').getBoundingClientRect();
    return {
      tabsVisible: bar.height > 0 && bar.width > 0,
      fact: document.getElementById('ww63-fact').textContent.replace(/[^0-9]/g, ''),
      nav: st
    };
  });
  check('на телефоне вкладки видны и цифры считаются',
    mob.tabsVisible && mob.fact === '70000', mob);
  check('нижняя панель осталась внизу на новой вкладке',
    mob.nav && mob.nav.bottomGap === 0 && mob.nav.position === 'fixed', mob.nav);

  const allErrors = errors.concat(merrors);
  console.log('\nERRORS', allErrors);
  await browser.close();
  if (fails.length || allErrors.length) {
    console.log('\nНЕ ПРОШЛИ: ' + fails.length + ' проверок');
    process.exit(1);
  }
  console.log('\nВсе проверки прошли');
})();
