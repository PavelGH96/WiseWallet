/* ============================================================================
   ГЛОБАЛЬНАЯ РЕВИЗИЯ РАСЧЁТОВ (v3.76)

   Идея: не проверять приложение его же формулами (так ошибка просто
   продублируется), а посчитать каждую величину НЕЗАВИСИМО — примитивным
   перебором сырых операций — и сверить с тем, что показывает приложение.
   Такой независимый счётчик дальше называется «эталон».

   Данные подобраны специально «злыми»: копейки, операции ровно на границах
   месяца, частично оплаченный регулярный платёж, кредит оплаченный обычной
   операцией, перевод между счетами, архивный счёт, будущая операция.
   ============================================================================ */
const { chromium } = require('playwright');
const path = require('path');
const FILE = 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };
const near = (a, b, eps = 0.5) => Math.abs((a || 0) - (b || 0)) < eps;

const FIXTURE = () => {
  const CAT_FOOD = 'zz_food', CAT_HOME = 'zz_home', CAT_SAL = 'zz_sal', CAT_EXTRA = 'zz_extra';
  S.accounts = [
    { id: 'ac_card', name: 'Карта', type: 'card', balance0: 1000.55, archived: false },
    { id: 'ac_cash', name: 'Наличные', type: 'cash', balance0: 0, archived: false },
    { id: 'ac_old', name: 'Старый счёт', type: 'card', balance0: 500, archived: true, archivedFrom: '2026-08-01' },
  ];
  S.categories = [
    { id: CAT_FOOD, name: 'Еда', type: 'expense', icon: '🍎' },
    { id: CAT_HOME, name: 'Дом', type: 'expense', icon: '🏠' },
    { id: 'c_credit', name: 'Платежи по кредитам', type: 'expense', icon: '🏦' },
    { id: CAT_SAL, name: 'Зарплата', type: 'income', icon: '💼' },
    { id: CAT_EXTRA, name: 'Подработка', type: 'income', icon: '💰' },
    { id: 'c_tr_in', name: 'Перевод (вх)', type: 'income', icon: '⇄' },
    { id: 'c_tr_out', name: 'Перевод (исх)', type: 'expense', icon: '⇄' },
  ];
  S.transactions = [
    // --- август: границы месяца ---
    { id: 't01', date: '2026-08-01', type: 'income', amount: 100000.10, accountId: 'ac_card', categoryId: CAT_SAL, note: 'ЗП', tags: [], createdAt: 1 },
    { id: 't02', date: '2026-08-31', type: 'expense', amount: 999.99, accountId: 'ac_card', categoryId: CAT_FOOD, note: 'последний день', tags: [], createdAt: 2 },
    // --- копейки ---
    { id: 't03', date: '2026-08-10', type: 'expense', amount: 1234.56, accountId: 'ac_card', categoryId: CAT_FOOD, note: '', tags: [], createdAt: 3 },
    { id: 't04', date: '2026-08-10', type: 'expense', amount: 0.44, accountId: 'ac_card', categoryId: CAT_FOOD, note: '', tags: [], createdAt: 4 },
    // --- частичная оплата регулярного «Дом» (план 8000, внесено 3000) ---
    { id: 't05', date: '2026-08-05', type: 'expense', amount: 3000, accountId: 'ac_card', categoryId: CAT_HOME, note: 'частично', tags: [], createdAt: 5 },
    // --- кредит оплачен ОБЫЧНОЙ операцией (не толчком) ---
    { id: 't06', date: '2026-08-12', type: 'expense', amount: 5000, accountId: 'ac_card', categoryId: 'c_credit', note: 'Кредит А', tags: [], createdAt: 6 },
    // --- перевод между своими счетами: не должен считаться доходом/расходом периода ---
    { id: 't07', date: '2026-08-15', type: 'expense', amount: 2000, accountId: 'ac_card', categoryId: 'c_tr_out', note: 'перевод', tags: [], createdAt: 7 },
    { id: 't08', date: '2026-08-15', type: 'income', amount: 2000, accountId: 'ac_cash', categoryId: 'c_tr_in', note: 'перевод', tags: [], createdAt: 8 },
    // --- доход-подработка ---
    { id: 't09', date: '2026-08-20', type: 'income', amount: 7500.25, accountId: 'ac_cash', categoryId: CAT_EXTRA, note: '', tags: [], createdAt: 9 },
    // --- ИЮЛЬ (предыдущий период) ---
    { id: 't10', date: '2026-07-31', type: 'expense', amount: 4321, accountId: 'ac_card', categoryId: CAT_FOOD, note: 'граница июля', tags: [], createdAt: 10 },
    { id: 't11', date: '2026-07-15', type: 'income', amount: 50000, accountId: 'ac_card', categoryId: CAT_SAL, note: '', tags: [], createdAt: 11 },
    // --- БУДУЩЕЕ (сентябрь): не должно влиять на август ---
    { id: 't12', date: '2026-09-05', type: 'expense', amount: 77777, accountId: 'ac_card', categoryId: CAT_FOOD, note: 'будущее', tags: [], createdAt: 12 },
    // --- операция по архивному счёту (июль, когда он ещё был активен) ---
    { id: 't13', date: '2026-07-20', type: 'expense', amount: 250, accountId: 'ac_old', categoryId: CAT_FOOD, note: '', tags: [], createdAt: 13 },
  ];
  S.recurring = [
    { id: 'r_home', name: 'Дом', type: 'expense', amount: 8000, categoryId: CAT_HOME, day: 5 },
    { id: 'r_sal', name: 'Зарплата', type: 'income', amount: 100000, categoryId: CAT_SAL, day: 1 },
  ];
  S.credits = [
    { id: 'cr_a', name: 'Кредит А', type: 'П', lender: '', initial: 0, balance: 100000, balanceFull: 100000, payment: 5000, rate: 0, payDay: 12, start: '2025-01-01', end: '', status: 'active' },
    { id: 'cr_b', name: 'Кредит Б', type: 'П', lender: '', initial: 0, balance: 60000, balanceFull: 60000, payment: 3000, rate: 0, payDay: 25, start: '2025-01-01', end: '', status: 'active' },
  ];
  S.budgets = [{ id: 'b1', categoryId: CAT_FOOD, limit: 5000 }];
  S.goals = [{ id: 'g1', name: 'Цель', target: 10000, saved: 2500, icon: '🎯' }];
  S.posted = {}; S.ww30Tx = {}; S.ww30Cr = {}; S.skipped = {};
  save();
  return { CAT_FOOD, CAT_HOME, CAT_SAL, CAT_EXTRA };
};

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const p = await (await b.newContext({ viewport: { width: 1600, height: 950 } })).newPage();
  const errors = [];
  p.on('pageerror', e => errors.push(e.message));
  p.on('console', m => { if (m.type() === 'error' && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text())) errors.push(m.text()); });
  await p.goto(FILE);
  await p.waitForTimeout(1600);
  await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
  await p.evaluate(FIXTURE);
  await p.evaluate(() => { ww26SetPeriod({ type: 'month', anchor: '2026-08' }); });
  // v3.94: у PDF-отчёта СВОЙ, независимый период (см. комментарий в самом
  // коде приложения: «период отчёта — свой, не влияет на дашборд»), и у него
  // нет понятия «месяц с произвольным якорем» — только фиксированные
  // пресеты (week/prevmonth/quarter/...) либо custom с явными датами.
  // Раньше этот тест полагался на случайное совпадение с реальной датой
  // «сегодня» (писался, когда сегодня приходилось на август) — как только
  // календарь сдвинулся дальше, совпадение исчезло. Указываем диапазон явно.
  await p.evaluate(() => { if (typeof ww43SetPeriod === 'function') ww43SetPeriod({ type: 'custom', from: '2026-08-01', to: '2026-08-31' }); });
  await p.waitForTimeout(700);

  console.log('\n=== 1. Балансы счетов (эталон: начальный + сумма движений) ===');
  const bal = await p.evaluate(() => {
    // ЭТАЛОН — независимый перебор
    const oracle = (id, until) => {
      const a = S.accounts.find(x => x.id === id);
      let v = +a.balance0 || 0;
      S.transactions.forEach(t => {
        if (t.accountId !== id) return;
        if (until && t.date > until) return;
        v += (t.type === 'income' ? +t.amount : -+t.amount);
      });
      return Math.round(v * 100) / 100;
    };
    return {
      cardToday: { app: Math.round(accBalance('ac_card') * 100) / 100, oracle: oracle('ac_card') },
      cardAug31: { app: Math.round(accBalanceAsOf('ac_card', '2026-08-31') * 100) / 100, oracle: oracle('ac_card', '2026-08-31') },
      cardJul31: { app: Math.round(accBalanceAsOf('ac_card', '2026-07-31') * 100) / 100, oracle: oracle('ac_card', '2026-07-31') },
      cashAug31: { app: Math.round(accBalanceAsOf('ac_cash', '2026-08-31') * 100) / 100, oracle: oracle('ac_cash', '2026-08-31') },
    };
  });
  Object.entries(bal).forEach(([k, v]) => check(`баланс ${k} совпадает с эталоном`, near(v.app, v.oracle, 0.011), v));

  console.log('\n=== 2. Доход/расход за период (август), включая копейки и границы ===');
  const per = await p.evaluate(() => {
    const inRange = d => d >= '2026-08-01' && d <= '2026-08-31';
    let inc = 0, exp = 0;
    S.transactions.forEach(t => { if (!inRange(t.date)) return; if (t.type === 'income') inc += +t.amount; else exp += +t.amount; });
    const tx = S.transactions.filter(t => ww26In(t.date));
    let appInc = 0, appExp = 0;
    tx.forEach(t => { if (t.type === 'income') appInc += +t.amount; else appExp += +t.amount; });
    return { inc: { app: Math.round(appInc * 100) / 100, oracle: Math.round(inc * 100) / 100 }, exp: { app: Math.round(appExp * 100) / 100, oracle: Math.round(exp * 100) / 100 }, n: tx.length };
  });
  check('доход за август совпадает с эталоном', near(per.inc.app, per.inc.oracle, 0.011), per.inc);
  check('расход за август совпадает с эталоном', near(per.exp.app, per.exp.oracle, 0.011), per.exp);
  check('в период попали ровно операции августа (9 шт., без июля/сентября)', per.n === 9, per.n);

  console.log('\n=== 3. Бюджет: потрачено по категории (эталон — прямая сумма) ===');
  const bud = await p.evaluate(() => {
    const oracle = S.transactions
      .filter(t => t.type === 'expense' && t.categoryId === 'zz_food' && t.date.slice(0, 7) === '2026-08')
      .reduce((s, t) => s + +t.amount, 0);
    return { app: Math.round(catSpentMonth('zz_food', '2026-08') * 100) / 100, oracle: Math.round(oracle * 100) / 100 };
  });
  check('«потрачено» по бюджету Еда совпадает с эталоном', near(bud.app, bud.oracle, 0.011), bud);

  console.log('\n=== 4. «Оплачено» с учётом обычных операций (регулярные и кредиты) ===');
  const paid = await p.evaluate(() => {
    const r = S.recurring.find(x => x.id === 'r_home');
    const c1 = S.credits.find(x => x.id === 'cr_a');
    const c2 = S.credits.find(x => x.id === 'cr_b');
    return {
      recurPartial: { posted: wwRecurEffectivePosted(r, '2026-08'), oracle: 3000, full: 8000 },
      creditByNote: { posted: wwCreditEffectivePosted(c1, '2026-08'), oracle: 5000, full: 5000 },
      creditUnpaid: { posted: wwCreditEffectivePosted(c2, '2026-08'), oracle: 0, full: 3000 },
    };
  });
  check('частично оплаченный регулярный: учтено ровно внесённое (3000 из 8000)', paid.recurPartial.posted === 3000, paid.recurPartial);
  check('кредит, оплаченный обычной операцией, засчитан полностью', paid.creditByNote.posted === 5000, paid.creditByNote);
  check('неоплаченный кредит остаётся неоплаченным', paid.creditUnpaid.posted === 0, paid.creditUnpaid);

  console.log('\n=== 5. Панель «К оплате»: остатки (эталон = план − внесённое) ===');
  const due = await p.evaluate(() => {
    const d = ww30Data();
    const r = d.exp.find(x => x.id === 'r_home');
    const c1 = d.cr.find(x => x.id === 'cr_a');
    const c2 = d.cr.find(x => x.id === 'cr_b');
    return {
      home: r ? { amount: r.amount, paid: r.paid, oracle: 8000 - 3000 } : null,
      crA: c1 ? { paid: c1.paid, oracle: true } : null,
      crB: c2 ? { amount: c2.amount, paid: c2.paid, oracle: 3000 } : null,
    };
  });
  check('остаток по «Дом» = 5000 (8000 − 3000), не закрыт', due.home && due.home.amount === 5000 && due.home.paid === false, due.home);
  check('«Кредит А» показан оплаченным (покрыт операцией)', due.crA && due.crA.paid === true, due.crA);
  check('«Кредит Б» остаётся к оплате на 3000', due.crB && due.crB.amount === 3000 && due.crB.paid === false, due.crB);

  console.log('\n=== 6. «Свободные деньги» = остаток на конец периода − неоплаченное ===');
  const free = await p.evaluate(() => {
    const f = ww318Free();
    const d = ww30Data();
    const dueSum = d.exp.concat(d.cr).filter(x => !x.paid).reduce((s, x) => s + (+x.amount || 0), 0);
    // Эталон остатка. ВАЖНО: для текущего месяца срез берётся на СЕГОДНЯ,
    // а не на конец месяца — операции с будущей датой (например, 31-е, когда
    // сегодня 28-е) в «деньги на счетах» ещё не входят. Это правильное
    // поведение приложения: показывать реальные деньги на руках.
    const asOf = ww318AsOfDate();
    const visible = S.accounts.filter(a => accVisibleFor(a, '2026-08'));
    let total = 0;
    visible.forEach(a => {
      let v = (a.balance0From && asOf < a.balance0From) ? 0 : (+a.balance0 || 0);
      S.transactions.forEach(t => { if (t.accountId === a.id && t.date <= asOf) v += (t.type === 'income' ? +t.amount : -+t.amount); });
      total += v;
    });
    return { appTotal: Math.round(f.total * 100) / 100, oracleTotal: Math.round(total * 100) / 100, appDue: Math.round(f.due * 100) / 100, oracleDue: Math.round(dueSum * 100) / 100, appFree: Math.round(f.free * 100) / 100 };
  });
  check('«на счетах» совпадает с эталоном', near(free.appTotal, free.oracleTotal, 0.011), free);
  check('«осталось оплатить» совпадает с суммой неоплаченного', near(free.appDue, free.oracleDue, 0.011), free);
  check('«свободные деньги» = на счетах − к оплате', near(free.appFree, free.appTotal - free.appDue, 0.011), free);

  console.log('\n=== 7. Архивный счёт: виден в прошлом, скрыт в текущем ===');
  const arch = await p.evaluate(() => ({
    julVisible: accVisibleFor(S.accounts.find(a => a.id === 'ac_old'), '2026-07'),
    augVisible: accVisibleFor(S.accounts.find(a => a.id === 'ac_old'), '2026-08'),
  }));
  check('архивный счёт виден в июле (когда был активен)', arch.julVisible === true, arch);
  check('архивный счёт скрыт в августе (после архивации)', arch.augVisible === false, arch);

  console.log('\n=== 8. Дашборд: цифры на экране = расчётным ===');
  await p.evaluate(() => { nav('dashboard'); });
  await p.waitForTimeout(700);
  const ui = await p.evaluate(() => {
    const num = s => { const t = (s || '').replace(/\u00a0|\s/g, '').replace('₽', '').replace('−', '-').replace('+', ''); return parseFloat(t.replace(',', '.')) || 0; };
    const coinTotal = num(document.getElementById('ww26-acc-total')?.textContent);
    const f = ww318Free();
    const incTotal = num(document.getElementById('ww26-inc-total')?.textContent);
    const expTotal = num(document.getElementById('ww26-exp-total')?.textContent);
    let oInc = 0, oExp = 0;
    S.transactions.filter(t => ww26In(t.date)).forEach(t => { if (t.type === 'income') oInc += +t.amount; else oExp += +t.amount; });
    return { coinTotal, freeTotal: Math.round(f.total), incTotal, oInc: Math.round(oInc), expTotal, oExp: Math.round(oExp) };
  });
  check('итог «Кошельки» на экране = «на счетах» в шапке', near(ui.coinTotal, ui.freeTotal, 1.5), ui);
  check('итог «Доходы» на экране = сумме доходов периода', near(ui.incTotal, ui.oInc, 1.5), ui);
  check('итог «Расходы» на экране = сумме расходов периода', near(Math.abs(ui.expTotal), ui.oExp, 1.5), ui);

  console.log('\n=== 9. Смена периода: июль пересчитывается независимо ===');
  await p.evaluate(() => ww26SetPeriod({ type: 'month', anchor: '2026-07' }));
  await p.waitForTimeout(700);
  const jul = await p.evaluate(() => {
    let oInc = 0, oExp = 0;
    S.transactions.filter(t => t.date >= '2026-07-01' && t.date <= '2026-07-31').forEach(t => { if (t.type === 'income') oInc += +t.amount; else oExp += +t.amount; });
    const num = s => { const t = (s || '').replace(/\u00a0|\s/g, '').replace('₽', '').replace('−', '-').replace('+', ''); return parseFloat(t.replace(',', '.')) || 0; };
    return { incUI: num(document.getElementById('ww26-inc-total')?.textContent), oInc, expUI: num(document.getElementById('ww26-exp-total')?.textContent), oExp };
  });
  check('доход июля на экране = эталону (50 000)', near(jul.incUI, jul.oInc, 1.5), jul);
  check('расход июля на экране = эталону (4321 + 250)', near(Math.abs(jul.expUI), jul.oExp, 1.5), jul);

  console.log('\n=== 10. PDF-отчёт: сходимость итогов ===');
  await p.evaluate(() => { window.print = function () {}; ww26SetPeriod({ type: 'month', anchor: '2026-08' }); });
  await p.evaluate(() => { if (typeof ww43SetPeriod === 'function') ww43SetPeriod({ type: 'custom', from: '2026-08-01', to: '2026-08-31' }); });
  await p.waitForTimeout(500);
  const rep = await p.evaluate(() => {
    const d = ww43Collect(ww43Period());
    const sumBy = o => Object.values(o || {}).reduce((s, v) => s + v, 0);
    return {
      inc: Math.round(d.inc * 100) / 100, incBy: Math.round(sumBy(d.incBy) * 100) / 100,
      exp: Math.round(d.exp * 100) / 100, expBy: Math.round(sumBy(d.expBy) * 100) / 100,
      net: Math.round(d.net * 100) / 100, left: Math.round(d.left * 100) / 100, dueTotal: Math.round(d.dueTotal * 100) / 100,
    };
  });
  check('в отчёте сумма по категориям доходов = общему доходу', near(rep.inc, rep.incBy, 0.011), rep);
  check('в отчёте сумма по категориям расходов = общему расходу', near(rep.exp, rep.expBy, 0.011), rep);
  check('в отчёте «доходы − расходы» сходится', near(rep.net, rep.inc - rep.exp, 0.011), rep);
  check('в отчёте «останется» = net − к оплате', near(rep.left, rep.net - rep.dueTotal, 0.011), rep);

  console.log('\n=== 10b. Сходимость «к оплате»: дашборд vs PDF-отчёт ===');
  const cross = await p.evaluate(() => {
    const d = ww30Data();
    const dash = d.exp.concat(d.cr).filter(x => !x.paid).reduce((s, x) => s + (+x.amount || 0), 0);
    const rep = ww43Collect(ww43Period());
    return { dash: Math.round(dash * 100) / 100, report: Math.round(rep.dueTotal * 100) / 100, lines: rep.due.map(x => x.name + ' | ' + x.amount) };
  });
  check('итог «к оплате» одинаков на дашборде и в отчёте (включая просроченное)', near(cross.dash, cross.report, 0.011), cross);

  console.log('\n=== 11. Обход всех разделов: без ошибок и без NaN на экране ==='); 
  const pages = ['dashboard', 'ops', 'credits', 'budgets', 'goals', 'calendar', 'planner', 'links', 'analytics', 'settings'];
  const bad = [];
  for (const pg of pages) {
    await p.evaluate(x => { try { nav(x); } catch (e) {} }, pg);
    await p.waitForTimeout(400);
    const t = await p.evaluate(() => {
      const root = document.querySelector('.page.active');
      const txt = root ? root.innerText : '';
      return { nan: /NaN|undefined|Infinity/.test(txt), sample: (txt.match(/.{0,40}(NaN|undefined|Infinity).{0,40}/) || [''])[0] };
    });
    if (t.nan) bad.push(pg + ': ' + t.sample);
  }
  check('ни на одной странице нет NaN/undefined/Infinity', bad.length === 0, bad);

  check('ошибок JS за весь прогон нет', errors.length === 0, errors.slice(0, 4));

  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ (' + fails.length + '): ' + fails.join(' | ') : '✅ все расчёты сошлись с независимым эталоном'));
  process.exit(fails.length ? 1 : 0);
})();
