/* Тесты v3.70: текстовое резюме в PDF-отчёте.
   Проверяем, что резюме есть, что его цифры совпадают с карточками отчёта
   и что формулировки корректны в пограничных случаях. */
const { chromium } = require('playwright');
const path = require('path');
const FILE = 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const p = await (await b.newContext({ viewport: { width: 1440, height: 900 } })).newPage();
  const errors = [];
  p.on('pageerror', e => errors.push(e.message));
  p.on('console', m => { if (m.type() === 'error' && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text())) errors.push(m.text()); });
  await p.goto(FILE);
  await p.waitForTimeout(1600);
  await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
  await p.evaluate(() => { window.print = function () {}; });

  const build = async (prep) => {
    await p.evaluate(prep);
    await p.waitForTimeout(250);
    await p.evaluate(() => { try { ww43ToPdf(); } catch (e) {} });
    await p.waitForTimeout(500);
    return p.evaluate(() => {
      const el = document.querySelector('#ww43-print .ww43-summary');
      return el ? el.innerText : '';
    });
  };

  // 1. Прибыльный период
  let s = await build(() => {
    const ex = S.categories.filter(c => c.type === 'expense');
    const inc = S.categories.find(c => c.type === 'income').id;
    const t = todayStr();
    S.credits = []; S.recurring = [];
    S.transactions = [
      { id: 'i1', date: t, type: 'income', amount: 150000, accountId: S.accounts[0].id, categoryId: inc, note: '', tags: [], createdAt: 1 },
      { id: 'e1', date: t, type: 'expense', amount: 50000, accountId: S.accounts[0].id, categoryId: ex[0].id, note: '', tags: [], createdAt: 2 },
      { id: 'e2', date: t, type: 'expense', amount: 20000, accountId: S.accounts[0].id, categoryId: ex[1].id, note: '', tags: [], createdAt: 3 },
    ];
    save();
  });
  check('резюме присутствует в отчёте', s.length > 0);
  check('заголовок резюме на месте', /Коротко о периоде/.test(s), s.slice(0, 40));
  check('назван верный итог периода (150 000 − 70 000 = 80 000)', /превысили расходы на\s*80\s*000/.test(s.replace(/\u00a0/g, ' ')), s.slice(0, 160));
  check('названа крупнейшая статья расходов', /Крупнейшая статья расходов/.test(s));
  check('доля крупнейшей статьи посчитана (71%)', /71%/.test(s), (s.match(/\d+% всех трат/) || [])[0]);

  // 2. Убыточный период
  s = await build(() => {
    const ex = S.categories.filter(c => c.type === 'expense');
    const inc = S.categories.find(c => c.type === 'income').id;
    const t = todayStr();
    S.transactions = [
      { id: 'i1', date: t, type: 'income', amount: 30000, accountId: S.accounts[0].id, categoryId: inc, note: '', tags: [], createdAt: 1 },
      { id: 'e1', date: t, type: 'expense', amount: 95000, accountId: S.accounts[0].id, categoryId: ex[0].id, note: '', tags: [], createdAt: 2 },
    ];
    save();
  });
  check('убыток описан как превышение расходов', /расходы превысили доходы на\s*65\s*000/.test(s.replace(/\u00a0/g, ' ')), s.slice(0, 120));

  // 3. Пустой период
  s = await build(() => { S.transactions = []; save(); });
  check('пустой период описан отдельно, без ложных выводов', /операций не записано/.test(s), s.slice(0, 120));
  check('в пустом периоде нет упоминания крупнейшей статьи', !/Крупнейшая статья/.test(s));

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));
  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})();
