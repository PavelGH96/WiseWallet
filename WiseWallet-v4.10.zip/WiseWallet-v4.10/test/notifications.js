const path=require("path");
const {chromium}=require("playwright");
const FILE = process.env.WW_APP || 'file://' + require('path').resolve(__dirname, '../index.html');
const SESSION={access_token:"smoke.jwt.token",refresh_token:"smoke.refresh",expires_at:Date.now()+3600e3,user_id:"00000000-0000-4000-8000-000000000001",email:"smoke@example.com"};
(async()=>{
 const browser=await chromium.launch({executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium',args:["--no-sandbox"]});
 const errors=[];
 async function run(viewport,mobile,label){
  const c=await browser.newContext({viewport,hasTouch:mobile,isMobile:mobile,deviceScaleFactor:mobile?2:1});
  const p=await c.newPage();
  p.on("pageerror",e=>errors.push(label+" PAGEERROR: "+e.message));
  p.on("console",m=>{if(m.type()==="error"&&!/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text()))errors.push(label+" CONSOLE: "+m.text())});
  await p.goto(FILE);await p.evaluate(s=>localStorage.setItem("ww_session_v2",JSON.stringify(s)),SESSION);await p.reload();await p.waitForTimeout(1700);
  await p.evaluate(()=>{
   const now=new Date(), day=now.getDate();
   const ex=(S.categories.find(c=>c.type==="expense")||{}).id;
   S.recurring=[];
   for(let i=0;i<24;i++) S.recurring.push({id:"n"+i,name:"Уведомление "+String(i+1).padStart(2,"0"),type:"expense",amount:1000+i*100,categoryId:ex,day:Math.min(28,((day+i-1)%28)+1)});
   S.credits=[];S.notifRead={};S.settings.dismissed={};save();
   ww331OpenNotifs();
  });
  await p.waitForTimeout(500);
  const init=await p.evaluate(()=>{const s=document.getElementById("ww331-notif-scroll");return{rows:s.querySelectorAll(".ww331-row").length,buttons:s.querySelectorAll('button[title="Отметить прочитанным"]').length,client:s.clientHeight,scroll:s.scrollHeight,max:s.scrollHeight-s.clientHeight,badge:(document.querySelector("#modal .mhead .badge")||{}).textContent||""}});
  const steps=[];
  for(let k=0;k<3;k++){
   const r=await p.evaluate(async(k)=>{
    const wait=ms=>new Promise(r=>setTimeout(r,ms));
    const s=document.getElementById("ww331-notif-scroll");
    s.scrollTop=Math.min(s.scrollHeight-s.clientHeight,180+k*55);
    await wait(80);
    const before=s.scrollTop,identity=s;
    const btn=[].slice.call(s.querySelectorAll('button[title="Отметить прочитанным"]')).find(b=>b.closest(".ww331-row").getBoundingClientRect().top>s.getBoundingClientRect().top+80);
    const key=btn.closest(".ww331-row").getAttribute("data-ww47-key");
    btn.click();await wait(250);
    const afterEl=document.getElementById("ww331-notif-scroll");
    const row=[].find.call(afterEl.querySelectorAll(".ww331-row"),x=>x.getAttribute("data-ww47-key")===key);
    return{before,after:afterEl.scrollTop,delta:afterEl.scrollTop-before,sameContainer:afterEl===identity,read:/прочитано/.test(row.textContent),stillOpen:document.getElementById("overlay").classList.contains("open"),badge:(document.querySelector("#modal .mhead .badge")||{}).textContent||""};
   },k);steps.push(r);
  }
  const all=await p.evaluate(async()=>{
   const wait=ms=>new Promise(r=>setTimeout(r,ms));const s=document.getElementById("ww331-notif-scroll");s.scrollTop=Math.min(s.scrollHeight-s.clientHeight,260);await wait(50);const before=s.scrollTop,identity=s;ww331MarkAllRead();await wait(250);const a=document.getElementById("ww331-notif-scroll");return{before,after:a.scrollTop,delta:a.scrollTop-before,sameContainer:a===identity,unread:a.querySelectorAll(".ww331-unread").length,checks:a.querySelectorAll('button[title="Отметить прочитанным"]').length,readLabels:a.querySelectorAll(".ww47-read").length,badge:!!document.querySelector("#modal .mhead .badge")};
  });
  console.log(label+"_INIT",JSON.stringify(init));console.log(label+"_STEPS",JSON.stringify(steps));console.log(label+"_ALL",JSON.stringify(all));
  if(label==="MOBILE")await p.screenshot({path:"/data/a347-notifications.png"});
  await c.close();
 }
 await run({width:390,height:844},true,"MOBILE");
 await run({width:1280,height:950},false,"DESKTOP");
 console.log("ERRORS",JSON.stringify(errors));
 await browser.close();
})();
