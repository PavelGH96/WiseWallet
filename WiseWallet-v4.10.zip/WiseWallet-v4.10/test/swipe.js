const { chromium } = require('playwright');
const FILE = process.env.WW_APP || 'file://' + require('path').resolve(__dirname, '../index.html');
const SESSION = { access_token: 'x.y.z', refresh_token: 'r', expires_at: Date.now() + 3600e3, user_id: '00000000-0000-4000-8000-000000000001', email: 'sw@test.local' };
const fails = [];
const check = (name, ok, detail) => { console.log((ok ? '  ok   ' : '  FAIL ') + name + (detail === undefined ? '' : '  -> ' + JSON.stringify(detail))); if (!ok) fails.push(name); };

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true, deviceScaleFactor: 2 });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text())) errors.push('CONSOLE: ' + m.text()); });

  await page.goto(FILE);
  await page.evaluate(s => localStorage.setItem('ww_session_v2', JSON.stringify(s)), SESSION);
  await page.goto(FILE);
  await page.waitForTimeout(1800);

  // Сею задачи во все колонки
  await page.evaluate(() => {
    const off = n => { const d = new Date(); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10); };
    S.tasks = [];
    for (let i = 0; i < 6; i++) S.tasks.push({ id: uid(), text: 'Просрочено ' + i, date: off(-2), who: 'me', prio: 'high', done: false });
    S.tasks.push({ id: uid(), text: 'Завтра', date: off(1), who: 'me', prio: 'mid', done: false });
    S.tasks.push({ id: uid(), text: 'На неделе', date: off(4), who: 'me', prio: 'low', done: false });
    S.tasks.push({ id: uid(), text: 'Без даты', date: null, who: 'me', prio: 'mid', done: false });
    save();
    nav('planner');
  });
  await page.waitForTimeout(700);

  // ---------- 1. колонки в ряд, как в CRM ----------
  console.log('\nКолонки планировщика');
  const cols = await page.evaluate(() => {
    const kb = document.getElementById('kanban');
    const cs = getComputedStyle(kb);
    const list = [...kb.querySelectorAll('.kb-col')].map(c => {
      const r = c.getBoundingClientRect();
      return { title: (c.querySelector('.kb-title span') || {}).textContent, top: Math.round(r.top), left: Math.round(r.left), w: Math.round(r.width), cards: c.querySelectorAll('.task-card').length, caret: !!c.querySelector('.ww54-caret') };
    });
    return { dir: cs.flexDirection, overflowX: cs.overflowX, scrollW: kb.scrollWidth, clientW: kb.clientWidth, list };
  });
  console.log('COLS', JSON.stringify(cols, null, 1));
  check('колонки выстроены в ряд', cols.dir === 'row', cols.dir);
  check('все колонки на одном уровне', new Set(cols.list.map(c => c.top)).size === 1, cols.list.map(c => c.top));
  check('колонки листаются горизонтально', cols.scrollW > cols.clientW + 50, { scrollW: cols.scrollW, clientW: cols.clientW });
  check('у всех заголовков есть стрелка', cols.list.every(c => c.caret));
  check('задачи разложены по колонкам', cols.list.map(c => c.cards).slice(0, 4).join(',') === '6,1,1,1', cols.list.map(c => c.cards));

  // ---------- 2. сворачивание колонки и память ----------
  await page.evaluate(() => document.querySelector('#kanban .kb-col .kb-head').click());
  await page.waitForTimeout(250);
  const collapsed = await page.evaluate(() => {
    const c = document.querySelector('#kanban .kb-col');
    return { on: c.classList.contains('ww54-collapsed'), cardsVisible: !!c.querySelector('.kb-cards').offsetParent, stored: localStorage.getItem('ww54_cols_v1') };
  });
  check('колонка сворачивается', collapsed.on === true && collapsed.cardsVisible === false, collapsed);
  await page.evaluate(() => renderPlanner());
  await page.waitForTimeout(200);
  check('состояние живёт после перерисовки', await page.evaluate(() => document.querySelector('#kanban .kb-col').classList.contains('ww54-collapsed')));
  await page.evaluate(() => document.querySelector('#kanban .kb-col .kb-head').click());
  await page.waitForTimeout(250);
  check('колонка раскрывается обратно', await page.evaluate(() => !document.querySelector('#kanban .kb-col').classList.contains('ww54-collapsed')));

  // ---------- 3. свайп вкладок по содержимому ----------
  console.log('\nСвайп между вкладками');
  const order = await page.evaluate(() => [...document.querySelectorAll('.bottom-nav .bn-item[data-nav]')].map(b => b.dataset.nav));
  console.log('NAV ORDER', JSON.stringify(order));

  async function swipeOn(selector, dir) {
    const box = await page.locator(selector).first().boundingBox();
    const y = Math.round(box.y + Math.min(box.height / 2, 30));
    // жест должен быть длиннее порога (70px), поэтому не ограничиваемся шириной элемента
    const vw = 390, travel = 200;
    const cx = Math.min(Math.max(box.x + box.width / 2, travel / 2 + 10), vw - travel / 2 - 10);
    const from = dir === 'left' ? cx + travel / 2 : cx - travel / 2;
    const to = dir === 'left' ? cx - travel / 2 : cx + travel / 2;
    await page.touchscreen.tap(1, 1).catch(() => {});
    await page.evaluate(({ x, y }) => {
      const t = (type, cx) => { const ev = new TouchEvent(type, { bubbles: true, cancelable: true, touches: type === 'touchend' ? [] : [new Touch({ identifier: 1, target: document.elementFromPoint(cx, y) || document.body, clientX: cx, clientY: y })], changedTouches: [new Touch({ identifier: 1, target: document.elementFromPoint(cx, y) || document.body, clientX: cx, clientY: y })] }); (document.elementFromPoint(cx, y) || document.body).dispatchEvent(ev); };
      window.__swipeSteps = [];
      t('touchstart', x.from);
      for (let i = 1; i <= 8; i++) t('touchmove', x.from + (x.to - x.from) * i / 8);
      t('touchend', x.to);
    }, { x: { from, to }, y });
    await page.waitForTimeout(450);
  }

  const startPage = await page.evaluate(() => activePage());
  await swipeOn('#kanban .task-card', 'left');
  const afterCard = await page.evaluate(() => activePage());
  check('свайп по карточке задачи не ломает колонки (канбан листается сам)', afterCard === startPage, { startPage, afterCard });

  await page.evaluate(() => nav('dashboard'));
  await page.waitForTimeout(600);
  const p0 = await page.evaluate(() => activePage());
  await swipeOn('#page-dashboard .card', 'left');
  const p1 = await page.evaluate(() => activePage());
  // v3.66: смена вкладки свайпом работает только в полосе нижнего меню —
  // на основном экране жест намеренно не ловится (мешал листать списки).
  check('свайп по карточке дашборда НЕ меняет вкладку', p1 === p0, { p0, p1 });

  const p2before = await page.evaluate(() => activePage());
  // Свайп ВЛЕВО = следующий раздел. Раньше тут был 'right', и проверка проходила
  // лишь потому, что предыдущий шаг успевал увести с первого пункта меню.
  // С v3.66 свайп по контенту раздел не меняет, поэтому мы остаёмся на дашборде —
  // а он первый в меню, и «предыдущего» раздела у него нет.
  await swipeOn('.bottom-nav .bn-item', 'left');
  const p2 = await page.evaluate(() => activePage());
  check('свайп по кнопке нижней панели тоже работает', p2 !== p2before, { p2before, p2 });

  const btnPage = await page.evaluate(() => activePage());
  await swipeOn('.bottom-nav .bn-item', 'left');
  const afterBtn = await page.evaluate(() => activePage());
  check('свайп не вызывает ложное нажатие кнопки', afterBtn !== btnPage, { btnPage, afterBtn });

  const modal = await page.evaluate(() => document.getElementById('overlay').classList.contains('open'));
  check('модалка не открылась от свайпа', modal === false);

  // ---------- 4. обычное нажатие работает ----------
  await page.evaluate(() => nav('planner'));
  await page.waitForTimeout(500);
  await page.locator('#kanban .task-card .task-text').first().click();
  await page.waitForTimeout(400);
  check('клик по задаче открывает карточку', await page.evaluate(() => document.getElementById('overlay').classList.contains('open')));
  await page.evaluate(() => closeModal());
  await page.waitForTimeout(300);

  // ---------- 5. на ПК ничего не сломалось ----------
  const desk = await ctx.newPage();
  desk.on('pageerror', e => errors.push('DESKTOP: ' + e.message));
  await desk.setViewportSize({ width: 1280, height: 900 });
  await desk.goto(FILE);
  await desk.waitForTimeout(1600);
  await desk.evaluate(() => nav('planner'));
  await desk.waitForTimeout(600);
  const deskCols = await desk.evaluate(() => {
    const kb = document.getElementById('kanban');
    return { dir: getComputedStyle(kb).flexDirection, n: kb.querySelectorAll('.kb-col').length, sameRow: new Set([...kb.querySelectorAll('.kb-col')].map(c => Math.round(c.getBoundingClientRect().top))).size, noHScroll: kb.scrollWidth <= kb.clientWidth + 2, version: WW_VERSION };
  });
  console.log('DESKTOP', JSON.stringify(deskCols));
  check('на ПК колонки в ряд без лишней прокрутки', deskCols.dir === 'row' && deskCols.n >= 4 && deskCols.sameRow === 1 && deskCols.noHScroll, deskCols);
  check('версия приложения задана', /^\d+\.\d+$/.test(String(deskCols.version)), deskCols.version);

  console.log('\nERRORS', JSON.stringify(errors));
  if (errors.length) fails.push('ошибки в консоли');
  await browser.close();
  console.log(fails.length ? '\nПРОВАЛЫ: ' + JSON.stringify(fails) : '\nВсе проверки прошли');
  process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
