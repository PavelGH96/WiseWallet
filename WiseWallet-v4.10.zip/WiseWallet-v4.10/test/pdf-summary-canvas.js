/* Тесты v3.73: текстовое резюме теперь есть и в «Скачать PDF» (canvas-путь),
   не только в печати/файле HTML. Оба пути берут фразы из общей функции
   wwReportSummaryLines — сверяем, что они дословно совпадают. */
const { chromium } = require('playwright');
const path = require('path');
const FILE = 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const p = await (await b.newContext({ viewport: { width: 1440, height: 900 } })).newPage();
  const errors = [];
  p.on('pageerror', e => errors.push(e.message));
  p.on('console', m => { if (m.type() === 'error' && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text())) errors.push(m.text()); });
  await p.goto(FILE);
  await p.waitForTimeout(1600);
  await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
  await p.evaluate(() => { window.print = function () {}; });

  await p.evaluate(() => {
    const ex = S.categories.filter(c => c.type === 'expense');
    const inc = S.categories.find(c => c.type === 'income').id;
    const t = todayStr();
    S.transactions = [
      { id: 'i1', date: t, type: 'income', amount: 150000, accountId: S.accounts[0].id, categoryId: inc, note: '', tags: [], createdAt: 1 },
      { id: 'e1', date: t, type: 'expense', amount: 50000, accountId: S.accounts[0].id, categoryId: ex[0].id, note: '', tags: [], createdAt: 2 },
      { id: 'e2', date: t, type: 'expense', amount: 20000, accountId: S.accounts[0].id, categoryId: ex[1].id, note: '', tags: [], createdAt: 3 },
    ];
    save();
  });

  // функция для сборки PDF-blob доступна
  check('window.ww53BuildPdf доступна', await p.evaluate(() => typeof ww53BuildPdf === 'function'));

  // PDF реально строится без ошибок (тот путь, что использует кнопка «Скачать PDF»)
  const built = await p.evaluate(async () => {
    const blob = await ww53BuildPdf(ww43Period());
    return { size: blob.size, type: blob.type };
  });
  check('PDF-файл строится (кнопка «Скачать PDF»)', built.type === 'application/pdf' && built.size > 1000, built);

  // фразы резюме доступны из общей функции и совпадают с html-версией
  const linesCanvas = await p.evaluate(() => wwReportSummaryLines(ww43Collect(ww43Period())));
  check('резюме для canvas-пути не пустое', linesCanvas.length > 0, linesCanvas);
  check('резюме упоминает верную разницу (80 000)', /80\s*000/.test(linesCanvas[0].replace(/\u00a0/g, ' ')), linesCanvas[0]);

  // html-путь (печать/файл) использует ТУ ЖЕ функцию — сверяем дословно
  await p.evaluate(() => { try { ww43ToPdf(); } catch (e) {} });
  await p.waitForTimeout(500);
  const htmlSummaryText = await p.evaluate(() => {
    const el = document.querySelector('#ww43-print .ww43-summary');
    return el ? [...el.querySelectorAll('p')].map(p => p.textContent) : [];
  });
  check('текст резюме в html-пути совпадает дословно с canvas-путём', JSON.stringify(htmlSummaryText) === JSON.stringify(linesCanvas), { html: htmlSummaryText, canvas: linesCanvas });

  // пустой период не ломает построение PDF
  await p.evaluate(() => { S.transactions = []; S.credits = []; S.recurring = []; save(); });
  const builtEmpty = await p.evaluate(async () => {
    try { const blob = await ww53BuildPdf(ww43Period()); return { ok: true, size: blob.size }; }
    catch (e) { return { ok: false, err: e.message }; }
  });
  check('PDF строится и для пустого периода', builtEmpty.ok, builtEmpty);

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));
  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})();
