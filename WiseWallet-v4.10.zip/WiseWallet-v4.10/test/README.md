# Тесты WiseWallet

Одна команда прогоняет все наборы сразу:

```bash
bash test/run-all.sh        # сам доставит playwright при необходимости
npm test                   # то же самое, если playwright уже установлен
node test/run-all.js search-and-lists   # только один набор
```

В конце выводится сводка «Итог: N из M наборов тестов прошли», код возврата 0 — всё зелёное.
Подробные логи по каждому набору — в `test/last-run-<имя>.log`.

Наборы: search-and-lists (поиск Ctrl+K, виртуализация, подписи полей), recovery (восстановление пароля),
amounts, swipe, pdf-report, notifications, navigation, settings, icons, section-order, audit (общий аудит),
smoke, vault.

Переменные: `CHROME_PATH` — путь к Chrome/Chromium, `WW_APP` — адрес проверяемого index.html.
