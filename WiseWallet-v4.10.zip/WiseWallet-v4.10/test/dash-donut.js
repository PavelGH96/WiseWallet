/* Тест v3.97: кольцевая диаграмма «Расходы» на дашборде замкнута полностью.

   Регрессия, которую он ловит: список под диаграммой показывает только
   топ-6 категорий, а в drawDonut раньше передавалась ОБЩАЯ сумма расходов
   (со всеми категориями). При семи и более категориях сумма долек не
   дотягивала до полного круга — в кольце оставался видимый разрыв.
   В «Аналитике» этого не было: там total считается из того же списка,
   что и рисуется.

   Проверяем по пикселям: идём по средней линии кольца с шагом 1° и ищем
   ПОДРЯД идущие прозрачные точки. Маленькие разрывы (1–4°) — это штатные
   декоративные зазоры между дольками (GAP в drawDonut). Всё, что длиннее,
   означает незакрытый сектор. */
const { chromium } = require('playwright');
const path = require('path');
const FILE = process.env.WW_APP || 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

async function ringGaps(page, canvasId) {
  /* v4.05: графики теперь анимируются при появлении на экране, поэтому холст
     ниже сгиба до прокрутки намеренно пуст. Прокручиваем к нему и ждём конца
     анимации, иначе замер пикселей увидит пустое кольцо. */
  await page.evaluate((id) => { const c = document.getElementById(id); if (c) c.scrollIntoView({ block: 'center' }); }, canvasId);
  await page.waitForTimeout(900);
  return page.evaluate((id) => {
    const cv = document.getElementById(id);
    const ctx = cv.getContext('2d');
    const w = cv.width, h = cv.height;
    const cx = w / 2, cy = h / 2;
    const R = Math.min(w, h) / 2 - 16;
    const ringR = R - Math.max(24, Math.round(R * 0.34)) / 2;
    const gapDegs = [];
    for (let deg = 0; deg < 360; deg++) {
      const rad = deg * Math.PI / 180;
      const x = Math.round(cx + ringR * Math.cos(rad));
      const y = Math.round(cy + ringR * Math.sin(rad));
      if (x < 0 || y < 0 || x >= w || y >= h) continue;
      if (ctx.getImageData(x, y, 1, 1).data[3] < 10) gapDegs.push(deg);
    }
    let longestRun = 0, curRun = 0, prev = -10;
    gapDegs.forEach((d) => { curRun = (d === prev + 1) ? curRun + 1 : 1; longestRun = Math.max(longestRun, curRun); prev = d; });
    return { longestRun, gapCount: gapDegs.length };
  }, canvasId);
}

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const p = await (await b.newContext({ viewport: { width: 1400, height: 900 } })).newPage();
  const errors = [];
  p.on('pageerror', e => errors.push(e.message));

  await p.goto(FILE);
  await p.waitForTimeout(1600);
  await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
  await p.waitForTimeout(400);

  /* 7 категорий расходов — на одну больше, чем показывает список (топ-6) */
  await p.evaluate(() => {
    S.categories = S.categories.filter(c => c.type !== 'expense').concat(
      ['Кредиты', 'Катя', 'Перевод', 'Развлечения', 'Быт', 'Кафе', 'Прочее'].map((n, i) => ({ id: 'xc' + i, name: n, type: 'expense', icon: '📌' }))
    );
    const d = todayStr().slice(0, 8) + '05';
    S.transactions = S.transactions.filter(t => t.type !== 'expense');
    [112067, 59050, 32358, 13555, 9700, 8950, 27801].forEach((amt, i) => {
      S.transactions.push({ id: 'tx' + i, type: 'expense', categoryId: 'xc' + i, amount: amt, date: d, accountId: (S.accounts[0] || {}).id || 'a1' });
    });
    save(); nav('dashboard');
  });
  await p.waitForTimeout(900);

  const dash = await ringGaps(p, 'dash-donut');
  check('КЛЮЧЕВОЕ: кольцо на дашборде замкнуто при 7 категориях', dash.longestRun <= 4, dash);

  /* центр кольца по-прежнему показывает полную сумму, а не сумму топ-6 */
  const centre = await p.evaluate(() => {
    const exp = S.transactions.filter(t => t.type === 'expense').reduce((s, t) => s + +t.amount, 0);
    const top6 = Object.entries(S.transactions.filter(t => t.type === 'expense')
      .reduce((a, t) => { a[t.categoryId] = (a[t.categoryId] || 0) + +t.amount; return a; }, {}))
      .sort((a, b) => b[1] - a[1]).slice(0, 6).reduce((s, [, v]) => s + v, 0);
    return { exp, top6 };
  });
  check('сумма всех расходов больше суммы топ-6 (сценарий воспроизведён)', centre.exp > centre.top6, centre);

  /* и ровно 6 строк в списке под диаграммой */
  const rows = await p.evaluate(() => document.querySelectorAll('#dash-cats .row').length);
  check('под диаграммой по-прежнему топ-6 категорий', rows === 6, rows);

  /* контроль: при 4 категориях (меньше лимита) кольцо тоже замкнуто */
  await p.evaluate(() => {
    S.transactions = S.transactions.filter(t => t.categoryId === 'xc0' || t.categoryId === 'xc1' || t.categoryId === 'xc2' || t.categoryId === 'xc3');
    save(); render('dashboard');
  });
  await p.waitForTimeout(900);
  const few = await ringGaps(p, 'dash-donut');
  check('кольцо замкнуто и при 4 категориях (регрессия не внесена)', few.longestRun <= 4, few);

  /* «Аналитика» как была, так и осталась корректной */
  await p.evaluate(() => nav('analytics'));
  await p.waitForTimeout(900);
  const an = await ringGaps(p, 'chart-donut');
  check('кольцо в «Аналитике» тоже замкнуто', an.longestRun <= 4, an);

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));
  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
