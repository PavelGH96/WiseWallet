/* Тесты v4.10: разряды в суммах и отсутствие диктовки в полях суммы.

   1) Сумма показывается как «200 000», а не «200000». Тонкость: поле остаётся
      полем ввода, и если вставлять разделители прямо во время набора, курсор
      прыгает. Поэтому разряды видны, когда поле не в фокусе, а при заходе в
      него возвращается «сырое» число.
   2) В полях, куда вводят только сумму, микрофон убран. Проверяем и то, что
      в текстовых полях (название, комментарий, поиск) он остался. */
const { chromium } = require('playwright');
const path = require('path');
const FILE = process.env.WW_APP || 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };
const NB = '\u202F';   // узкий неразрывный пробел — им разделяются разряды

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const p = await (await b.newContext({ viewport: { width: 1400, height: 950 } })).newPage();
  const errors = [];
  p.on('pageerror', e => errors.push(e.message));
  await p.goto(FILE); await p.waitForTimeout(1600);
  await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
  await p.waitForTimeout(300);

  console.log('=== 1. Форматирование чисел ===');
  const g = await p.evaluate(() => ({
    a: ww410Group(200000), b: ww410Group(1500000), c: ww410Group(999),
    d: ww410Group(12345678), e: ww410Group(1234.5), f: ww410Group(0),
    strip: ww410Strip('200\u202F000'), strip2: ww410Strip('1 234'),
  }));
  check('200000 → 200 000', g.a === '200' + NB + '000', g.a);
  check('1500000 → 1 500 000', g.b === '1' + NB + '500' + NB + '000', g.b);
  check('трёхзначное не разбивается', g.c === '999', g.c);
  check('12345678 → 12 345 678', g.d === '12' + NB + '345' + NB + '678', g.d);
  check('копейки сохраняются', g.e === '1' + NB + '234,50', g.e);
  check('разделители снимаются обратно', g.strip === '200000' && g.strip2 === '1234', g);

  console.log('\n=== 2. Помесячная сумма регулярного дохода ===');
  await p.evaluate(() => {
    S.recurring = (S.recurring || []).filter(r => r.type !== 'income');
    const c = (S.categories || []).find(x => x.type === 'income') || { id: 'ic1' };
    S.recurring.push({ id: 'ri1', type: 'income', name: 'Заработная плата', categoryId: c.id, amount: 200000, day: 15 });
    S.recurIncomeAmt = {}; save(); nav('credits');
  });
  await p.waitForTimeout(400);
  await p.evaluate(() => ww63Tab('inc'));
  await p.waitForTimeout(800);

  const shown = await p.evaluate(() => {
    const i = document.querySelector('#ww63-recur input.ww89-plan[data-id="ri1"]');
    const row = i.closest('.row');
    return { value: i.value, mic: !!row.querySelector('.ww61-mic') };
  });
  check('КЛЮЧЕВОЕ: сумма показана с разделителями', shown.value === '200' + NB + '000', shown.value);
  check('КЛЮЧЕВОЕ: микрофона в строке суммы нет', shown.mic === false, shown);

  const focused = await p.evaluate(() => {
    const i = document.querySelector('#ww63-recur input.ww89-plan[data-id="ri1"]');
    i.focus(); ww410Unformat(i);
    return i.value;
  });
  check('при фокусе поле показывает «сырое» число — править удобно', focused === '200000', focused);

  const edited = await p.evaluate(() => {
    const i = document.querySelector('#ww63-recur input.ww89-plan[data-id="ri1"]');
    i.value = '250000';
    i.dispatchEvent(new Event('change', { bubbles: true }));
    ww410Format(i);
    return { field: i.value, stored: S.recurIncomeAmt[Object.keys(S.recurIncomeAmt)[0]], tpl: S.recurring.find(r => r.id === 'ri1').amount };
  });
  check('после правки поле снова с разделителями', edited.field === '250' + NB + '000', edited.field);
  check('сохранилось правильное число, а не строка с пробелами', edited.stored === 250000, edited);
  check('шаблон при этом не тронут (помесячность цела)', edited.tpl === 200000, edited.tpl);

  /* значение, введённое С разделителями, тоже должно разобраться */
  const withSep = await p.evaluate(() => {
    const i = document.querySelector('#ww63-recur input.ww89-plan[data-id="ri1"]');
    i.value = '180' + '\u202F' + '000';
    i.dispatchEvent(new Event('change', { bubbles: true }));
    return S.recurIncomeAmt[Object.keys(S.recurIncomeAmt)[0]];
  });
  check('КЛЮЧЕВОЕ: сумма с разделителями разбирается верно', withSep === 180000, withSep);

  console.log('\n=== 3. Форма операции ===');
  await p.evaluate(() => { closeModal(); openTxModal(); });
  /* микрофоны навешиваются асинхронно (наблюдатель за DOM), поэтому ждём */
  await p.waitForTimeout(600);
  const tx = await p.evaluate(() => {
    const a = document.getElementById('tx-amount');
    /* у tx-note свой собственный микрофон (не .ww61-mic), поэтому для проверки
       «в текстовых полях диктовка осталась» берём обычное поле меток. */
    const tags = document.getElementById('tx-tags');
    return {
      amountMic: !!(a.parentElement && a.parentElement.querySelector && a.parentElement.querySelector('.ww61-mic')),
      tagsMic: !!(tags && tags.parentElement && tags.parentElement.querySelector && tags.parentElement.querySelector('.ww61-mic')),
    };
  });
  check('КЛЮЧЕВОЕ: в поле суммы микрофона нет', tx.amountMic === false, tx);
  check('в текстовом поле (метки) микрофон остался', tx.tagsMic === true, tx);

  const calc = await p.evaluate(() => {
    const a = document.getElementById('tx-amount');
    a.value = '450+120'; wwApplyCalc(a); ww410Format(a);
    return a.value;
  });
  check('выражение считается и форматируется', calc === '570', calc);

  const saved = await p.evaluate(() => {
    const a = document.getElementById('tx-amount');
    a.value = '200' + '\u202F' + '000';
    txCat = (S.categories.find(c => c.type === 'expense') || {}).id;
    ww80PickWhose('me', document.querySelector('#tx-whose button'));
    saveTx();
    const t = S.transactions[S.transactions.length - 1];
    return t ? t.amount : null;
  });
  check('КЛЮЧЕВОЕ: сумма с разделителями сохраняется как число', saved === 200000, saved);

  console.log('\n=== 4. Разделение чека понимает разделители ===');
  await p.evaluate(() => { closeModal(); openTxModal(); });
  await p.waitForTimeout(400);
  const split = await p.evaluate(() => {
    document.getElementById('tx-amount').value = '3' + '\u202F' + '000';
    const cats = S.categories.filter(c => c.type === 'expense');
    _txSplit = [{ cid: cats[0].id, amt: '2' + '\u202F' + '200' }, { cid: (cats[1] || cats[0]).id, amt: '800' }];
    ww403SplitRender();
    return { rest: document.getElementById('tx-split-rest').textContent, sum: ww403SplitSum() };
  });
  check('части с разделителями суммируются верно', split.sum === 3000 && /Разложено полностью/.test(split.rest), split);
  await p.evaluate(() => { _txSplit = null; closeModal(); });

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));
  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
