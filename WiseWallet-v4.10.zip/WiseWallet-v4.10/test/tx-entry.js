/* Тесты v4.03: три улучшения ежедневного ввода —
   повтор операции, арифметика в поле суммы, разделение чека по категориям. */
const { chromium } = require('playwright');
const path = require('path');
const FILE = process.env.WW_APP || 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const p = await (await b.newContext({ viewport: { width: 1400, height: 950 } })).newPage();
  const errors = [];
  p.on('pageerror', e => errors.push(e.message));

  await p.goto(FILE);
  await p.waitForTimeout(1600);
  await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
  await p.waitForTimeout(400);

  await p.evaluate(() => {
    S.categories = S.categories.filter(c => c.type !== 'expense').concat([
      { id: 'ce1', name: 'Еда', type: 'expense', icon: '🍎' },
      { id: 'ce2', name: 'Химия', type: 'expense', icon: '🧴' },
      { id: 'ce3', name: 'Кафе', type: 'expense', icon: '☕' },
    ]);
    S.transactions = [];
    save(); nav('ops');
  });
  await p.waitForTimeout(500);

  console.log('\n=== 1. Калькулятор в поле суммы ===');
  const calc = await p.evaluate(() => ({
    plus: wwCalcExpr('450+120'),
    minus: wwCalcExpr('1000-250,50'),
    mul: wwCalcExpr('3*150'),
    div: wwCalcExpr('900/4'),
    parens: wwCalcExpr('(200+100)*2'),
    comma: wwCalcExpr('10,5+1,5'),
    spaces: wwCalcExpr(' 450 + 120 '),
    plain: wwCalcExpr('450'),
    divZero: wwCalcExpr('10/0'),
    junk: wwCalcExpr('450+'),
    letters: wwCalcExpr('450+abc'),
    unbalanced: wwCalcExpr('(450+120'),
  }));
  check('сложение', calc.plus === 570, calc.plus);
  check('вычитание с запятой', calc.minus === 749.5, calc.minus);
  check('умножение и деление', calc.mul === 450 && calc.div === 225, [calc.mul, calc.div]);
  check('скобки и приоритет', calc.parens === 600, calc.parens);
  check('запятая как разделитель', calc.comma === 12, calc.comma);
  check('пробелы игнорируются', calc.spaces === 570, calc.spaces);
  check('обычное число проходит как есть', calc.plain === 450, calc.plain);
  check('КЛЮЧЕВОЕ: деление на ноль — ошибка, а не Infinity', calc.divZero === null, calc.divZero);
  check('КЛЮЧЕВОЕ: мусор отвергается, а не вычисляется', calc.junk === null && calc.letters === null && calc.unbalanced === null, calc);

  // защита от исполнения кода — парсер свой, не eval
  const evil = await p.evaluate(() => {
    window.__pwned = false;
    return { r: wwCalcExpr('(window.__pwned=true)||1'), pwned: window.__pwned };
  });
  check('КЛЮЧЕВОЕ: выражение не исполняет код (не eval)', evil.r === null && evil.pwned === false, evil);

  // сквозной сценарий: сумма-выражение сохраняется вычисленной
  await p.evaluate(() => { openTxModal(); });
  await p.waitForTimeout(300);
  await p.evaluate(() => {
    document.getElementById('tx-amount').value = '450+120';
    txCat = 'ce1';
    ww80PickWhose('me', document.querySelector('#tx-whose button'));
    saveTx();
  });
  await p.waitForTimeout(500);
  const saved = await p.evaluate(() => S.transactions.map(t => ({ a: t.amount, c: t.categoryId })));
  check('сумма-выражение сохраняется вычисленной (570, а не 450)', saved.length === 1 && saved[0].a === 570, saved);

  console.log('\n=== 2. Повтор операции ===');
  const dup = await p.evaluate(() => {
    const src = S.transactions[0];
    src.note = 'обед'; src.tags = ['работа']; src.date = '2020-01-05';
    save();
    dupTx(src.id);
    return {
      open: !!document.getElementById('tx-amount'),
      amount: document.getElementById('tx-amount').value,
      note: document.getElementById('tx-note').value,
      tags: document.getElementById('tx-tags').value,
      date: document.getElementById('tx-date').value,
      today: todayStr(),
      cat: txCat,
      editId: window._txEditId,
    };
  });
  check('форма открылась с заполненными полями образца', dup.open && +dup.amount === 570 && dup.note === 'обед' && dup.tags === 'работа', dup);
  check('категория взята из образца', dup.cat === 'ce1', dup.cat);
  check('КЛЮЧЕВОЕ: дата — сегодняшняя, а не из образца', dup.date === dup.today, { date: dup.date, today: dup.today });
  check('КЛЮЧЕВОЕ: это новая операция, а не правка старой', dup.editId === null, dup.editId);

  await p.evaluate(() => { document.getElementById('tx-amount').value = '300'; saveTx(); });
  await p.waitForTimeout(500);
  const afterDup = await p.evaluate(() => S.transactions.map(t => ({ a: t.amount, d: t.date, n: t.note })));
  check('повтор сохраняется отдельной операцией, образец не тронут', afterDup.length === 2 && afterDup.some(t => t.a === 570) && afterDup.some(t => t.a === 300), afterDup);

  console.log('\n=== 3. Разделение чека по категориям ===');
  await p.evaluate(() => { S.transactions = []; save(); openTxModal(); });
  await p.waitForTimeout(300);
  const splitUi = await p.evaluate(() => {
    document.getElementById('tx-amount').value = '3000';
    ww403SplitToggle();
    return {
      rows: document.querySelectorAll('.ww403-split-row').length,
      catHidden: document.getElementById('tx-cat-fg').style.display === 'none',
      rest: document.getElementById('tx-split-rest').textContent,
    };
  });
  check('режим разделения открывает две части и прячет одиночную категорию', splitUi.rows === 2 && splitUi.catHidden, splitUi);

  // сумма не сходится — сохранять нельзя
  const notBalanced = await p.evaluate(() => {
    _txSplit = [{ cid: 'ce1', amt: '2200' }, { cid: 'ce2', amt: '500' }];
    ww403SplitRender();
    ww80PickWhose('me', document.querySelector('#tx-whose button'));
    saveTx();
    return { count: S.transactions.length, rest: document.getElementById('tx-split-rest').textContent, open: !!document.getElementById('tx-amount') };
  });
  check('КЛЮЧЕВОЕ: несошедшийся чек не сохраняется', notBalanced.count === 0 && notBalanced.open, notBalanced);
  check('показан остаток к распределению', /Осталось разложить/.test(notBalanced.rest), notBalanced.rest);

  // перебор тоже блокируется
  const over = await p.evaluate(() => {
    _txSplit = [{ cid: 'ce1', amt: '2200' }, { cid: 'ce2', amt: '1200' }];
    ww403SplitRender();
    saveTx();
    return { count: S.transactions.length, rest: document.getElementById('tx-split-rest').textContent };
  });
  check('перебор по сумме тоже блокируется', over.count === 0 && /Перебор/.test(over.rest), over);

  // корректное разделение
  const okSplit = await p.evaluate(() => {
    _txSplit = [{ cid: 'ce1', amt: '2200' }, { cid: 'ce2', amt: '800' }];
    ww403SplitRender();
    const restTxt = document.getElementById('tx-split-rest').textContent;
    saveTx();
    return {
      restTxt,
      tx: S.transactions.map(t => ({ a: t.amount, c: t.categoryId, s: t.splitId, d: t.date, w: t.whose })),
    };
  });
  await p.waitForTimeout(400);
  check('«Разложено полностью» при сошедшейся сумме', /Разложено полностью/.test(okSplit.restTxt), okSplit.restTxt);
  check('КЛЮЧЕВОЕ: создано 2 операции по своим категориям', okSplit.tx.length === 2 && okSplit.tx.some(t => t.a === 2200 && t.c === 'ce1') && okSplit.tx.some(t => t.a === 800 && t.c === 'ce2'), okSplit.tx);
  check('части связаны общим splitId', okSplit.tx[0].s && okSplit.tx[0].s === okSplit.tx[1].s, okSplit.tx.map(t => t.s));
  check('пометка «чей расход» перенесена в обе части', okSplit.tx.every(t => t.w && t.w === okSplit.tx[0].w), okSplit.tx.map(t => t.w));

  // КЛЮЧЕВОЕ: суммы не задваиваются — нет «родительской» записи
  const totals = await p.evaluate(() => {
    const ym = todayStr().slice(0, 7);
    const monthSum = monthTx(ym).filter(t => t.type === 'expense').reduce((s, t) => s + +t.amount, 0);
    return { monthSum, count: S.transactions.length };
  });
  check('КЛЮЧЕВОЕ: итог месяца равен сумме чека (3000), без задвоения', totals.monthSum === 3000 && totals.count === 2, totals);

  // режим разделения не протекает в следующую форму
  const leak = await p.evaluate(() => { openTxModal(); return { split: _txSplit, rows: document.querySelectorAll('.ww403-split-row').length }; });
  check('режим разделения сброшен при открытии новой формы', leak.split === null && leak.rows === 0, leak);

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));
  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
