const { chromium } = require('playwright');
const FILE = process.env.WW_APP || 'file://' + require('path').resolve(__dirname, '../index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

async function swipe(page, fromX, fromY, toX, toY) {
  await page.evaluate(({ fromX, fromY, toX, toY }) => {
    const el = document.elementFromPoint(fromX, fromY) || document.body;
    const mk = (type, x, y) => {
      const t = new Touch({ identifier: 1, target: el, clientX: x, clientY: y });
      return new TouchEvent(type, { touches: type === 'touchend' ? [] : [t], changedTouches: [t], bubbles: true, cancelable: true });
    };
    el.dispatchEvent(mk('touchstart', fromX, fromY));
    const steps = 6;
    for (let i = 1; i <= steps; i++) {
      const x = fromX + (toX - fromX) * i / steps, y = fromY + (toY - fromY) * i / steps;
      el.dispatchEvent(mk('touchmove', x, y));
    }
    el.dispatchEvent(mk('touchend', toX, toY));
  }, { fromX, fromY, toX, toY });
  await page.waitForTimeout(400);
}

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH, args: ['--no-sandbox'] });
  const ctx = await b.newContext({ viewport: { width: 430, height: 932 }, isMobile: true, hasTouch: true, deviceScaleFactor: 3 });
  const p = await ctx.newPage();
  const errors = [];
  p.on('pageerror', e => errors.push(e.message));
  await p.goto(FILE);
  await p.waitForTimeout(1600);
  await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(id => { const e = document.getElementById(id); if (e) e.remove(); }); });
  await p.waitForTimeout(400);

  const navInfo = await p.evaluate(() => {
    const nb = document.querySelector('.bottom-nav');
    if (!nb) return null;
    const r = nb.getBoundingClientRect();
    return { y: Math.round(r.top + r.height / 2), visible: getComputedStyle(nb).display !== 'none', touch: getComputedStyle(nb).touchAction };
  });
  check('нижнее меню отображается на телефоне', !!(navInfo && navInfo.visible), navInfo);
  check('в меню разрешён горизонтальный жест', navInfo && /pan-x/.test(navInfo.touch), navInfo && navInfo.touch);

  const page0 = await p.evaluate(() => activePage());

  // === 1. Свайп по КОНТЕНТУ (середина экрана) — раздел меняться НЕ должен ===
  await swipe(p, 340, 400, 90, 400);
  const afterContent = await p.evaluate(() => activePage());
  check('свайп по основному экрану НЕ меняет раздел', afterContent === page0, { было: page0, стало: afterContent });

  // и в обратную сторону
  await swipe(p, 90, 500, 340, 500);
  const afterContent2 = await p.evaluate(() => activePage());
  check('свайп по контенту вправо тоже не меняет раздел', afterContent2 === page0, { стало: afterContent2 });

  // === 2. Свайп по НИЖНЕМУ МЕНЮ — раздел меняться должен ===
  const navY = navInfo.y;
  await swipe(p, 340, navY, 90, navY);
  const afterNav = await p.evaluate(() => activePage());
  check('свайп по нижнему меню переключает раздел', afterNav !== page0, { было: page0, стало: afterNav });

  // обратно
  await swipe(p, 90, navY, 340, navY);
  const backNav = await p.evaluate(() => activePage());
  check('свайп по меню в обратную сторону возвращает', backNav === page0, { стало: backNav });

  // === 3. Свайп по строке операции по-прежнему работает (удаление/правка) ===
  await p.evaluate(() => {
    S.transactions = [{ id: 'swipetx', date: todayStr(), type: 'expense', amount: 100, accountId: S.accounts[0].id, categoryId: S.categories.find(c => c.type === 'expense').id, note: 'тест свайпа', tags: [], createdAt: Date.now() }];
    save(); nav('ops');
  });
  await p.waitForTimeout(700);
  const rowBox = await p.evaluate(() => {
    const el = document.querySelector('#page-ops [data-sid="swipetx"]');
    if (!el) return null;
    const r = el.getBoundingClientRect();
    return { x: Math.round(r.left + r.width * 0.7), y: Math.round(r.top + r.height / 2) };
  });
  if (rowBox) {
    const pageBefore = await p.evaluate(() => activePage());
    await swipe(p, rowBox.x, rowBox.y, rowBox.x - 150, rowBox.y);
    await p.waitForTimeout(700);
    const res = await p.evaluate(() => ({ page: activePage(), gone: !S.transactions.some(t => t.id === 'swipetx') }));
    check('свайп по строке операции по-прежнему срабатывает', res.gone, res);
    check('при этом раздел не переключился', res.page === pageBefore, res.page);
  } else {
    check('строка операции найдена для проверки свайпа', false, 'не найдена');
  }

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));

  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})();
