/* Тесты v3.87: бейдж «льготный» и сумма платежа на странице
   «Расходы и доходы» должны зависеть от МЕСЯЦА, выбранного переключателем
   периода этой страницы, а не от сегодняшней даты.
   Было: currentPayment(c) смотрит на todayStr() → бейдж «льготный» продолжал
   показываться в октябре (после конца льготы 30.09), если сегодняшняя дата
   ещё укладывалась в льготный период. */
const { chromium } = require('playwright');
const path = require('path');
const FILE = 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const p = await (await b.newContext({ viewport: { width: 1600, height: 900 } })).newPage();
  const errors = [];
  p.on('pageerror', e => errors.push(e.message));
  p.on('console', m => { if (m.type() === 'error' && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text())) errors.push(m.text()); });
  await p.goto(FILE);
  await p.waitForTimeout(1600);
  await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
  await p.evaluate(() => {
    S.credits = [{ id: 'c1', name: 'Сбербанк кредит 1', type: 'П', lender: '', initial: 0, balance: 210173, balanceFull: 210173, payment: 6663, rate: 0, payDay: 30, start: '2026-04-07', end: '', status: 'active', graceFrom: '2026-04-07', graceTo: '2026-09-30', gracePayment: 529.29 }];
    save(); nav('credits');
  });
  await p.waitForTimeout(500);

  // === Список: месяц ВНУТРИ льготного периода ===
  await p.evaluate(() => crSetPeriod({ type: 'month', anchor: '2026-08' }));
  await p.waitForTimeout(500);
  const inGrace = await p.evaluate(() => {
    const row = document.querySelector('[data-sid="c1"]');
    return { grace: /льготный/i.test(row.textContent), text: row.textContent.replace(/\s+/g, ' ') };
  });
  check('август (внутри льготы): бейдж «льготный» показан', inGrace.grace === true, inGrace);

  // === Список: месяц ПОСЛЕ окончания льготного периода ===
  await p.evaluate(() => crSetPeriod({ type: 'month', anchor: '2026-10' }));
  await p.waitForTimeout(500);
  const afterGrace = await p.evaluate(() => {
    const row = document.querySelector('[data-sid="c1"]');
    return { grace: /льготный/i.test(row.textContent), amount: row.textContent.replace(/\u00a0/g, ' ') };
  });
  check('КЛЮЧЕВОЕ: октябрь (после льготы) — бейдж «льготный» НЕ показан', afterGrace.grace === false, afterGrace);
  check('в октябре показан полный платёж (6 663), а не льготный (529.29)', /6.?663/.test(afterGrace.amount) && !/529/.test(afterGrace.amount), afterGrace.amount.slice(0,300));

  // === То же самое в карточном виде ===
  await p.evaluate(() => { try { setViewMode('credits', 'cards'); } catch (e) {} });
  await p.waitForTimeout(600);
  const cardAfter = await p.evaluate(() => {
    const c = document.querySelector('.credit-card[data-sid="c1"]');
    return { grace: /льготный/i.test(c.querySelector('.credit-top').textContent) };
  });
  check('карточный вид тоже не показывает «льготный» в октябре', cardAfter.grace === false, cardAfter);

  await p.evaluate(() => { try { setViewMode('credits', 'list'); } catch (e) {} });
  await p.waitForTimeout(400);
  await p.evaluate(() => crSetPeriod({ type: 'month', anchor: '2026-08' }));
  await p.waitForTimeout(500);
  await p.evaluate(() => { try { setViewMode('credits', 'cards'); } catch (e) {} });
  await p.waitForTimeout(500);
  const cardBefore = await p.evaluate(() => {
    const c = document.querySelector('.credit-card[data-sid="c1"]');
    return { grace: /льготный/i.test(c.querySelector('.credit-top').textContent) };
  });
  check('карточный вид корректно показывает «льготный» внутри периода льготы', cardBefore.grace === true, cardBefore);

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));
  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})();
