/* =====================================================================
   WiseWallet — быстрый автотест (smoke). Запуск:

     npm i -D playwright        # один раз
     node test/smoke.js         # из папки с index.html

   Проверяет то, что всё равно ломалось тихо: ошибки в консоли, экран входа,
   редактирование операции без дублей, защиту от затирания данных и вёрстку
   на ширине iPhone. Любой провал — ненулевой код выхода.
   ===================================================================== */
const path = require("path");
const { chromium } = require("playwright");

const FILE = "file://" + path.resolve(__dirname, "..", "index.html");
const SESSION = {
  access_token: "smoke.jwt.token",
  refresh_token: "smoke.refresh",
  expires_at: Date.now() + 3600e3,
  user_id: "00000000-0000-4000-8000-000000000001",
  email: "smoke@example.com",
};

const fails = [];
function check(name, ok, detail) {
  console.log((ok ? "  ok   " : "  FAIL ") + name + (detail === undefined ? "" : "  → " + JSON.stringify(detail)));
  if (!ok) fails.push(name);
}

(async () => {
  const browser = await chromium.launch({
    executablePath: process.env.CHROME_PATH || undefined,
    args: ["--no-sandbox"],
  });
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  const page = await ctx.newPage();

  const errors = [];
  page.on("pageerror", (e) => errors.push(e.message));
  page.on("console", (m) => {
    const t = m.text();
    if (m.type() === "error" && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(t)) errors.push(t);
  });

  // ---------- вход обязателен ----------
  console.log("\nВход");
  await page.goto(FILE);
  await page.waitForTimeout(1500);
  const gate = await page.evaluate(() => ({
    gate: !!document.querySelector("#ww332-gate.on"),
    baked: WW332_BAKED,
    version: WW_VERSION,
  }));
  check("экран входа без сессии", gate.gate === true, gate);
  check("подключение зашито в файл", gate.baked === true);

  // ---------- приложение открывается с сессией ----------
  await page.evaluate((s) => localStorage.setItem("ww_session_v2", JSON.stringify(s)), SESSION);
  await page.goto(FILE);
  await page.waitForTimeout(2000);
  check("с сессией экран входа скрыт", (await page.evaluate(() => !document.querySelector("#ww332-gate.on"))) === true);

  // ---------- защита от затирания данных ----------
  console.log("\nЗащита данных");
  const guard = await page.evaluate(() => ({
    freshInstall: wwLooksUntouched({ transactions: [], budgets: [1, 2], goals: [1], recurring: [1, 2], audit: [] }),
    onlySettingsEdited: wwLooksUntouched({ transactions: [], audit: [{ id: "1", action: "update" }] }),
    withTx: wwLooksUntouched({ transactions: [{ id: "t" }] }),
    weight: wwPayloadWeight({ transactions: [1, 2], posted: { a: 1 } }),
  }));
  check("свежая установка считается пустой", guard.freshInstall === true, guard);
  check("настроенные лимиты/цели не считаются пустотой", guard.onlySettingsEdited === false);
  check("состояние с операциями не пустое", guard.withTx === false);
  check("вес состояния считается", guard.weight === 3);

  // ---------- добавление и редактирование операции ----------
  console.log("\nОперации");
  await page.evaluate(() => {
    S.transactions.unshift({
      id: "smoke-1", date: todayStr(), type: "expense", amount: 1234,
      accountId: S.accounts[0].id,
      categoryId: (S.categories.find((c) => c.type === "expense") || S.categories[0]).id,
      note: "smoke", tags: ["тест"], createdAt: Date.now(),
    });
    save(); render(activePage());
  });
  await page.evaluate(() => nav("ops"));
  await page.waitForTimeout(700);
  check("в списке есть кнопка правки", (await page.evaluate(() => document.querySelectorAll('[onclick*="editTx("]').length)) > 0);

  const edit = await page.evaluate(async () => {
    editTx("smoke-1");
    await new Promise((r) => setTimeout(r, 400));
    const filled = {
      amount: (document.getElementById("tx-amount") || {}).value,
      note: (document.getElementById("tx-note") || {}).value,
      acc: (document.getElementById("tx-acc") || {}).value,
    };
    const el = document.getElementById("tx-amount");
    if (el) el.value = "999";
    const save = [].slice.call(document.querySelectorAll("#modal button")).filter((b) => /Сохранить/.test(b.textContent))[0];
    if (save) save.click();
    await new Promise((r) => setTimeout(r, 700));
    const copies = S.transactions.filter((t) => t.id === "smoke-1");
    return { filled, copies: copies.length, amount: copies[0] && copies[0].amount };
  });
  check("модалка правки предзаполнена", edit.filled.amount === "1234" && edit.filled.note === "smoke", edit.filled);
  check("правка не создаёт дубль", edit.copies === 1, edit);
  check("новая сумма сохранилась", Number(edit.amount) === 999, edit);

  // ---------- функции блока v3.31 ----------
  console.log("\nФункции");
  const feats = await page.evaluate(() => ({
    notifs: ww331Notifs().length,
    tags: ww331AllTags().length,
    ics: (ww331BuildIcs() || "").split("BEGIN:VEVENT").length - 1,
    hotkeys: typeof ww331Hotkeys === "function",
    bulk: typeof ww331BulkDelete === "function",
    log: Array.isArray(S.audit),
  }));
  check("центр уведомлений", feats.notifs > 0, feats);
  check("теги", feats.tags > 0);
  check("экспорт в календарь", feats.ics > 0);
  check("горячие клавиши и массовые операции", feats.hotkeys && feats.bulk);
  check("журнал изменений", feats.log === true);

  // ---------- диаграмма в скрытом контейнере не падает ----------
  const donut = await page.evaluate(() => {
    const box = document.createElement("div");
    box.style.width = "0px";
    const cv = document.createElement("canvas");
    box.appendChild(cv);
    document.body.appendChild(box);
    try {
      drawDonut(cv, [["a", 10, "•"], ["b", 5, "•"]], 15, "тест");
      box.remove();
      return { threw: false };
    } catch (e) { box.remove(); return { threw: true, msg: e.message }; }
  });
  check("диаграмма без ширины не падает", donut.threw === false, donut);

  // ---------- мобильная ширина ----------
  console.log("\niPhone 390px");
  const m = await ctx.newPage();
  m.on("pageerror", (e) => errors.push("mobile: " + e.message));
  await m.setViewportSize({ width: 390, height: 844 });
  await m.goto(FILE);
  await m.waitForTimeout(600);
  await m.evaluate((s) => localStorage.setItem("ww_session_v2", JSON.stringify(s)), SESSION);
  await m.goto(FILE);
  await m.waitForTimeout(2000);
  for (const p of ["dash", "ops", "credits", "analytics", "settings", "dash"]) {
    await m.evaluate((x) => nav(x), p);
    await m.waitForTimeout(500);
    const sizes = await m.evaluate(() => ({ s: document.documentElement.scrollWidth, c: document.documentElement.clientWidth }));
    check("без горизонтального скролла: " + p, sizes.s <= sizes.c + 1, sizes);
  }
  const zoom = await m.evaluate(() => {
    const el = document.querySelector('meta[name="viewport"]');
    return el ? el.getAttribute("content") : "";
  });
  // v3.67: масштабирование запрещено намеренно — по требованию владельца.
  // На iPhone случайный «щипок» ломал вёрстку и сдвигал экран.
  check("пинч-зум запрещён", /user-scalable=no/.test(zoom) && /maximum-scale=1/.test(zoom), zoom);

  // ---------- ошибки ----------
  console.log("\nКонсоль");
  check("ни одной ошибки в консоли", errors.length === 0, errors.slice(0, 5));

  await browser.close();

  console.log("\n" + (fails.length ? "Провалов: " + fails.length + " — " + fails.join(", ") : "Все проверки прошли") + "\n");
  process.exit(fails.length ? 1 : 0);
})();
