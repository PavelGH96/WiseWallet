/* Тест v3.74: панель «Кошельки» на дашборде должна показывать баланс на конец
   ПРОСМАТРИВАЕМОГО периода, как и шапка «Свободные деньги» — а не баланс
   «на сегодня» всегда. Раньше при браузинге прошлого месяца эти два места
   расходились в цифрах. */
const { chromium } = require('playwright');
const path = require('path');
const FILE = 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const p = await (await b.newContext({ viewport: { width: 1440, height: 900 } })).newPage();
  const errors = [];
  p.on('pageerror', e => errors.push(e.message));
  p.on('console', m => { if (m.type() === 'error' && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text())) errors.push(m.text()); });
  await p.goto(FILE);
  await p.waitForTimeout(1600);
  await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });

  await p.evaluate(() => {
    const exp = S.categories.find(c => c.type === 'expense').id, inc = S.categories.find(c => c.type === 'income').id;
    S.credits = []; S.recurring = [];
    S.transactions = [
      { id: 'jul1', date: '2026-07-15', type: 'expense', amount: 42463, accountId: S.accounts[0].id, categoryId: exp, note: '', tags: [], createdAt: 1 },
      { id: 'aug1', date: '2026-08-20', type: 'income', amount: 29353, accountId: S.accounts[0].id, categoryId: inc, note: '', tags: [], createdAt: 2 },
    ];
    save(); nav('dashboard');
  });
  await p.waitForTimeout(500);

  // === Просмотр прошлого месяца: «Кошельки» = «Свободные деньги» ===
  await p.evaluate(() => ww26SetPeriod({ type: 'month', anchor: '2026-07' }));
  await p.waitForTimeout(500);
  const july = await p.evaluate(() => ({
    free: (typeof ww318Free === 'function') ? ww318Free().free : null,
    coinsTotal: document.getElementById('ww26-acc-total')?.textContent,
    coinAmt: document.querySelector('.coin.acc[data-acc] .camt')?.textContent,
  }));
  const norm = (s) => (s || '').replace(/\u00a0/g, ' ');
  check('«Кошельки» (итог) совпадают со «Свободные деньги» за июль', norm(july.coinsTotal) === '-42 463 ₽' && july.free === -42463, july);
  check('баланс отдельного счёта тоже на конец июля, а не на сегодня', norm(july.coinAmt) === '-42 463 ₽', july.coinAmt);

  // === Текущий месяц: по-прежнему баланс «на сегодня», без регрессии ===
  await p.evaluate(() => ww26SetPeriod({ type: 'month' }));
  await p.waitForTimeout(500);
  const cur = await p.evaluate(() => ({
    coinsTotal: document.getElementById('ww26-acc-total')?.textContent,
    todayBal: accBalance(S.accounts[0].id),
  }));
  check('в текущем месяце «Кошельки» показывают баланс на сегодня (без регрессии)', norm(cur.coinsTotal) === '-13 110 ₽' && cur.todayBal === -13110, cur);

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));
  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})();
