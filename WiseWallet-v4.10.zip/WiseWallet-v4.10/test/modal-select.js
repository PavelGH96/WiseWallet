/* Тест v4.06: выделение текста мышкой не закрывает окно.

   Регрессия, которую он ловит: на подложке висел onclick с проверкой
   event.target === this. Браузер шлёт click не по месту отпускания кнопки,
   а по ближайшему ОБЩЕМУ предку места нажатия и места отпускания. Поэтому
   «выделяю текст в поле и отпускаю кнопку за пределами окна» давало click
   с target = подложка, и окно закрывалось посреди заполнения формы, теряя
   введённое.

   Теперь окно закрывается, только если жест целиком прошёл по подложке. */
const { chromium } = require('playwright');
const path = require('path');
const FILE = process.env.WW_APP || 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

const isOpen = (p) => p.evaluate(() => document.getElementById('overlay').classList.contains('open'));

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const p = await (await b.newContext({ viewport: { width: 1400, height: 950 } })).newPage();
  const errors = [];
  p.on('pageerror', e => errors.push(e.message));
  await p.goto(FILE); await p.waitForTimeout(1600);
  await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
  await p.waitForTimeout(400);

  /* ---- 1. КЛЮЧЕВОЕ: выделение внутри формы с отпусканием снаружи ---- */
  await p.evaluate(() => openTxModal());
  await p.waitForTimeout(400);
  await p.evaluate(() => { document.getElementById('tx-note').value = 'важный комментарий'; });

  /* Тянем от ОБЫЧНОГО текста в окне (заголовок/подпись), а не от <input>:
     при перетаскивании из поля ввода Chrome click вообще не шлёт, и баг так
     не воспроизводится. А вот выделение обычного текста с отпусканием
     снаружи даёт click с target = подложка — это и есть жалоба. */
  const box = await p.evaluate(() => {
    const h = document.querySelector('#modal h3') || document.querySelector('#modal label') || document.getElementById('modal');
    const f = h.getBoundingClientRect();
    const m = document.getElementById('modal').getBoundingClientRect();
    return { fx: Math.round(f.left + 6), fy: Math.round(f.top + f.height / 2), outX: Math.round(m.left - 60), outY: Math.round(m.top + 40) };
  });
  await p.mouse.move(box.fx, box.fy);
  await p.mouse.down();
  await p.mouse.move(box.fx + 60, box.fy, { steps: 5 });
  await p.mouse.move(box.outX, box.outY, { steps: 8 });   // ушли за пределы окна
  await p.mouse.up();                                      // и отпустили там
  await p.waitForTimeout(300);

  check('КЛЮЧЕВОЕ: окно не закрылось при выделении с отпусканием снаружи', await isOpen(p) === true);
  check('введённые данные на месте', await p.evaluate(() => (document.getElementById('tx-note') || {}).value) === 'важный комментарий');

  /* ---- 2. Обратный случай: нажали на подложке, отпустили в окне ---- */
  await p.mouse.move(box.outX, box.outY);
  await p.mouse.down();
  await p.mouse.move(box.fx, box.fy, { steps: 6 });
  await p.mouse.up();
  await p.waitForTimeout(300);
  check('окно не закрылось, когда отпустили внутри него', await isOpen(p) === true);

  /* ---- 3. Обычный клик по подложке по-прежнему закрывает ---- */
  await p.mouse.move(box.outX, box.outY);
  await p.mouse.down();
  await p.mouse.up();
  await p.waitForTimeout(300);
  check('обычный клик по подложке закрывает окно (поведение сохранено)', await isOpen(p) === false);

  /* ---- 4. Крестик и Esc работают ---- */
  await p.evaluate(() => openTxModal());
  await p.waitForTimeout(300);
  await p.evaluate(() => { const x = document.querySelector('#modal .x'); if (x) x.click(); });
  await p.waitForTimeout(300);
  check('кнопка «✕» закрывает окно', await isOpen(p) === false);

  await p.evaluate(() => openTxModal());
  await p.waitForTimeout(300);
  await p.keyboard.press('Escape');
  await p.waitForTimeout(300);
  check('Esc закрывает окно', await isOpen(p) === false);

  /* ---- 5. То же для диалога подтверждения ---- */
  await p.evaluate(() => { window.__dlg = wwConfirm('Проверка', { title: 'Вопрос', okText: 'Да' }); });
  await p.waitForTimeout(400);
  const d = await p.evaluate(() => {
    const ov = document.getElementById('ww-dlg-ov'), dl = document.getElementById('ww-dlg');
    if (!ov || !dl) return null;
    const r = dl.getBoundingClientRect();
    return { inX: Math.round(r.left + r.width / 2), inY: Math.round(r.top + 30), outX: Math.round(r.left - 60), outY: Math.round(r.top + 40) };
  });
  if (d) {
    await p.mouse.move(d.inX, d.inY);
    await p.mouse.down();
    await p.mouse.move(d.outX, d.outY, { steps: 8 });
    await p.mouse.up();
    await p.waitForTimeout(300);
    const stillOpen = await p.evaluate(() => { const o = document.getElementById('ww-dlg-ov'); return !!o && o.classList.contains('open'); });
    check('КЛЮЧЕВОЕ: диалог подтверждения тоже не закрывается выделением', stillOpen === true);
    await p.mouse.move(d.outX, d.outY); await p.mouse.down(); await p.mouse.up();
    await p.waitForTimeout(300);
    check('клик по подложке диалога закрывает его', await p.evaluate(() => { const o = document.getElementById('ww-dlg-ov'); return !o || !o.classList.contains('open'); }) === true);
  } else {
    check('диалог подтверждения найден', false, 'нет #ww-dlg-ov');
  }

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));
  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
