/* Широкий аудит WiseWallet: все разделы, мобайл и ПК, ошибки, вёрстка, тач-цели. */
const { chromium } = require('playwright');
const FILE = process.env.WW_APP || 'file://' + require('path').resolve(__dirname, '../index.html');
const SESSION = { access_token: 'x.y.z', refresh_token: 'r', expires_at: Date.now() + 3600e3, user_id: '00000000-0000-4000-8000-000000000001', email: 'audit@test.local' };
const issues = [];
const notes = [];
const add = (sev, text) => { issues.push({ sev, text }); console.log('  [' + sev + '] ' + text); };
const okLine = t => console.log('  ok   ' + t);

async function setup(ctx) {
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text())) errors.push('CONSOLE: ' + m.text()); });
  await page.goto(FILE);
  await page.evaluate(s => localStorage.setItem('ww_session_v2', JSON.stringify(s)), SESSION);
  await page.goto(FILE);
  await page.waitForTimeout(1800);
  return { page, errors };
}

async function seed(page) {
  return await page.evaluate(() => {
    const a = S.accounts.filter(x => !x.archived)[0];
    const inc = S.categories.filter(c => c.type === 'income')[0];
    const exp = S.categories.filter(c => c.type === 'expense')[0];
    const t = todayStr();
    S.transactions = [];
    for (let i = 0; i < 12; i++) {
      S.transactions.push({ id: uid(), date: t, type: i % 3 === 0 ? 'income' : 'expense', amount: 100 * (i + 1), accountId: a.id, categoryId: i % 3 === 0 ? inc.id : exp.id, tags: i % 2 ? ['тест'] : [], note: 'Операция ' + i, createdAt: Date.now() - i * 1000 });
    }
    S.tasks = S.tasks || [];
    for (let i = 0; i < 6; i++) S.tasks.push({ id: uid(), summary: 'Задача ' + i, date: t, done: false, createdAt: Date.now() });
    save();
    return { acc: a.id, inc: inc.id, exp: exp.id, pages: (typeof ww40Order === 'function' ? 'ordered' : 'plain') };
  });
}

async function pages(page) {
  return await page.evaluate(() => {
    const out = [];
    document.querySelectorAll('[id^="page-"]').forEach(el => out.push(el.id.replace(/^page-/, '')));
    return out;
  });
}

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });

  /* ---------------- МОБИЛЬНЫЙ ---------------- */
  console.log('\n=== Мобильный iPhone 390×844 ===');
  const mctx = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true, deviceScaleFactor: 2 });
  const m = await setup(mctx);
  const seeded = await seed(m.page);
  notes.push('версия ' + (await m.page.evaluate(() => WW_VERSION)));

  const allPages = await pages(m.page);
  console.log('  разделы:', JSON.stringify(allPages));

  const REMOVED = ['budgets'];
  for (const p of allPages) {
    if (REMOVED.indexOf(p) !== -1) {
      const hidden = await m.page.evaluate(pg => {
        const el = document.getElementById('page-' + pg);
        return { hidden: !el || getComputedStyle(el).display === 'none', navBtns: document.querySelectorAll('[data-nav="' + pg + '"]').length };
      }, p);
      if (hidden.hidden && hidden.navBtns === 0) okLine('удалённый раздел «' + p + '» недоступен в интерфейсе, как и задумано');
      else add('Внимание', 'удалённый раздел «' + p + '» всё ещё достижим: ' + JSON.stringify(hidden));
      add('Код', 'в файле осталась разметка и код удалённого раздела «' + p + '», который прячется скриптом на старте — можно вырезать совсем');
      continue;
    }
    const before = m.errors.length;
    const res = await m.page.evaluate(async pg => {
      try { nav(pg); } catch (e) { return { err: String(e && e.message) }; }
      await new Promise(r => setTimeout(r, 260));
      const el = document.getElementById('page-' + pg);
      const vis = el && getComputedStyle(el).display !== 'none';
      const overflow = document.documentElement.scrollWidth - document.documentElement.clientWidth;
      let empty = false;
      if (el) empty = (el.textContent || '').trim().length < 3;
      return { vis: !!vis, overflow: overflow, empty: empty };
    }, p);
    if (res.err) add('Баг', 'раздел «' + p + '» не открывается: ' + res.err);
    else {
      if (!res.vis) add('Баг', 'раздел «' + p + '» после перехода остаётся скрытым');
      if (res.overflow > 2) add('Вёрстка', 'горизонтальная прокрутка в «' + p + '»: +' + res.overflow + 'px');
      if (res.empty) add('Внимание', 'раздел «' + p + '» выглядит пустым');
      if (m.errors.length > before) add('Ошибка', 'в «' + p + '»: ' + m.errors.slice(before).join(' | '));
      if (res.vis && res.overflow <= 2 && !res.empty && m.errors.length === before) okLine('раздел «' + p + '» открывается без ошибок');
    }
  }

  /* тач-цели меньше 36px */
  const small = await m.page.evaluate(() => {
    const bad = [];
    document.querySelectorAll('button, .bn-item, a[onclick], .coin-menu-btn, .ww331-bbtn').forEach(b => {
      const r = b.getBoundingClientRect();
      if (r.width === 0 || r.height === 0) return;
      if (r.height < 32 || r.width < 28) bad.push(((b.id || b.className || b.textContent || '').toString().trim().slice(0, 34)) + ' ' + Math.round(r.width) + '×' + Math.round(r.height));
    });
    return bad.slice(0, 12);
  });
  if (small.length) add('Удобство', 'мелкие кнопки (<32px высоты): ' + JSON.stringify(small));
  else okLine('все кнопки не меньше 32px');

  /* дубли id и пустые onclick */
  const dom = await m.page.evaluate(() => {
    const ids = {}, dup = [];
    document.querySelectorAll('[id]').forEach(el => { ids[el.id] = (ids[el.id] || 0) + 1; });
    Object.keys(ids).forEach(k => { if (ids[k] > 1) dup.push(k + '×' + ids[k]); });
    const broken = [];
    document.querySelectorAll('[onclick]').forEach(el => {
      const code = el.getAttribute('onclick') || '';
      const fn = (code.match(/^\s*([A-Za-z_$][\w$]*)\s*\(/) || [])[1];
      const KW = ['if', 'for', 'while', 'switch', 'return', 'typeof', 'catch', 'function', 'do'];
      if (fn && KW.indexOf(fn) === -1 && typeof window[fn] !== 'function') broken.push(fn);
    });
    return { dup: dup.slice(0, 15), broken: Array.from(new Set(broken)).slice(0, 15) };
  });
  if (dom.dup.length) add('Код', 'дублируются id элементов: ' + JSON.stringify(dom.dup));
  else okLine('дублей id нет');
  if (dom.broken.length) add('Баг', 'кнопки ссылаются на несуществующие функции: ' + JSON.stringify(dom.broken));
  else okLine('все obработчики onclick существуют');

  /* ключевые сценарии: добавление операции, undo, поиск, теги */
  const flows = await m.page.evaluate(async ids => {
    const out = {};
    const n0 = S.transactions.length;
    try {
      S.transactions.push({ id: uid(), date: todayStr(), type: 'expense', amount: 777, accountId: ids.acc, categoryId: ids.exp, tags: ['аудит'], createdAt: Date.now() });
      save(); render('ops'); await new Promise(r => setTimeout(r, 200));
      out.added = S.transactions.length === n0 + 1;
    } catch (e) { out.added = String(e.message); }
    out.balance = typeof accBalance === 'function' ? accBalance(ids.acc) : null;
    out.undo = typeof window.ww31Undo === 'function' || typeof window.wwUndo === 'function' || typeof undoLast === 'function';
    out.hotkeys = typeof window.ww31Hotkeys !== 'undefined' || !!document.querySelector('[data-hotkey]') || true;
    out.ics = typeof window.ww331ExportIcs === 'function';
    out.voice = typeof window.ww31Voice === 'function' || !!document.querySelector('[onclick*="oice"]');
    out.pdf = typeof window.ww53BuildPdf === 'function';
    out.notes = !!document.getElementById('page-vault') || !!document.getElementById('page-notes');
    return out;
  }, seeded);
  console.log('  сценарии:', JSON.stringify(flows));
  if (flows.added !== true) add('Баг', 'не удалось добавить операцию: ' + flows.added);
  if (!flows.pdf) add('Баг', 'генератор PDF недоступен');
  if (!flows.ics) add('Внимание', 'экспорт ICS не найден');

  /* localStorage размер и целостность состояния */
  const storage = await m.page.evaluate(() => {
    let total = 0;
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      total += (k.length + (localStorage.getItem(k) || '').length);
    }
    let parsed = null;
    try { parsed = JSON.parse(localStorage.getItem(LS_KEY) || 'null'); } catch (e) {}
    const orphanTx = (S.transactions || []).filter(t => t.accountId && !S.accounts.some(a => a.id === t.accountId)).length;
    const orphanCat = (S.transactions || []).filter(t => t.categoryId && !S.categories.some(c => c.id === t.categoryId)).length;
    return { kb: Math.round(total / 1024), keys: localStorage.length, hasState: !!parsed, orphanTx: orphanTx, orphanCat: orphanCat };
  });
  console.log('  хранилище:', JSON.stringify(storage));
  if (!storage.hasState) add('Баг', 'состояние не сохраняется в localStorage');
  if (storage.orphanTx || storage.orphanCat) add('Данные', 'есть операции без счёта/категории: ' + storage.orphanTx + '/' + storage.orphanCat);
  if (storage.kb > 4000) add('Производительность', 'хранилище уже ' + storage.kb + ' КБ — близко к лимитам localStorage (~5 МБ)');

  /* размер файла и скорость старта */
  const perf = await m.page.evaluate(() => {
    const n = performance.getEntriesByType('navigation')[0] || {};
    return { domReady: Math.round(n.domContentLoadedEventEnd || 0), load: Math.round(n.loadEventEnd || 0), nodes: document.querySelectorAll('*').length };
  });
  console.log('  старт:', JSON.stringify(perf));
  if (perf.nodes > 6000) add('Производительность', 'в DOM ' + perf.nodes + ' узлов — стоит виртуализировать длинные списки');

  /* много операций: скорость отрисовки списка */
  const stress = await m.page.evaluate(async ids => {
    const t = todayStr();
    const base = S.transactions.length;
    for (let i = 0; i < 1500; i++) {
      S.transactions.push({ id: uid(), date: t, type: 'expense', amount: 10 + (i % 90), accountId: ids.acc, categoryId: ids.exp, tags: [], note: 'stress ' + i, createdAt: Date.now() - i });
    }
    save();
    const t0 = performance.now();
    render('ops');
    await new Promise(r => setTimeout(r, 30));
    const t1 = performance.now();
    const rows = document.querySelectorAll('#page-ops .op-row, #page-ops tr, #page-ops .row').length;
    const t2 = performance.now();
    render('dashboard');
    await new Promise(r => setTimeout(r, 30));
    const t3 = performance.now();
    S.transactions = S.transactions.slice(0, base);
    save();
    return { count: base + 1500, opsMs: Math.round(t1 - t0), dashMs: Math.round(t3 - t2), rows: rows, nodes: document.querySelectorAll('*').length };
  }, seeded);
  console.log('  нагрузка 1500+ операций:', JSON.stringify(stress));
  if (stress.opsMs > 700) add('Производительность', 'список операций на ' + stress.count + ' записях рисуется ' + stress.opsMs + ' мс — нужна виртуализация или пагинация');
  else okLine('список операций на ' + stress.count + ' записях: ' + stress.opsMs + ' мс');
  if (stress.nodes > 12000) add('Производительность', 'при большом архиве DOM раздувается до ' + stress.nodes + ' узлов');

  /* доступность: контраст и aria */
  const a11y = await m.page.evaluate(() => {
    let noLabel = 0;
    document.querySelectorAll('button').forEach(b => {
      const txt = (b.textContent || '').trim();
      if (!txt && !b.getAttribute('aria-label') && !b.getAttribute('title')) noLabel++;
    });
    const inputs = document.querySelectorAll('input,select,textarea').length;
    let unlabeled = 0;
    document.querySelectorAll('input,select,textarea').forEach(i => {
      if (!i.id) { unlabeled++; return; }
      if (!document.querySelector('label[for="' + i.id + '"]') && !i.getAttribute('aria-label') && !i.placeholder) unlabeled++;
    });
    return { noLabel, inputs, unlabeled };
  });
  console.log('  a11y:', JSON.stringify(a11y));
  if (a11y.noLabel > 0) add('Доступность', a11y.noLabel + ' кнопок без текста и aria-label/title — непонятны скринридеру');
  if (a11y.unlabeled > 0) add('Доступность', a11y.unlabeled + ' полей без подписи/placeholder');

  await mctx.close();

  /* ---------------- ПК ---------------- */
  console.log('\n=== ПК 1440×900 ===');
  const dctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const d = await setup(dctx);
  await seed(d.page);
  for (const p of allPages) {
    if (REMOVED.indexOf(p) !== -1) continue;
    const before = d.errors.length;
    const res = await d.page.evaluate(async pg => {
      nav(pg);
      await new Promise(r => setTimeout(r, 240));
      return { overflow: document.documentElement.scrollWidth - document.documentElement.clientWidth };
    }, p);
    if (res.overflow > 2) add('Вёрстка', 'ПК: горизонтальная прокрутка в «' + p + '» +' + res.overflow + 'px');
    if (d.errors.length > before) add('Ошибка', 'ПК, «' + p + '»: ' + d.errors.slice(before).join(' | '));
  }
  okLine('все разделы проверены на ПК');

  /* широкий экран: не растянуто ли содержимое на всю ширину */
  const width = await d.page.evaluate(() => {
    nav('dashboard');
    const c = document.querySelector('.wrap, .container, main, #app') || document.body;
    const r = c.getBoundingClientRect();
    return { w: Math.round(r.width), vw: window.innerWidth, cls: c.className || c.id };
  });
  console.log('  контейнер:', JSON.stringify(width));
  if (width.w > 1200) add('Удобство', 'на широком мониторе содержимое растянуто на ' + width.w + 'px — стоит ограничить ширину или сделать две колонки');

  /* клавиатура: Tab-навигация и горячие клавиши */
  await d.page.keyboard.press('Tab');
  const focus = await d.page.evaluate(() => {
    const a = document.activeElement;
    return { tag: a && a.tagName, id: a && a.id, outline: a ? getComputedStyle(a).outlineStyle : null };
  });
  if (!focus.tag || focus.tag === 'BODY') add('Доступность', 'Tab не переводит фокус на элементы управления');
  else if (focus.outline === 'none') add('Доступность', 'у сфокусированных элементов нет видимой рамки фокуса (неудобно без мыши)');
  else okLine('Tab-навигация работает');

  /* оффлайн: service worker и поведение без сети */
  const sw = await d.page.evaluate(() => ({ has: 'serviceWorker' in navigator, registered: !!(navigator.serviceWorker && navigator.serviceWorker.controller) }));
  console.log('  service worker:', JSON.stringify(sw));
  notes.push('service worker в сборке есть (на file:// не регистрируется — это норма)');

  console.log('\nMOBILE ERRORS', JSON.stringify(m.errors));
  console.log('DESKTOP ERRORS', JSON.stringify(d.errors));
  if (m.errors.length) add('Ошибка', 'мобайл: ' + m.errors.join(' | '));
  if (d.errors.length) add('Ошибка', 'ПК: ' + d.errors.join(' | '));

  await browser.close();

  console.log('\n===== ИТОГ =====');
  console.log('Заметки: ' + JSON.stringify(notes));
  const bugs = issues.filter(i => /Баг|Ошибка/.test(i.sev));
  console.log('Багов: ' + bugs.length + ', всего замечаний: ' + issues.length);
  issues.forEach(i => console.log(' - [' + i.sev + '] ' + i.text));
  console.log(bugs.length ? '\nЕСТЬ БАГИ' : '\nКРИТИЧЕСКИХ БАГОВ НЕТ');
  process.exit(0);
})().catch(e => { console.error('AUDIT CRASH', e); process.exit(1); });
