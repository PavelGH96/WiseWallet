/* Тесты v3.88: во время открытого окна прокрутка блокируется не только на
   <body>, но и на корневом <html> — иначе тот продолжал разрешать
   вертикальный жест (touch-action:pan-y), и iOS всё равно визуально
   «дёргал» страницу за спиной открытого окна (скрывал/показывал адресную
   строку), хотя body уже был зафиксирован. */
const { chromium } = require('playwright');
const path = require('path');
const FILE = 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const ctx = await b.newContext({ viewport: { width: 430, height: 932 }, isMobile: true, hasTouch: true, deviceScaleFactor: 3 });
  const p = await ctx.newPage();
  const errors = [];
  p.on('pageerror', e => errors.push(e.message));
  p.on('console', m => { if (m.type() === 'error' && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text())) errors.push(m.text()); });
  await p.goto(FILE);
  await p.waitForTimeout(1600);
  await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
  await p.evaluate(() => {
    S.links = [{ id: 'l1', title: 'Т', category: 'Ф', url: 'https://e.com', created: Date.now() }];
    S.tasks = [{ id: 't1', title: 'Задача', done: false, prio: 2, created: Date.now() }];
    save();
  });
  await p.waitForTimeout(300);

  const before = await p.evaluate(() => ({
    htmlLocked: document.documentElement.classList.contains('no-scroll'),
    htmlTouch: getComputedStyle(document.documentElement).touchAction,
  }));
  check('до открытия окна корень не заблокирован', before.htmlLocked === false && before.htmlTouch === 'pan-y', before);

  // === Обычное окно (showModal/closeModal) ===
  await p.evaluate(() => nav('links'));
  await p.waitForTimeout(300);
  await p.evaluate(() => openLinkModal('l1'));
  await p.waitForTimeout(400);
  const duringModal = await p.evaluate(() => ({
    htmlLocked: document.documentElement.classList.contains('no-scroll'),
    htmlTouch: getComputedStyle(document.documentElement).touchAction,
    modalTouch: getComputedStyle(document.getElementById('modal')).touchAction,
  }));
  check('КЛЮЧЕВОЕ: пока окно открыто, корень заблокирован (touch-action:none)',
    duringModal.htmlLocked === true && duringModal.htmlTouch === 'none', duringModal);
  check('при этом само окно по-прежнему может прокручиваться (pan-y)',
    duringModal.modalTouch === 'pan-y', duringModal);

  await p.evaluate(() => closeModal());
  await p.waitForTimeout(400);
  const afterModal = await p.evaluate(() => ({
    htmlLocked: document.documentElement.classList.contains('no-scroll'),
    htmlTouch: getComputedStyle(document.documentElement).touchAction,
  }));
  check('после закрытия корень разблокирован', afterModal.htmlLocked === false && afterModal.htmlTouch === 'pan-y', afterModal);

  // === Системный диалог (_dlgOpen/_dlgClose — другой путь блокировки) ===
  p.evaluate(() => wwConfirm('Проверка', { title: 'Тест' }));
  await p.waitForTimeout(500);
  const duringDlg = await p.evaluate(() => document.documentElement.classList.contains('no-scroll'));
  check('диалог подтверждения тоже блокирует корень', duringDlg === true);
  await p.evaluate(() => { const c = [...document.querySelectorAll('#ww-dlg button')].find(b => /Отмен/.test(b.textContent)); if (c) c.click(); });
  await p.waitForTimeout(400);
  check('после диалога корень разблокирован', (await p.evaluate(() => document.documentElement.classList.contains('no-scroll'))) === false);

  // === Вложенность: диалог поверх окна не должен снимать блокировку раньше времени ===
  await p.evaluate(() => openTaskModal('t1'));
  await p.waitForTimeout(400);
  p.evaluate(() => wwConfirm('Удалить?', { title: 'Подтверждение' }));
  await p.waitForTimeout(500);
  check('счётчик блокировок: заблокировано при двух открытых окнах', (await p.evaluate(() => document.documentElement.classList.contains('no-scroll'))) === true);
  await p.evaluate(() => { const c = [...document.querySelectorAll('#ww-dlg button')].find(b => /Отмен/.test(b.textContent)); if (c) c.click(); });
  await p.waitForTimeout(400);
  check('после закрытия ТОЛЬКО диалога — окно ещё открыто, блокировка держится',
    (await p.evaluate(() => document.documentElement.classList.contains('no-scroll'))) === true &&
    (await p.evaluate(() => document.getElementById('overlay').classList.contains('open'))) === true);
  await p.evaluate(() => closeModal());
  await p.waitForTimeout(400);
  check('после закрытия обоих — блокировка снята', (await p.evaluate(() => document.documentElement.classList.contains('no-scroll'))) === false);

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));
  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})();
