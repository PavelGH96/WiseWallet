/* Тест v3.98: правка суммы регулярного дохода во вкладке «Доходы»
   действует ТОЛЬКО на показанный месяц.

   Регрессия, которую он ловит: поле суммы было редактируемым лишь для
   будущих месяцев; в текущем месяце сумму меняли карандашом, а карандаш
   правит сам шаблон S.recurring — и новая сумма разъезжалась сразу по
   всем месяцам, хотя доход нестабильный (премии, подработки).

   Проверяем: правка в августе не трогает ни шаблон, ни июль, ни сентябрь;
   очистка поля возвращает сумму шаблона; карандаш по-прежнему меняет
   шаблон целиком (это отдельный, осознанный сценарий). */
const { chromium } = require('playwright');
const path = require('path');
const FILE = process.env.WW_APP || 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const p = await (await b.newContext({ viewport: { width: 1500, height: 950 } })).newPage();
  const errors = [];
  p.on('pageerror', e => errors.push(e.message));

  await p.goto(FILE);
  await p.waitForTimeout(1600);
  await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
  await p.waitForTimeout(400);

  const ctx = await p.evaluate(() => {
    S.recurring = (S.recurring || []).filter(r => r.type !== 'income');
    S.recurIncomeAmt = {};
    const c = (S.categories || []).find(x => x.type === 'income') || { id: 'ic1' };
    S.recurring.push({ id: 'ri1', type: 'income', name: 'Заработная плата', categoryId: c.id, amount: 150000, day: 15 });
    save();
    const cur = todayStr().slice(0, 7);
    return { cur, prev: ymShift(cur, -1), next: ymShift(cur, 1) };
  });

  // открыть вкладку «Доходы» на текущем месяце
  await p.evaluate(() => { nav('credits'); });
  await p.waitForTimeout(500);
  await p.evaluate(() => { ww63Tab('inc'); });
  await p.waitForTimeout(700);

  const editable = await p.evaluate(() => {
    const i = document.querySelector('#ww63-recur input.ww89-plan[data-id="ri1"]');
    return i ? { found: true, ym: i.dataset.ym, value: i.value } : { found: false };
  });
  check('КЛЮЧЕВОЕ: сумма в текущем месяце редактируется прямо в строке', editable.found && editable.ym === ctx.cur, editable);

  // изменить сумму на текущий месяц
  await p.evaluate(() => {
    const i = document.querySelector('#ww63-recur input.ww89-plan[data-id="ri1"]');
    i.value = '250000';
    i.dispatchEvent(new Event('change', { bubbles: true }));
  });
  await p.waitForTimeout(600);

  const after = await p.evaluate((c) => ({
    template: S.recurring.find(r => r.id === 'ri1').amount,
    cur: wwRecurIncomeAmount(S.recurring.find(r => r.id === 'ri1'), c.cur),
    prev: wwRecurIncomeAmount(S.recurring.find(r => r.id === 'ri1'), c.prev),
    next: wwRecurIncomeAmount(S.recurring.find(r => r.id === 'ri1'), c.next),
    keys: Object.keys(S.recurIncomeAmt || {}),
  }), ctx);
  check('КЛЮЧЕВОЕ: новая сумма применилась к текущему месяцу', after.cur === 250000, after);
  check('КЛЮЧЕВОЕ: шаблон НЕ изменился', after.template === 150000, after.template);
  check('КЛЮЧЕВОЕ: прошлый месяц не затронут', after.prev === 150000, after.prev);
  check('КЛЮЧЕВОЕ: будущий месяц не затронут', after.next === null, after.next);
  check('исключение записано ровно на один месяц', after.keys.length === 1 && after.keys[0] === 'ri1:' + ctx.cur, after.keys);

  // план на месяц на дашборде тоже должен учесть исключение
  const planNow = await p.evaluate(() => planIncomeMonth());
  check('план доходов текущего месяца учитывает исключение', planNow === 250000, planNow);

  // очистка поля возвращает сумму шаблона
  await p.evaluate(() => {
    const i = document.querySelector('#ww63-recur input.ww89-plan[data-id="ri1"]');
    i.value = '';
    i.dispatchEvent(new Event('change', { bubbles: true }));
  });
  await p.waitForTimeout(600);
  const cleared = await p.evaluate((c) => ({
    cur: wwRecurIncomeAmount(S.recurring.find(r => r.id === 'ri1'), c.cur),
    keys: Object.keys(S.recurIncomeAmt || {}),
  }), ctx);
  check('очистка поля возвращает сумму из шаблона', cleared.cur === 150000 && cleared.keys.length === 0, cleared);

  // ввод суммы, равной шаблону, не плодит лишнее исключение
  await p.evaluate(() => {
    const i = document.querySelector('#ww63-recur input.ww89-plan[data-id="ri1"]');
    i.value = '150000';
    i.dispatchEvent(new Event('change', { bubbles: true }));
  });
  await p.waitForTimeout(600);
  const same = await p.evaluate(() => Object.keys(S.recurIncomeAmt || {}).length);
  check('сумма, равная шаблону, не создаёт лишнюю запись-исключение', same === 0, same);

  // карандаш по-прежнему меняет шаблон целиком — это отдельный сценарий
  await p.evaluate(() => {
    const r = S.recurring.find(x => x.id === 'ri1');
    r.amount = 170000; save();
    if (typeof renderAll === 'function') renderAll();
  });
  await p.waitForTimeout(300);
  const tpl = await p.evaluate((c) => ({
    cur: wwRecurIncomeAmount(S.recurring.find(r => r.id === 'ri1'), c.cur),
    prev: wwRecurIncomeAmount(S.recurring.find(r => r.id === 'ri1'), c.prev),
  }), ctx);
  check('правка шаблона по-прежнему действует на все месяцы', tpl.cur === 170000 && tpl.prev === 170000, tpl);

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));
  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
