/* Тесты v3.93: редактирование и удаление регулярного дохода прямо из строки
   списка во вкладке «Доходы». Отдельно проверяем, что список обновляется
   СРАЗУ после сохранения/удаления, не требуя ухода со страницы и возврата —
   этого не было даже для уже существовавшей кнопки «+ Регулярный доход». */
const { chromium } = require('playwright');
const path = require('path');
const FILE = 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const p = await (await b.newContext({ viewport: { width: 1400, height: 950 } })).newPage();
  const errors = [];
  p.on('pageerror', e => errors.push(e.message));
  p.on('console', m => { if (m.type() === 'error' && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text())) errors.push(m.text()); });
  await p.goto(FILE);
  await p.waitForTimeout(1600);
  await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
  await p.evaluate(() => {
    const incCats = S.categories.filter(c => c.type === 'income');
    S.recurring = [
      { id: 'r_sal', name: 'Зарплата', type: 'income', amount: 150000, categoryId: incCats[0].id, day: 5 },
      { id: 'r_side', name: 'Подработка', type: 'income', amount: 20000, categoryId: (incCats[1] || incCats[0]).id, day: 10 },
    ];
    save(); nav('credits');
  });
  await p.waitForTimeout(500);
  await p.evaluate(() => { const b = [...document.querySelectorAll('[data-tab]')].find(x => x.dataset.tab === 'inc'); if (b) b.click(); });
  await p.waitForTimeout(500);

  check('в каждой строке есть кнопка «Изменить»', (await p.evaluate(() => document.querySelectorAll('#ww63-recur .row button[title="Изменить"]').length)) === 2);
  check('в каждой строке есть кнопка «Удалить»', (await p.evaluate(() => document.querySelectorAll('#ww63-recur .row button[title="Удалить"]').length)) === 2);

  // === Редактирование ===
  await p.evaluate(() => document.querySelector('#ww63-recur .row button[title="Изменить"]').click());
  await p.waitForTimeout(400);
  const form = await p.evaluate(() => ({ open: document.getElementById('overlay').classList.contains('open'), name: document.getElementById('rc-name')?.value, amt: document.getElementById('rc-amt')?.value }));
  check('форма открывается с уже заполненными значениями', form.open && form.name === 'Зарплата' && form.amt === '150000', form);

  await p.fill('#rc-amt', '175000');
  await p.evaluate(() => saveRecur('r_sal'));
  await p.waitForTimeout(500);
  const afterEdit = await p.evaluate(() => {
    const box = document.getElementById('ww63-recur');
    // v3.98: сумма месяца теперь живёт в поле ввода, поэтому textContent её
    // не видит — читаем и текст строки, и значения полей.
    const vals = [...box.querySelectorAll('input.ww89-plan')].map(i => i.value).join(' ');
    return {
      closed: !document.getElementById('overlay').classList.contains('open'),
      stored: S.recurring.find(r => r.id === 'r_sal').amount,
      listShowsNew: (box.textContent + ' ' + vals).includes('175'),
    };
  });
  check('сохранённое значение записано', afterEdit.stored === 175000, afterEdit);
  check('КЛЮЧЕВОЕ: список во вкладке обновился сразу, без перехода на другую страницу', afterEdit.listShowsNew === true, afterEdit);

  // === Удаление ===
  await p.evaluate(() => {
    const rows = [...document.querySelectorAll('#ww63-recur .row')];
    rows.find(r => r.textContent.includes('Подработка')).querySelector('button[title="Удалить"]').click();
  });
  await p.waitForTimeout(400);
  const afterDel = await p.evaluate(() => ({
    stored: S.recurring.length,
    goneFromList: !document.getElementById('ww63-recur').textContent.includes('Подработка'),
    toast: document.getElementById('toast')?.textContent || '',
  }));
  check('запись удалена из данных', afterDel.stored === 1, afterDel);
  check('строка сразу пропала из списка', afterDel.goneFromList === true, afterDel);
  check('показан тост с отменой', /Отменить/.test(afterDel.toast), afterDel.toast);

  // === Отмена удаления ===
  await p.evaluate(() => { const u = [...document.querySelectorAll('#toast button, #toast a')].find(b => /Отменить/.test(b.textContent)); if (u) u.click(); });
  await p.waitForTimeout(400);
  const afterUndo = await p.evaluate(() => ({ stored: S.recurring.length, backInList: document.getElementById('ww63-recur').textContent.includes('Подработка') }));
  check('удаление отменяется', afterUndo.stored === 2, afterUndo);
  check('строка возвращается в список сразу', afterUndo.backInList === true, afterUndo);

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));
  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})();
