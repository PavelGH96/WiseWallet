/* Тест v4.02: переполнение localStorage обрабатывается, а не роняет операцию.

   Регрессия, которую он ловит: save() вызывал localStorage.setItem без
   try/catch. При исчерпании квоты (~5 МБ) исключение улетало наружу:
   текущая операция обрывалась на середине, пользователь не видел никакого
   предупреждения и молча терял правку. */
const { chromium } = require('playwright');
const path = require('path');
const FILE = process.env.WW_APP || 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const p = await (await b.newContext({ viewport: { width: 1400, height: 900 } })).newPage();
  const errors = [];
  p.on('pageerror', e => errors.push(e.message));

  await p.goto(FILE);
  await p.waitForTimeout(1600);
  await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
  await p.waitForTimeout(400);

  /* Подменяем setItem так, чтобы запись состояния всегда падала по квоте */
  const res = await p.evaluate(() => {
    const orig = localStorage.setItem.bind(localStorage);
    localStorage.setItem = function (k, v) {
      if (k === LS_KEY || (typeof WW22_DEMO_KEY !== 'undefined' && k === WW22_DEMO_KEY)) { const e = new Error('quota'); e.name = 'QuotaExceededError'; throw e; }
      return orig(k, v);
    };
    let escaped = null, ret = null;
    try { ret = save(); } catch (e) { escaped = e.name; }
    const toastEl = document.getElementById('toast');
    const out = {
      escaped,
      ret,
      toastShown: !!toastEl && toastEl.classList.contains('show'),
      toastText: toastEl ? toastEl.textContent : '',
      stateIntact: Array.isArray(S.transactions),
    };
    localStorage.setItem = orig;
    return out;
  });

  check('КЛЮЧЕВОЕ: save() не выбрасывает исключение наружу', res.escaped === null, res.escaped);
  check('save() честно сообщает вызывающему коду о неудаче (false)', res.ret === false, res.ret);
  check('пользователь видит предупреждение, а не тишину', res.toastShown && /[Пп]амять браузера заполнена/.test(res.toastText), res.toastText);
  check('данные остаются в памяти — их можно экспортировать', res.stateIntact === true);

  /* Повторные сохранения не должны сыпать одинаковыми тостами */
  const spam = await p.evaluate(() => {
    const orig = localStorage.setItem.bind(localStorage);
    localStorage.setItem = function (k, v) {
      if (k === LS_KEY || (typeof WW22_DEMO_KEY !== 'undefined' && k === WW22_DEMO_KEY)) { const e = new Error('quota'); e.name = 'QuotaExceededError'; throw e; }
      return orig(k, v);
    };
    let shown = 0;
    const realToast = window.toast;
    window.toast = function (m) { if (/заполнена/.test(m)) shown++; return realToast.apply(this, arguments); };
    for (let i = 0; i < 5; i++) save();
    window.toast = realToast;
    localStorage.setItem = orig;
    return shown;
  });
  check('предупреждение не повторяется на каждое сохранение', spam === 0, spam);

  /* Когда место освободилось — сохранение снова работает и молчит */
  const recovered = await p.evaluate(() => {
    const ok = save();
    const raw = localStorage.getItem(LS_KEY) || localStorage.getItem(typeof WW22_DEMO_KEY !== 'undefined' ? WW22_DEMO_KEY : '');
    return { ok, written: !!raw && raw.length > 10 };
  });
  check('после освобождения места сохранение восстанавливается', recovered.ok === true && recovered.written, recovered);

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));
  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
