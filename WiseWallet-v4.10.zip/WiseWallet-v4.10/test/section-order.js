const path = require("path");
const { chromium } = require("playwright");
const FILE = process.env.WW_APP || 'file://' + require('path').resolve(__dirname, '../index.html');
const SESSION = { access_token:"smoke.jwt.token", refresh_token:"smoke.refresh", expires_at:Date.now()+3600e3, user_id:"00000000-0000-4000-8000-000000000001", email:"smoke@example.com" };

(async()=>{
  const browser = await chromium.launch({executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium',args:["--no-sandbox"]});
  const errors=[];
  const ctx=await browser.newContext({viewport:{width:390,height:844},hasTouch:true,isMobile:true,deviceScaleFactor:2});
  const page=await ctx.newPage();
  page.on("pageerror",e=>errors.push("PAGEERROR: "+e.message));
  page.on("console",m=>{if(m.type()==="error"&&!/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text()))errors.push("CONSOLE: "+m.text())});
  await page.goto(FILE);
  await page.evaluate(s=>localStorage.setItem("ww_session_v2",JSON.stringify(s)),SESSION);
  await page.goto(FILE); await page.waitForTimeout(1800);

  const snap=()=>page.evaluate(()=>({
    saved:(S.settings.navOrder||[]).slice(),
    card:[].map.call(document.querySelectorAll("#ww40-order-list .row"),x=>x.dataset.sid),
    rail:[].map.call(document.querySelectorAll(".rail .rail-item[data-nav]"),x=>x.dataset.nav),
    bottom:[].map.call(document.querySelectorAll(".bottom-nav .bn-item[data-nav]"),x=>x.dataset.nav),
    bottomLabels:[].map.call(document.querySelectorAll(".bottom-nav .bn-item"),x=>x.textContent.trim()),
  }));

  await page.evaluate(()=>{S.settings.navOrder=[];save();ww40ApplyOrder();nav("settings")});
  await page.waitForTimeout(700);
  console.log("DEFAULT",JSON.stringify(await snap()));

  // Реальное нажатие стрелки: Планировщик поднимаем с 6-го на 1-е место.
  for(let i=0;i<5;i++){
    await page.evaluate(()=>document.querySelector('#ww40-order-list .row[data-sid="planner"] button[title="Выше"]').click());
    await page.waitForTimeout(180);
  }
  const moved=await snap();
  console.log("MOVED",JSON.stringify(moved));

  // Нижняя панель должна сразу стать Планировщик, Дашборд, Операции, Бюджеты.
  await page.locator('.bottom-nav .bn-item[data-nav="planner"]').click();
  await page.waitForTimeout(500);
  console.log("NAV_FROM_DYNAMIC",JSON.stringify(await page.evaluate(()=>({active:document.querySelector("main .page.active").id,bottomActive:(document.querySelector(".bottom-nav .bn-item.active")||{}).dataset&&document.querySelector(".bottom-nav .bn-item.active").dataset.nav}))));

  // «Ещё» содержит остаток ровно в сохранённом порядке.
  await page.locator("#ww45-more").click(); await page.waitForTimeout(400);
  console.log("MORE",JSON.stringify(await page.evaluate(()=>({
    open:document.getElementById("overlay").classList.contains("open"),
    items:[].map.call(document.querySelectorAll("#modal .more-item[data-more]"),x=>x.dataset.more),
    text:(document.querySelector("#modal .sub")||{}).textContent
  }))));
  await page.evaluate(()=>closeModal());

  // Перезагрузка: порядок обязан сохраниться.
  await page.reload(); await page.waitForTimeout(1800);
  await page.evaluate(()=>nav("settings")); await page.waitForTimeout(500);
  console.log("RELOAD",JSON.stringify(await snap()));

  // Симулируем перетаскивание списка: Аналитика первой.
  console.log("DRAG_CALLBACK",JSON.stringify(await page.evaluate(()=>{
    const list=document.getElementById("ww40-order-list");
    const ids=ww40Order(); ids.splice(ids.indexOf("analytics"),1); ids.unshift("analytics");
    list._sortCb(ids);
    return {saved:S.settings.navOrder.slice(),bottom:[].map.call(document.querySelectorAll(".bottom-nav [data-nav]"),x=>x.dataset.nav)};
  })));
  await page.waitForTimeout(400);

  // Сброс возвращает исходную раскладку и после перезагрузки.
  await page.evaluate(()=>ww40ResetOrder()); await page.waitForTimeout(500);
  console.log("RESET",JSON.stringify(await snap()));
  await page.reload(); await page.waitForTimeout(1700);
  console.log("RESET_RELOAD",JSON.stringify(await page.evaluate(()=>({saved:S.settings.navOrder,bottom:[].map.call(document.querySelectorAll(".bottom-nav [data-nav]"),x=>x.dataset.nav),rail:[].map.call(document.querySelectorAll(".rail [data-nav]"),x=>x.dataset.nav)}))));

  await page.screenshot({path:"/data/a345-order-default.png"});
  // Снова ставим Планировщик первым для визуальной проверки.
  await page.evaluate(()=>{S.settings.navOrder=["planner","dashboard","ops","budgets","credits","calendar","vault","analytics","settings"];save();ww40ApplyOrder();nav("settings")});
  await page.waitForTimeout(600);
  await page.screenshot({path:"/data/a345-order-custom.png"});

  // Desktop rail
  const ctx2=await browser.newContext({viewport:{width:1280,height:950}});
  const p2=await ctx2.newPage();
  p2.on("pageerror",e=>errors.push("DESKTOP PAGEERROR: "+e.message));
  await p2.goto(FILE); await p2.evaluate(s=>localStorage.setItem("ww_session_v2",JSON.stringify(s)),SESSION);
  await p2.goto(FILE); await p2.waitForTimeout(1700);
  await p2.evaluate(()=>{S.settings.navOrder=["planner","dashboard","ops","budgets","credits","calendar","vault","analytics","settings"];save();ww40ApplyOrder()});
  console.log("DESKTOP",JSON.stringify(await p2.evaluate(()=>({rail:[].map.call(document.querySelectorAll(".rail [data-nav]"),x=>x.dataset.nav),bottom:[].map.call(document.querySelectorAll(".bottom-nav [data-nav]"),x=>x.dataset.nav),groupsHidden:[].every.call(document.querySelectorAll(".rail-grp"),x=>getComputedStyle(x).display==="none"),version:WW_VERSION}))));

  console.log("ERRORS",JSON.stringify(errors));
  await browser.close();
})();
