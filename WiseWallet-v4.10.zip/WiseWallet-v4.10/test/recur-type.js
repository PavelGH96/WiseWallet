/* Тесты v4.07: раздел «Доходы и расходы» и однозначный тип регулярного платежа.

   1) Раздел переименован, «Доходы» — первая вкладка.
   2) Тип регулярного платежа не выбирается там, где он известен из контекста:
      при добавлении из «Доходов» это всегда доход, из блока «Регулярные
      расходы» — всегда расход, при правке существующей записи — её тип.
      Раньше форма открывалась с выпадающим списком «Расход/Доход», а для
      дохода тип переставлялся костылём через setTimeout — пользователь
      успевал увидеть бессмысленный выбор и мог сменить тип, уведя запись
      в другой раздел с несовпадающей категорией. */
const { chromium } = require('playwright');
const path = require('path');
const FILE = process.env.WW_APP || 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const p = await (await b.newContext({ viewport: { width: 1400, height: 950 } })).newPage();
  const errors = [];
  p.on('pageerror', e => errors.push(e.message));
  await p.goto(FILE); await p.waitForTimeout(1600);
  await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
  await p.waitForTimeout(400);

  console.log('=== 1. Название раздела и порядок вкладок ===');
  const names = await p.evaluate(() => {
    const rail = [...document.querySelectorAll('[data-nav="credits"]')].map(e => e.textContent.trim());
    return { rail, oldLeft: document.body.innerHTML.indexOf('Расходы и доходы') };
  });
  check('в меню раздел называется «Доходы и расходы»', names.rail.every(t => /Доходы и расходы/.test(t)), names.rail);
  check('старого названия «Расходы и доходы» нигде не осталось', names.oldLeft === -1, names.oldLeft);

  await p.evaluate(() => nav('credits'));
  await p.waitForTimeout(800);
  const tabs = await p.evaluate(() => {
    const t = [...document.querySelectorAll('#ww63-tabs button, #ww63-tabs .seg-btn, #ww63-tabs [data-tab]')].map(e => e.textContent.trim()).filter(Boolean);
    return { tabs: t, h1: document.querySelector('#page-credits h1').textContent.trim() };
  });
  check('КЛЮЧЕВОЕ: «Доходы» — первая вкладка', tabs.tabs.length >= 2 && /Доходы/.test(tabs.tabs[0]) && /Расходы/.test(tabs.tabs[1]), tabs.tabs);

  console.log('\n=== 2. Добавление регулярного ДОХОДА ===');
  const inc = await p.evaluate(() => {
    ww63AddRecurIncome();
    const sel = document.getElementById('rc-type');
    return {
      title: (document.querySelector('#modal h3') || {}).textContent,
      tag: sel ? sel.tagName : null,
      value: sel ? sel.value : null,
      selectVisible: !!document.querySelector('#modal select#rc-type'),
      shownText: (document.querySelector('#modal .tx-locked-cat') || {}).textContent,
      cats: [...document.querySelectorAll('#rc-cat option')].length,
    };
  });
  check('КЛЮЧЕВОЕ: выпадающего выбора типа нет', inc.selectVisible === false, inc);
  check('тип жёстко задан как доход', inc.value === 'income', inc.value);
  check('в форме видно, что это доход', /Доход/.test(inc.shownText || ''), inc.shownText);
  check('заголовок говорит, что добавляем доход', /Новый регулярный доход/.test(inc.title || ''), inc.title);
  check('категории подставлены из доходных', inc.cats > 0, inc.cats);

  /* сохраняется именно доходом */
  const savedInc = await p.evaluate(() => {
    document.getElementById('rc-name').value = 'Тестовый доход';
    document.getElementById('rc-amt').value = '1000';
    saveRecur('');
    const r = S.recurring.find(x => x.name === 'Тестовый доход');
    return r ? { type: r.type, cat: r.categoryId } : null;
  });
  await p.waitForTimeout(300);
  check('КЛЮЧЕВОЕ: запись сохранена как доход', savedInc && savedInc.type === 'income', savedInc);
  const catOk = await p.evaluate((cid) => { const c = S.categories.find(x => x.id === cid); return c ? c.type : null; }, savedInc && savedInc.cat);
  check('категория тоже доходная (типы не разъехались)', catOk === 'income', catOk);

  console.log('\n=== 3. Добавление регулярного РАСХОДА ===');
  const exp = await p.evaluate(() => {
    closeModal();
    openRecurModal(null, 'expense');
    const sel = document.getElementById('rc-type');
    return {
      title: (document.querySelector('#modal h3') || {}).textContent,
      selectVisible: !!document.querySelector('#modal select#rc-type'),
      value: sel ? sel.value : null,
      shownText: (document.querySelector('#modal .tx-locked-cat') || {}).textContent,
    };
  });
  check('КЛЮЧЕВОЕ: выбора типа нет и здесь', exp.selectVisible === false && exp.value === 'expense', exp);
  check('заголовок говорит, что добавляем расход', /Новый регулярный расход/.test(exp.title || ''), exp.title);
  check('в форме видно, что это расход', /Расход/.test(exp.shownText || ''), exp.shownText);

  console.log('\n=== 4. Правка существующей записи ===');
  const edit = await p.evaluate(() => {
    closeModal();
    const r = S.recurring.find(x => x.name === 'Тестовый доход');
    openRecurModal(r.id);
    const sel = document.getElementById('rc-type');
    return {
      title: (document.querySelector('#modal h3') || {}).textContent,
      selectVisible: !!document.querySelector('#modal select#rc-type'),
      value: sel ? sel.value : null,
      name: document.getElementById('rc-name').value,
    };
  });
  check('КЛЮЧЕВОЕ: при правке тип показан, но не переключается', edit.selectVisible === false && edit.value === 'income', edit);
  check('заголовок отражает тип записи', /Регулярный доход/.test(edit.title || ''), edit.title);
  check('данные записи подставлены', edit.name === 'Тестовый доход', edit.name);

  console.log('\n=== 5. Общая кнопка в смешанном списке ===');
  const generic = await p.evaluate(() => {
    closeModal();
    openRecurModal(null);
    return {
      selectVisible: !!document.querySelector('#modal select#rc-type'),
      title: (document.querySelector('#modal h3') || {}).textContent,
      options: [...document.querySelectorAll('#modal select#rc-type option')].map(o => o.value),
    };
  });
  check('в смешанном списке выбор типа сохранён (контекст неоднозначен)',
    generic.selectVisible === true && generic.options.length === 2, generic);
  await p.evaluate(() => closeModal());

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));
  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
