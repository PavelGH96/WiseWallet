/* Тесты v3.64: выбор сферы задачи в планировщике */
const { chromium } = require('playwright');
const FILE = process.env.WW_APP || 'file://' + require('path').resolve(__dirname, '../index.html');
const fails = [];
function check(name, cond, extra) {
  console.log((cond ? '  ok   ' : '  FAIL ') + name + (extra !== undefined ? '  -> ' + JSON.stringify(extra) : ''));
  if (!cond) fails.push(name);
}

const SESSION = { access_token: 'x.y.z', refresh_token: 'r', expires_at: Date.now() + 3600e3, user_id: '00000000-0000-4000-8000-000000000001', email: 't364@test.local' };

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  await ctx.route(/supabase\.co/, r => {
    if (r.request().method() === 'OPTIONS') return r.fulfill({ status: 204, headers: { 'access-control-allow-origin': '*' }, body: '' });
    return r.fulfill({ status: 200, headers: { 'access-control-allow-origin': '*', 'content-type': 'application/json' }, body: '[]' });
  });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text())) errors.push('CONSOLE: ' + m.text()); });

  await page.goto(FILE);
  await page.evaluate(s => localStorage.setItem('ww_session_v2', JSON.stringify(s)), SESSION);
  await page.goto(FILE);
  await page.waitForTimeout(1800);

  check('версия не ниже 3.64', parseFloat(String(await page.evaluate(() => WW_VERSION))) >= 3.64, await page.evaluate(() => WW_VERSION));
  check('нет битых символов', !(await page.evaluate(() => document.documentElement.innerHTML.indexOf('\uFFFD') !== -1)));

  /* ---------- 1. поле в окне новой задачи ---------- */
  const opened = await page.evaluate(async () => {
    S.tasks = [];
    save();
    nav('planner');
    await new Promise(r => setTimeout(r, 500));
    openTaskModal();
    await new Promise(r => setTimeout(r, 500));
    const sel = document.getElementById('ww64-sphere');
    if (!sel) return { found: false };
    const opts = Array.prototype.map.call(sel.options, o => o.textContent.trim());
    const fg = document.getElementById('ww64-fg');
    const label = fg ? fg.querySelector('label').textContent.trim() : '';
    return {
      found: true, opts, label, value: sel.value,
      hasTypeField: !!document.getElementById('ww60-type'),
      hasText: !!document.getElementById('tk-text'),
      hasNote: !!document.getElementById('ww60-note'),
      hasTime: !!document.getElementById('ww60-time'),
      hasRep: !!document.getElementById('ww60-rep'),
      visible: sel.getBoundingClientRect().height > 0
    };
  });
  check('в окне задачи появилось поле выбора сферы',
    opened.found && opened.visible && /касается/i.test(opened.label), opened);
  check('есть нужные варианты: Личное, Семья, Авто, Работа и Другое',
    opened.found && ['Личное', 'Семья', 'Авто', 'Работа', 'Другое'].every(w => opened.opts.some(o => o.indexOf(w) !== -1)) &&
    /Другое/.test(opened.opts[opened.opts.length - 1]), opened.opts);
  check('добавлены ещё популярные сферы (Дом, Здоровье, Финансы и др.)',
    opened.found && opened.opts.length >= 10 &&
    ['Дом', 'Здоровье', 'Финансы', 'Учёба', 'Покупки'].every(w => opened.opts.some(o => o.indexOf(w) !== -1)), opened.opts.length);
  check('прежние поля окна задачи целы (тип, время, повтор, заметка)',
    opened.hasTypeField && opened.hasText && opened.hasNote && opened.hasTime && opened.hasRep, opened);

  /* ---------- 2. сохранение сферы ---------- */
  const saved = await page.evaluate(async () => {
    document.getElementById('tk-text').value = 'Поменять масло';
    document.getElementById('ww64-sphere').value = 'car';
    saveTask('');
    await new Promise(r => setTimeout(r, 600));
    const t = S.tasks[S.tasks.length - 1];
    return { n: S.tasks.length, text: t.text, sphere: t.sphere, viaApi: ww64SphereOf(t.id) };
  });
  check('выбранная сфера сохраняется в задаче',
    saved.n === 1 && saved.sphere === 'car' && saved.viaApi === 'car', saved);

  /* ---------- 3. метка на карточке ---------- */
  const chip = await page.evaluate(async () => {
    renderPlanner();
    await new Promise(r => setTimeout(r, 400));
    const card = document.querySelector('#kanban .task-card');
    const c = card ? card.querySelector('.ww64-sph-chip') : null;
    return {
      card: !!card,
      chip: !!c,
      text: c ? c.textContent.trim() : '',
      keepsType: !!(card && card.querySelector('.ww60-chip')),
      meta: card ? card.querySelector('.task-meta').textContent.trim() : ''
    };
  });
  check('на карточке видна метка сферы',
    chip.card && chip.chip && /Авто/.test(chip.text) && chip.keepsType, chip);

  /* ---------- 4. редактирование сохраняет и меняет сферу ---------- */
  const edited = await page.evaluate(async () => {
    const id = S.tasks[0].id;
    openTaskModal(id);
    await new Promise(r => setTimeout(r, 500));
    const pre = document.getElementById('ww64-sphere').value;
    document.getElementById('ww64-sphere').value = 'work';
    saveTask(id);
    await new Promise(r => setTimeout(r, 600));
    const t = S.tasks.find(x => x.id === id);
    const card = document.querySelector('#kanban .task-card .ww64-sph-chip');
    return { pre, now: t.sphere, text: t.text, chip: card ? card.textContent.trim() : '' };
  });
  check('при редактировании сфера показывается и меняется',
    edited.pre === 'car' && edited.now === 'work' && /Работа/.test(edited.chip) && edited.text === 'Поменять масло', edited);

  /* ---------- 5. последняя сфера предлагается в новой задаче ---------- */
  const remembered = await page.evaluate(async () => {
    closeModal();
    openTaskModal();
    await new Promise(r => setTimeout(r, 500));
    const v = document.getElementById('ww64-sphere').value;
    document.getElementById('tk-text').value = 'Задача без сферы';
    document.getElementById('ww64-sphere').value = 'other';
    saveTask('');
    await new Promise(r => setTimeout(r, 600));
    const t = S.tasks[S.tasks.length - 1];
    return { suggested: v, saved: t.sphere, n: S.tasks.length };
  });
  check('новая задача предлагает последнюю использованную сферу',
    remembered.suggested === 'work' && remembered.saved === 'other' && remembered.n === 2, remembered);

  /* ---------- 6. фильтр по сферам ---------- */
  const filter = await page.evaluate(async () => {
    renderPlanner();
    await new Promise(r => setTimeout(r, 400));
    const bar = document.getElementById('ww64-filter');
    const labels = bar ? Array.prototype.map.call(bar.querySelectorAll('.chip'), b => b.textContent.trim()) : [];
    ww64Filter('work');
    await new Promise(r => setTimeout(r, 300));
    const vis = Array.prototype.filter.call(document.querySelectorAll('#kanban .task-card'), c => c.style.display !== 'none').length;
    ww64Filter('all');
    await new Promise(r => setTimeout(r, 300));
    const all = Array.prototype.filter.call(document.querySelectorAll('#kanban .task-card'), c => c.style.display !== 'none').length;
    return { labels, vis, all, cur: ww64CurFilter() };
  });
  check('в планировщике есть фильтр по сферам',
    filter.labels.length >= 3 && /Все сферы/.test(filter.labels[0]), filter.labels);
  check('фильтр показывает только нужную сферу и сбрасывается',
    filter.vis === 1 && filter.all === 2 && filter.cur === 'all', filter);

  /* ---------- 7. старые задачи без сферы не ломаются ---------- */
  const legacy = await page.evaluate(async () => {
    S.tasks.push({ id: 'legacy1', text: 'Старая задача', who: 'me', date: todayStr(), prio: 'mid', done: false, created: Date.now() });
    save();
    renderPlanner();
    await new Promise(r => setTimeout(r, 400));
    const card = Array.prototype.find.call(document.querySelectorAll('#kanban .task-card'), c => /Старая задача/.test(c.textContent));
    return {
      shown: !!card,
      noChip: card ? !card.querySelector('.ww64-sph-chip') : false,
      total: document.querySelectorAll('#kanban .task-card').length
    };
  });
  check('задачи без сферы отображаются как раньше',
    legacy.shown && legacy.noChip && legacy.total === 3, legacy);

  /* ---------- 8. повторяющаяся задача наследует сферу ---------- */
  const repeat = await page.evaluate(async () => {
    S.tasks = [{ id: 'rep1', text: 'Оплатить ОСАГО', who: 'me', date: todayStr(), prio: 'mid', done: false, created: Date.now(), repeat: 'monthly', sphere: 'car', ttype: 'task' }];
    save();
    renderPlanner();
    await new Promise(r => setTimeout(r, 300));
    toggleTask('rep1');
    await new Promise(r => setTimeout(r, 700));
    const spawned = S.tasks.filter(t => t.ww60From === 'rep1');
    return { n: S.tasks.length, spawned: spawned.length, sphere: spawned[0] ? spawned[0].sphere : null };
  });
  check('следующая повторяющаяся задача сохраняет сферу',
    repeat.spawned === 1 && repeat.sphere === 'car', repeat);

  /* ---------- 9. перезагрузка: сфера на месте ---------- */
  await page.reload();
  await page.waitForTimeout(1800);
  const afterReload = await page.evaluate(async () => {
    nav('planner');
    await new Promise(r => setTimeout(r, 700));
    const chips = Array.prototype.map.call(document.querySelectorAll('#kanban .ww64-sph-chip'), c => c.textContent.trim());
    return { chips, spheres: S.tasks.map(t => t.sphere) };
  });
  check('после перезагрузки сферы сохранились',
    afterReload.chips.length >= 1 && afterReload.chips.every(c => /Авто/.test(c)), afterReload);

  /* ---------- 10. телефон: поле и фильтр удобны, панель внизу ---------- */
  const mctx = await browser.newContext({ viewport: { width: 390, height: 780 }, isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
  const mpage = await mctx.newPage();
  const merrors = [];
  mpage.on('pageerror', e => merrors.push('PAGEERROR: ' + e.message));
  await mpage.goto(FILE);
  await mpage.evaluate(s => localStorage.setItem('ww_session_v2', JSON.stringify(s)), SESSION);
  await mpage.goto(FILE);
  await mpage.waitForTimeout(1800);
  const mob = await mpage.evaluate(async () => {
    S.tasks = [
      { id: 'm1', text: 'К врачу', who: 'me', date: todayStr(), prio: 'mid', done: false, created: 1, sphere: 'health' },
      { id: 'm2', text: 'Отчёт', who: 'me', date: todayStr(), prio: 'high', done: false, created: 2, sphere: 'work' }
    ];
    save();
    nav('planner');
    await new Promise(r => setTimeout(r, 700));
    const bar = document.getElementById('ww64-filter').getBoundingClientRect();
    openTaskModal();
    await new Promise(r => setTimeout(r, 600));
    const sel = document.getElementById('ww64-sphere');
    const r = sel.getBoundingClientRect();
    closeModal();
    await new Promise(r2 => setTimeout(r2, 400));
    window.scrollTo(0, document.body.scrollHeight);
    await new Promise(r2 => setTimeout(r2, 400));
    return {
      filterVisible: bar.height > 0,
      selVisible: r.height > 0 && r.width > 100,
      inScreen: r.top >= 0 && r.bottom <= window.innerHeight + 1,
      nav: typeof ww62NavState === 'function' ? ww62NavState() : null,
      chips: document.querySelectorAll('#kanban .ww64-sph-chip').length
    };
  });
  check('на телефоне поле сферы и фильтр видны',
    mob.filterVisible && mob.selVisible && mob.inScreen && mob.chips === 2, mob);
  check('нижняя панель по-прежнему зафиксирована внизу',
    mob.nav && mob.nav.bottomGap === 0 && mob.nav.position === 'fixed', mob.nav);

  const allErrors = errors.concat(merrors);
  console.log('\nERRORS', allErrors);
  await browser.close();
  if (fails.length || allErrors.length) {
    console.log('\nНЕ ПРОШЛИ: ' + fails.length + ' проверок');
    process.exit(1);
  }
  console.log('\nВсе проверки прошли');
})();
