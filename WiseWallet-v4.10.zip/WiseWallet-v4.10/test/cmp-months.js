/* Тест v4.01: «Сравнение месяцев» — оба месяца выбираются вручную. */
const { chromium } = require('playwright');
const path = require('path');
const FILE = process.env.WW_APP || 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };
const clean = (s) => (s || '').replace(/\u00a0/g, ' ');

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const p = await (await b.newContext({ viewport: { width: 1500, height: 950 } })).newPage();
  const errors = [];
  p.on('pageerror', e => errors.push(e.message));

  await p.goto(FILE);
  await p.waitForTimeout(1600);
  await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
  await p.waitForTimeout(400);

  // расходы в трёх разных месяцах, чтобы было что выбирать
  const yms = await p.evaluate(() => {
    S.categories = S.categories.filter(c => c.type !== 'expense').concat([
      { id: 'k1', name: 'Кредиты', type: 'expense', icon: '🏦' },
      { id: 'k2', name: 'Бензин', type: 'expense', icon: '⛽' },
    ]);
    S.transactions = [];
    const now = new Date();
    const mk = (back, a1, a2) => {
      const d = new Date(now.getFullYear(), now.getMonth() - back, 10);
      const ds = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-10';
      S.transactions.push({ id: 'x' + back + 'a', type: 'expense', categoryId: 'k1', amount: a1, date: ds, accountId: (S.accounts[0] || {}).id || 'a1' });
      S.transactions.push({ id: 'x' + back + 'b', type: 'expense', categoryId: 'k2', amount: a2, date: ds, accountId: (S.accounts[0] || {}).id || 'a1' });
      return ds.slice(0, 7);
    };
    const cur = mk(0, 10000, 1000);
    const m1 = mk(1, 20000, 2000);
    const m2 = mk(2, 30000, 3000);
    save(); nav('analytics');
    return { cur, m1, m2 };
  });
  await p.waitForTimeout(1000);

  const inputs = await p.evaluate(() => {
    const a = document.getElementById('ww23-cmp-a'), b = document.getElementById('ww23-cmp-b');
    return { a: a && a.value, b: b && b.value, type: a && a.type };
  });
  check('в карточке появились два поля выбора месяца', inputs.type === 'month', inputs);
  check('по умолчанию сравниваются прошлый и текущий месяц (поведение не изменилось)',
    inputs.a === yms.m1 && inputs.b === yms.cur, { got: inputs, want: { a: yms.m1, b: yms.cur } });

  const defRow = clean(await p.evaluate(() => {
    const rows = [...document.querySelectorAll('#ww23-an-cmp table tr')];
    return rows[rows.length - 1].textContent;
  }));
  check('итог по умолчанию: 22 000 против 11 000', /22 000/.test(defRow) && /11 000/.test(defRow), defRow);

  // выбрать вручную два ПРОШЛЫХ месяца — то, чего раньше было нельзя
  await p.evaluate((y) => { ww23CmpSet('a', y.m2); ww23CmpSet('b', y.m1); }, yms);
  await p.waitForTimeout(400);
  const manual = await p.evaluate(() => {
    const rows = [...document.querySelectorAll('#ww23-an-cmp table tr')];
    return {
      head: rows[0].textContent,
      last: rows[rows.length - 1].textContent,
      a: document.getElementById('ww23-cmp-a').value,
      b: document.getElementById('ww23-cmp-b').value,
    };
  });
  check('КЛЮЧЕВОЕ: можно сравнить два произвольных месяца, оба в прошлом',
    manual.a === yms.m2 && manual.b === yms.m1 && /33 000/.test(clean(manual.last)) && /22 000/.test(clean(manual.last)), manual);

  // заголовки колонок отражают выбранные месяцы
  check('заголовки колонок — выбранные месяцы, а не «прошлый/текущий»',
    clean(manual.head).length > 0 && !/сейчас/.test(clean(manual.head)), clean(manual.head));

  // ⇄ меняет месяцы местами
  await p.evaluate(() => ww23CmpSwap());
  await p.waitForTimeout(400);
  const swapped = await p.evaluate(() => ({ a: document.getElementById('ww23-cmp-a').value, b: document.getElementById('ww23-cmp-b').value }));
  check('кнопка ⇄ меняет месяцы местами', swapped.a === yms.m1 && swapped.b === yms.m2, swapped);

  // ↺ возвращает значения по умолчанию
  await p.evaluate(() => ww23CmpReset());
  await p.waitForTimeout(400);
  const reset = await p.evaluate(() => ({ a: document.getElementById('ww23-cmp-a').value, b: document.getElementById('ww23-cmp-b').value }));
  check('кнопка ↺ возвращает прошлый и текущий месяц', reset.a === yms.m1 && reset.b === yms.cur, reset);

  // месяц без данных — понятная заглушка, а не пустая таблица
  await p.evaluate(() => { ww23CmpSet('a', '2005-01'); ww23CmpSet('b', '2005-02'); });
  await p.waitForTimeout(400);
  const empty = clean(await p.evaluate(() => document.getElementById('ww23-an-cmp').textContent));
  check('для месяцев без расходов показана понятная заглушка', /сравнивать нечего/.test(empty), empty.slice(0, 90));

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));
  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
