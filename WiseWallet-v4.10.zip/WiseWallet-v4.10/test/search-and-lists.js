/* Тесты v3.57: виртуализация списка, подписи полей, глобальный поиск */
const { chromium } = require('playwright');
const FILE = process.env.WW_APP || 'file://' + require('path').resolve(__dirname, '../index.html');
const fails = [];
function check(name, cond, extra) {
  console.log((cond ? '  ok   ' : '  FAIL ') + name + (extra !== undefined ? '  -> ' + JSON.stringify(extra) : ''));
  if (!cond) fails.push(name);
}

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text())) errors.push('CONSOLE: ' + m.text()); });

  await page.goto(FILE);
  await page.evaluate(() => localStorage.setItem('ww_session_v2', JSON.stringify({ access_token: 'x.y.z', refresh_token: 'r', expires_at: Date.now() + 3600e3, user_id: '00000000-0000-4000-8000-000000000001', email: 't357@test.local' })));
  await page.goto(FILE);
  await page.waitForTimeout(1800);

  check('версия приложения задана', /^\d+\.\d+$/.test(String(await page.evaluate(() => WW_VERSION))), await page.evaluate(() => WW_VERSION));

  /* ---------- данные для тестов ---------- */
  const ids = await page.evaluate(() => {
    const a = S.accounts.filter(x => !x.archived)[0];
    const exp = S.categories.filter(c => c.type === 'expense')[0];
    const inc = S.categories.filter(c => c.type === 'income')[0];
    const t = todayStr();
    S.transactions = [];
    for (let i = 0; i < 900; i++) {
      S.transactions.push({ id: uid(), date: t, type: 'expense', amount: 10 + i, accountId: a.id, categoryId: exp.id, tags: [], note: 'Строка ' + i, createdAt: Date.now() - i });
    }
    S.transactions.push({ id: 'TX-NEEDLE', date: t, type: 'income', amount: 54321, accountId: a.id, categoryId: inc.id, tags: ['маркер'], note: 'Уникальная премия Абракадабра', createdAt: Date.now() });
    S.notes = [{ id: 'N-1', body: 'Заметка про квартиру\nсчётчики и показания', folder: 'Заметки', updatedAt: Date.now() }];
    S.tasks = [{ id: 'T-1', summary: 'Оплатить садик', date: t, done: false, createdAt: Date.now() }];
    S.links = [{ id: 'L-1', title: 'Налоговая служба', url: 'https://nalog.gov.ru', category: 'Госуслуги' }];
    S.passwords = [{ id: 'P-1', title: 'Сбербанк', login: 'ivan', password: 'СЕКРЕТНЫЙПАРОЛЬ', category: 'Банки' }];
    S.goals = [{ id: 'G-1', name: 'Отпуск в Сочи', target: 200000, icon: '🏖' }];
    save();
    return { acc: a.id, exp: exp.id, inc: inc.id };
  });

  /* =================== 1. ВИРТУАЛИЗАЦИЯ =================== */
  console.log('\n1. Виртуализация длинного списка');
  const v1 = await page.evaluate(async () => {
    nav('ops');
    await new Promise(r => setTimeout(r, 400));
    const t0 = performance.now();
    renderOps();
    await new Promise(r => setTimeout(r, 60));
    return {
      ms: Math.round(performance.now() - t0),
      rows: document.querySelectorAll('#ops-list [data-sid]').length,
      nodes: document.querySelectorAll('*').length,
      total: window.ww57Total,
      cap: window.ww57Cap,
      moreBtn: !!document.getElementById('ww57-more-btn'),
      footText: (document.getElementById('ww57-more') || {}).textContent || '',
    };
  });
  check('сразу рисуется только первая порция (≤200 из 901)', v1.rows > 0 && v1.rows <= 200 && v1.total === 901, v1);
  check('DOM остаётся компактным (<9000 узлов)', v1.nodes < 9000, v1.nodes);
  check('показан счётчик и кнопка «Показать ещё»', v1.moreBtn && /Показано 200 из 901/.test(v1.footText), v1.footText.slice(0, 60));

  await page.click('#ww57-more-btn');
  await page.waitForTimeout(400);
  const v2 = await page.evaluate(() => ({
    rows: document.querySelectorAll('#ops-list [data-sid]').length,
    cap: window.ww57Cap,
    moreBtn: !!document.getElementById('ww57-more-btn'),
  }));
  check('«Показать ещё» догружает следующую порцию', v2.rows > v1.rows && v2.cap === 400, v2);

  const v3 = await page.evaluate(async () => {
    const q = document.getElementById('ops-q');
    q.value = 'Строка 1';
    renderOps();
    await new Promise(r => setTimeout(r, 80));
    return { cap: window.ww57Cap, rows: document.querySelectorAll('#ops-list [data-sid]').length, total: window.ww57Total };
  });
  check('при смене фильтра окно сбрасывается к первой порции', v3.cap === 200, v3);

  const v4 = await page.evaluate(async () => {
    const q = document.getElementById('ops-q');
    q.value = '';
    renderOps();
    await new Promise(r => setTimeout(r, 60));
    const before = document.querySelectorAll('#ops-list [data-sid]').length;
    /* маленький архив — кнопки быть не должно */
    const keep = S.transactions.slice(0, 12);
    window.__all = S.transactions;
    S.transactions = keep;
    renderOps();
    await new Promise(r => setTimeout(r, 60));
    const small = { rows: document.querySelectorAll('#ops-list [data-sid]').length, more: !!document.getElementById('ww57-more') };
    S.transactions = window.__all;
    renderOps();
    return { before: before, small: small };
  });
  check('на коротком списке подвала нет', v4.small.rows === 12 && v4.small.more === false, v4);

  /* =================== 4. ПОДПИСИ ПОЛЕЙ =================== */
  console.log('\n4. Подписи полей ввода');
  const lab = await page.evaluate(() => {
    const bad = [];
    document.querySelectorAll('input,select,textarea').forEach(i => {
      if (i.type === 'hidden') return;
      const ok = i.getAttribute('aria-label') || i.placeholder || (i.id && document.querySelector('label[for="' + i.id + '"]'));
      if (!ok) bad.push(i.id || i.tagName);
    });
    return { unlabeled: bad, month: (document.getElementById('ops-month') || {}).getAttribute && document.getElementById('ops-month').getAttribute('aria-label'), type: document.getElementById('ops-type').getAttribute('aria-label') };
  });
  check('нет полей без подписи', lab.unlabeled.length === 0, lab.unlabeled);
  check('осмысленные подписи у фильтров', /Месяц/.test(lab.month || '') && /Тип/.test(lab.type || ''), lab);

  /* поля в модальных окнах тоже подписаны (MutationObserver) */
  await page.evaluate(() => { openTxModal(); });
  await page.waitForTimeout(500);
  const labModal = await page.evaluate(() => {
    const bad = [];
    document.querySelectorAll('#modal input,#modal select,#modal textarea,.modal input,.modal select,.modal textarea').forEach(i => {
      if (i.type === 'hidden') return;
      const ok = i.getAttribute('aria-label') || i.placeholder || (i.id && document.querySelector('label[for="' + i.id + '"]'));
      if (!ok) bad.push(i.id || i.tagName);
    });
    return bad;
  });
  check('поля в окне операции тоже подписаны', labModal.length === 0, labModal);
  await page.evaluate(() => closeModal());
  await page.waitForTimeout(250);

  /* =================== 6. ГЛОБАЛЬНЫЙ ПОИСК =================== */
  console.log('\n6. Глобальный поиск Ctrl+K');
  await page.keyboard.press('Control+k');
  await page.waitForTimeout(400);
  const open1 = await page.evaluate(() => ({
    on: (document.getElementById('ww57-pal-ov') || {}).className || '',
    focused: (document.activeElement || {}).id,
    groups: Array.from(document.querySelectorAll('#ww57-res .gh')).map(e => e.textContent),
  }));
  check('Ctrl+K открывает палитру и ставит фокус в поле', /\bon\b/.test(open1.on) && open1.focused === 'ww57-q', open1);
  check('по умолчанию предлагаются действия и разделы', open1.groups.some(g => /Действия/.test(g)) && open1.groups.some(g => /Разделы/.test(g)), open1.groups);

  await page.fill('#ww57-q', 'Абракадабра');
  await page.waitForTimeout(350);
  const found = await page.evaluate(() => Array.from(document.querySelectorAll('#ww57-res .it')).map(e => e.textContent));
  check('находит операцию по тексту заметки', found.length === 1 && /Абракадабра/.test(found[0]), found);

  await page.keyboard.press('Enter');
  await page.waitForTimeout(900);
  const jumped = await page.evaluate(() => ({
    page: activePage ? activePage() : (document.querySelector('.page.active') || {}).id,
    palOpen: (document.getElementById('ww57-pal-ov') || {}).classList.contains('on'),
    hit: !!document.querySelector('[data-sid="TX-NEEDLE"]'),
  }));
  check('Enter закрывает поиск и открывает найденную операцию', !jumped.palOpen && jumped.hit, jumped);

  /* поиск по заметкам / задачам / ссылкам / паролям / целям */
  const kinds = await page.evaluate(() => {
    const idx = ww57BuildIndex();
    const byQ = q => {
      const t = q.toLowerCase();
      return idx.filter(r => r.hay.indexOf(t) !== -1).map(r => r.kind + ': ' + r.t1);
    };
    return {
      note: byQ('счётчики'),
      task: byQ('садик'),
      link: byQ('nalog'),
      pass: byQ('сбербанк'),
      goal: byQ('сочи'),
      secretLeak: idx.filter(r => r.hay.indexOf('секретныйпароль') !== -1).length,
    };
  });
  check('ищет заметки', kinds.note.some(x => /Заметки/.test(x)), kinds.note);
  check('ищет задачи', kinds.task.some(x => /Задачи/.test(x)), kinds.task);
  check('ищет ссылки', kinds.link.some(x => /Ссылки/.test(x)), kinds.link);
  check('ищет записи паролей по названию', kinds.pass.some(x => /Пароли/.test(x)), kinds.pass);
  check('ищет цели', kinds.goal.some(x => /Цели/.test(x)), kinds.goal);
  check('сами пароли в индекс не попадают', kinds.secretLeak === 0, kinds.secretLeak);

  /* переход к заметкам из поиска */
  await page.keyboard.press('Control+k');
  await page.waitForTimeout(300);
  await page.fill('#ww57-q', 'квартиру');
  await page.waitForTimeout(300);
  await page.keyboard.press('Enter');
  await page.waitForTimeout(900);
  const toNotes = await page.evaluate(() => ({ tab: S.settings.vaultTab, page: (document.querySelector('.page.active') || {}).id }));
  check('из поиска открывается вкладка заметок', toNotes.tab === 'notes' && toNotes.page === 'page-vault', toNotes);

  /* стрелки и Esc */
  await page.keyboard.press('Control+k');
  await page.waitForTimeout(300);
  await page.fill('#ww57-q', 'Строка');
  await page.waitForTimeout(320);
  await page.keyboard.press('ArrowDown');
  await page.keyboard.press('ArrowDown');
  const sel = await page.evaluate(() => {
    const el = document.querySelector('#ww57-res .it.sel');
    return { i: el && el.getAttribute('data-i'), count: document.querySelectorAll('#ww57-res .it').length };
  });
  check('стрелки перемещают выбор', sel.i === '2', sel);
  await page.keyboard.press('Escape');
  await page.waitForTimeout(300);
  check('Esc закрывает палитру', await page.evaluate(() => !document.getElementById('ww57-pal-ov').classList.contains('on')));

  /* кнопка поиска в интерфейсе и справка по клавишам */
  const btn = await page.evaluate(() => {
    const b = document.getElementById('ww57-search-btn');
    if (!b) return null;
    const r = b.getBoundingClientRect();
    return { w: Math.round(r.width), h: Math.round(r.height), label: b.getAttribute('aria-label') };
  });
  check('в интерфейсе есть кнопка поиска', !!btn && btn.h >= 28, btn);
  const keysDoc = await page.evaluate(() => WW331_KEYS.map(k => k[0]).join(' | '));
  check('горячая клавиша есть в справке', /Ctrl\+K/.test(keysDoc), keysDoc);

  /* поиск не ломает ввод в полях */
  await page.evaluate(() => {
    try { closeModal(); } catch (e) {}
    try { wwScrollUnlock(); } catch (e) {}
    document.querySelectorAll('#overlay,.overlay,.dlg-ov').forEach(o => o.classList.remove('open'));
    nav('ops');
  });
  await page.waitForTimeout(500);
  await page.click('#ops-q');
  await page.type('#ops-q', 'Строка 5');
  await page.waitForTimeout(300);
  const typed = await page.evaluate(() => ({ v: document.getElementById('ops-q').value, pal: document.getElementById('ww57-pal-ov').classList.contains('on') }));
  check('обычный ввод в полях не трогает палитру', typed.v === 'Строка 5' && !typed.pal, typed);

  console.log('\nERRORS', JSON.stringify(errors));
  if (errors.length) fails.push('ошибки в консоли');
  await browser.close();
  console.log(fails.length ? '\nПРОВАЛЫ: ' + JSON.stringify(fails) : '\nВсе проверки прошли');
  process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
