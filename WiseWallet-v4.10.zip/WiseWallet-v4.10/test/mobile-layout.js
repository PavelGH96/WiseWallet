/* Тесты v4.04: мобильная вёрстка и читаемость.

   Что ловим (всё измерено до правки):
   1. Строка операции разваливалась: на 390 px под текст оставалось 16 px,
      на 360 px — 0 px, высота строки 122 px из-за переноса даты на три
      строки. Три кнопки в строке съедали 126 px.
   2. Последняя строка списка была накрыта плавающей кнопкой «+».
   3. Вторичный текст .sub давал контраст 2,54 при норме 4,5.
   4. На «Операциях» до первой записи шёл почти целый экран фильтров.
   5. Ярлыки быстрого ввода обрезали названия до «Заработна…». */
const { chromium } = require('playwright');
const path = require('path');
const FILE = process.env.WW_APP || 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

const lum = c => { const [r, g, b] = c.map(v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }); return 0.2126 * r + 0.7152 * g + 0.0722 * b; };
const ratio = (a, b) => { const l1 = lum(a), l2 = lum(b); return +(((Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05))).toFixed(2); };
const parse = s => (s.match(/\d+/g) || [0, 0, 0]).slice(0, 3).map(Number);

const seed = () => {
  const acc = (S.accounts[0] || {}).id || 'a1';
  S.categories = S.categories.filter(c => c.type === 'income').concat([{ id: 'e1', name: 'Кафе/доставка еды', type: 'expense', icon: '☕' }]);
  S.transactions = [...Array(12)].map((_, i) => ({ id: 't' + i, type: 'expense', categoryId: 'e1', amount: 900 + i, date: todayStr(), accountId: acc, whose: 'me', note: 'обед с коллегами', tags: [] }));
  save(); nav('ops');
};

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const errors = [];

  /* ---- 1. Строка операции на телефонах разной ширины ---- */
  for (const w of [360, 390, 430]) {
    const p = await (await b.newContext({ viewport: { width: w, height: 844 }, isMobile: true, hasTouch: true })).newPage();
    p.on('pageerror', e => errors.push(w + 'px: ' + e.message));
    await p.goto(FILE); await p.waitForTimeout(1500);
    await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
    await p.evaluate(seed); await p.waitForTimeout(700);

    const r = await p.evaluate(() => {
      const row = document.querySelector('#ops-list .row');
      const main = row.querySelector('.rmain');
      const amt = row.querySelector('.ramt');
      const vis = [...row.querySelectorAll('button')].filter(x => x.offsetParent !== null);
      return {
        textW: Math.round(main.getBoundingClientRect().width),
        h: Math.round(row.getBoundingClientRect().height),
        visBtns: vis.length,
        minTap: vis.length ? Math.min(...vis.map(x => Math.round(Math.min(x.getBoundingClientRect().width, x.getBoundingClientRect().height)))) : 0,
        overlap: Math.round(main.getBoundingClientRect().right - amt.getBoundingClientRect().left),
      };
    });
    check('КЛЮЧЕВОЕ: на ' + w + 'px под текст остаётся ≥80px (было 0–56)', r.textW >= 80, r);
    check('строка не раздувается переносами на ' + w + 'px (≤80px)', r.h <= 80, r.h);
    check('на ' + w + 'px в строке одна кнопка действий, а не три', r.visBtns === 1, r.visBtns);
    check('цель нажатия ≥40px на ' + w + 'px', r.minTap >= 40, r.minTap);
    check('текст не наезжает на сумму на ' + w + 'px', r.overlap <= 0, r.overlap);
    await p.context().close();
  }

  /* ---- остальное на 390px ---- */
  const p = await (await b.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true })).newPage();
  p.on('pageerror', e => errors.push(e.message));
  await p.goto(FILE); await p.waitForTimeout(1500);
  await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
  await p.evaluate(seed); await p.waitForTimeout(700);

  /* меню действий открывается и содержит все три команды */
  const menu = await p.evaluate(() => {
    document.querySelector('#ops-list .row .ww404-more').click();
    const txt = document.querySelector('.ww26-sheet') ? document.querySelector('.ww26-sheet').textContent : '';
    return { txt, opts: document.querySelectorAll('.ww26-sheet .opt').length };
  });
  check('меню «⋮» даёт повтор, правку и удаление', menu.opts === 3 && /Повторить/.test(menu.txt) && /Изменить/.test(menu.txt) && /Удалить/.test(menu.txt), menu.opts);
  await p.evaluate(() => closeModal());
  await p.waitForTimeout(300);

  /* ---- 2. Последняя строка не накрыта плавающей кнопкой ---- */
  await p.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
  await p.waitForTimeout(400);
  const fab = await p.evaluate(() => {
    const rows = [...document.querySelectorAll('#ops-list .row')];
    const last = rows[rows.length - 1].getBoundingClientRect();
    const f = document.querySelector('.fab');
    if (!f) return { noFab: true };
    const q = f.getBoundingClientRect();
    return { covered: !(q.right < last.left || q.left > last.right || q.bottom < last.top || q.top > last.bottom) };
  });
  check('КЛЮЧЕВОЕ: кнопка «+» не накрывает последнюю строку списка', fab.noFab || fab.covered === false, fab);

  /* правая панель уходит за край на время прокрутки */
  const away = await p.evaluate(async () => {
    const bar = document.querySelector('.ww331-bar');
    if (!bar) return { noBar: true };
    window.scrollTo(0, 200);
    window.dispatchEvent(new Event('scroll'));
    await new Promise(r => setTimeout(r, 60));
    const hidden = bar.classList.contains('ww404-away');
    await new Promise(r => setTimeout(r, 750));
    return { hidden, backAfterStop: !bar.classList.contains('ww404-away') };
  });
  check('правая панель уходит за край при прокрутке и возвращается', away.noBar || (away.hidden && away.backAfterStop), away);

  /* ---- 3. Контраст вторичного текста во всех темах ---- */
  for (const th of ['t9', 't1', 't3', 't10']) {
    const r = await p.evaluate((t) => {
      document.body.dataset.theme = t;
      const sub = document.querySelector('.sub'), card = document.querySelector('.card');
      return { sub: getComputedStyle(sub).color, card: getComputedStyle(card).backgroundColor };
    }, th);
    const cr = ratio(parse(r.sub), parse(r.card));
    check('КЛЮЧЕВОЕ: контраст .sub ≥4.5 в теме ' + th + ' (было 2.54)', cr >= 4.5, cr);
  }
  await p.evaluate(() => { document.body.dataset.theme = 't9'; });

  /* ---- 4. Фильтры свёрнуты, счётчик активных работает ---- */
  const f1 = await p.evaluate(() => ({
    hidden: document.getElementById('ops-filters').offsetParent === null,
    btn: document.querySelector('.ww404-filters-btn').offsetParent !== null,
    listTop: Math.round(document.getElementById('ops-list').getBoundingClientRect().top),
  }));
  check('КЛЮЧЕВОЕ: на телефоне фильтры свёрнуты за кнопку', f1.hidden && f1.btn, f1);
  check('список начинается в пределах первого экрана', f1.listTop < 500, f1.listTop);

  const f2 = await p.evaluate(() => {
    ww404OpsFilters();
    const t = document.getElementById('ops-type');
    t.value = 'expense'; t.dispatchEvent(new Event('change', { bubbles: true }));
    return { open: document.getElementById('ops-filters').offsetParent !== null, n: document.getElementById('ops-filters-n').textContent };
  });
  check('фильтры раскрываются по кнопке', f2.open === true, f2);
  check('счётчик показывает число активных фильтров', f2.n === '1', f2.n);

  const f3 = await p.evaluate(() => {
    const t = document.getElementById('ops-type');
    t.value = ''; t.dispatchEvent(new Event('change', { bubbles: true }));
    return document.getElementById('ops-filters-n').textContent;
  });
  check('счётчик пуст, когда фильтров нет', f3 === '', f3);

  /* ---- 5. Быстрый ввод: ярлыки компактнее, названия не в одну обрезанную строку ---- */
  await p.evaluate(() => nav('dashboard'));
  await p.waitForTimeout(800);
  const coins = await p.evaluate(() => {
    const c = document.querySelector('#coins-cat .coin');
    if (!c) return { none: true };
    const n = c.querySelector('.cname');
    return { w: Math.round(c.getBoundingClientRect().width), lineClamp: getComputedStyle(n).webkitLineClamp };
  });
  check('ярлык компактнее (64px вместо 74px)', coins.none || coins.w === 64, coins);
  check('название может занять две строки, а не обрезаться в одну', coins.none || coins.lineClamp === '2', coins.lineClamp);

  /* ---- общая проверка: нет горизонтальной прокрутки ---- */
  for (const page of ['dashboard', 'ops', 'analytics', 'planner']) {
    await p.evaluate((pg) => nav(pg), page);
    await p.waitForTimeout(600);
    const hs = await p.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1);
    check('нет горизонтальной прокрутки на «' + page + '»', hs === false);
  }

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));
  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
