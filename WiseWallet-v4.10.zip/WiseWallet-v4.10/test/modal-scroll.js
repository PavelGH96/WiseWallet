/* Тесты v3.84: жест закрытия окна не должен мешать прокрутке содержимого.
   Симптом был в разделе «Ссылки»: при открытой клавиатуре окно становится
   прокручиваемым, экран дрожал, а попытка прокрутить вверх закрывала окно. */
const { chromium } = require('playwright');
const path = require('path');
const FILE = 'file://' + path.resolve(__dirname, '..', 'index.html');
const fails = [];
const check = (n, ok, d) => { console.log((ok ? '  ok   ' : '  FAIL ') + n + (d === undefined ? '' : '  -> ' + JSON.stringify(d))); if (!ok) fails.push(n); };

async function swipeFrom(p, sel, dy) {
  await p.evaluate(({ sel, dy }) => {
    const el = document.querySelector(sel);
    const r = el.getBoundingClientRect();
    const x = Math.round(r.left + r.width / 2), y1 = Math.round(r.top + r.height / 2);
    const mk = (t, cy) => {
      const tt = new Touch({ identifier: 1, target: el, clientX: x, clientY: cy });
      return new TouchEvent(t, { touches: t === 'touchend' ? [] : [tt], changedTouches: [tt], bubbles: true, cancelable: true });
    };
    el.dispatchEvent(mk('touchstart', y1));
    for (let i = 1; i <= 8; i++) el.dispatchEvent(mk('touchmove', y1 + dy * i / 8));
    el.dispatchEvent(mk('touchend', y1 + dy));
  }, { sel, dy });
  await p.waitForTimeout(400);
}

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const errors = [];

  for (const [label, h, scrollable] of [['окно влезает целиком', 932, false], ['окно прокручивается (клавиатура)', 420, true]]) {
    const ctx = await b.newContext({ viewport: { width: 430, height: h }, isMobile: true, hasTouch: true, deviceScaleFactor: 3 });
    const p = await ctx.newPage();
    p.on('pageerror', e => errors.push(e.message));
    await p.goto(FILE);
    await p.waitForTimeout(1500);
    await p.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
    await p.evaluate(() => { S.links = [{ id: 'l1', title: 'Т', category: 'Ф', url: 'https://e.com', created: Date.now() }]; save(); nav('links'); });
    await p.waitForTimeout(400);
    await p.evaluate(() => openLinkModal('l1'));
    await p.waitForTimeout(400);

    console.log('--- ' + label + ' ---');
    const isScroll = await p.evaluate(() => { const m = document.getElementById('modal'); return m.scrollHeight > m.clientHeight + 1; });
    check('состояние воспроизведено (прокрутка=' + scrollable + ')', isScroll === scrollable, isScroll);

    check('«ручка» для свайпа показана', await p.evaluate(() => getComputedStyle(document.querySelector('.modal .mhead'), '::before').width) === '38px');

    await swipeFrom(p, '#ln-url', 170);
    const openAfterField = await p.evaluate(() => document.getElementById('overlay').classList.contains('open'));
    if (scrollable) {
      check('КЛЮЧЕВОЕ: свайп по полю НЕ закрывает окно, прокрутка свободна', openAfterField === true, openAfterField);
    } else {
      check('когда прокрутки нет — свайп по содержимому закрывает, как раньше', openAfterField === false, openAfterField);
      await p.evaluate(() => openLinkModal('l1'));
      await p.waitForTimeout(400);
    }

    await swipeFrom(p, '.modal .mhead', 170);
    check('свайп по шапке закрывает окно всегда', (await p.evaluate(() => document.getElementById('overlay').classList.contains('open'))) === false);
    await ctx.close();
  }

  // ===== Проверка по ВСЕМ разделам: механизм один, но убеждаемся практикой =====
  const ctx2 = await b.newContext({ viewport: { width: 430, height: 400 }, isMobile: true, hasTouch: true, deviceScaleFactor: 3 });
  const p2 = await ctx2.newPage();
  p2.on('pageerror', e => errors.push(e.message));
  await p2.goto(FILE);
  await p2.waitForTimeout(1500);
  await p2.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
  await p2.evaluate(() => {
    S.links = [{ id: 'l1', title: 'Т', category: 'Ф', url: 'https://e.com', created: Date.now() }];
    S.goals = [{ id: 'g1', name: 'Цель', target: 10000, saved: 100, icon: '🎯' }];
    S.passwords = [{ id: 'p1', title: 'Почта', login: 'a@b.c', password: 'x', url: '', note: '' }];
    S.tasks = [{ id: 't1', title: 'Задача', done: false, prio: 2, created: Date.now() }];
    save();
  });

  const cases = [
    ['операция', 'openTxModal()'],
    ['кредит', 'openCreditModal()'],
    ['регулярный платёж', 'openRecurModal()'],
    ['бюджет', 'openBudgetModal()'],
    ['цель', "openGoalModal('g1')"],
    ['ссылка', "openLinkModal('l1')"],
    ['пароль', "openPassModal('p1')"],
    ['задача', "openTaskModal('t1')"],
    ['перевод', 'openTransferModal()'],
  ];
  const bad = [];
  for (const [name, call] of cases) {
    await p2.evaluate(v => { try { eval(v); } catch (e) {} }, call);
    await p2.waitForTimeout(350);
    const scrollable = await p2.evaluate(() => { const m = document.getElementById('modal'); return m.scrollHeight > m.clientHeight + 1; });
    const field = await p2.evaluate(() => { const i = document.querySelector('#modal input,#modal select,#modal textarea'); return i && i.id ? '#' + i.id : null; });
    if (scrollable && field) {
      await swipeFrom(p2, field, 150);
      const stillOpen = await p2.evaluate(() => document.getElementById('overlay').classList.contains('open'));
      if (!stillOpen) bad.push(name + ': свайп по содержимому закрыл окно');
      else {
        await swipeFrom(p2, '.modal .mhead', 150);
        const closed = !(await p2.evaluate(() => document.getElementById('overlay').classList.contains('open')));
        if (!closed) bad.push(name + ': свайп по шапке не закрыл окно');
      }
    }
    await p2.evaluate(() => { try { closeModal(); } catch (e) {} });
    await p2.waitForTimeout(120);
  }
  check('во всех разделах окна ведут себя правильно (9 видов окон)', bad.length === 0, bad);
  await ctx2.close();

  // ===== Заметка: прокручивается ВНУТРЕННЕЕ поле, а не окно (v3.86) =====
  // Отдельный случай: окно помещается целиком, но текст заметки длинный и
  // прокручивается сам. Раньше жест закрытия перехватывал такую прокрутку.
  for (const [label2, h2] of [['высокий экран', 932], ['клавиатура открыта', 400]]) {
    const ctx3 = await b.newContext({ viewport: { width: 430, height: h2 }, isMobile: true, hasTouch: true, deviceScaleFactor: 3 });
    const p3 = await ctx3.newPage();
    p3.on('pageerror', e => errors.push(e.message));
    await p3.goto(FILE);
    await p3.waitForTimeout(1500);
    await p3.evaluate(() => { ['ww-splash', 'ww-lock', 'ww-auth', 'ww332-gate'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); });
    await p3.evaluate(() => {
      const long = Array.from({ length: 60 }, (_, i) => 'Строка заметки номер ' + (i + 1) + ' с довольно длинным текстом.').join('\n');
      S.notes = [{ id: 'n1', body: long, folder: 'Заметки', updated: Date.now(), created: Date.now() }];
      save();
    });
    await p3.evaluate(() => ww41Open('n1'));
    await p3.waitForTimeout(500);

    console.log('--- заметка, ' + label2 + ' ---');
    const inner = await p3.evaluate(() => {
      const ta = document.getElementById('ww41-body');
      return ta ? ta.scrollHeight > ta.clientHeight + 1 : false;
    });
    check('текст заметки действительно прокручивается', inner === true, inner);

    await swipeFrom(p3, '#ww41-body', 150);
    check('свайп по тексту заметки НЕ закрывает окно',
      (await p3.evaluate(() => document.getElementById('overlay').classList.contains('open'))) === true);

    await swipeFrom(p3, '.modal .mhead', 150);
    check('свайп по шапке закрывает заметку',
      (await p3.evaluate(() => document.getElementById('overlay').classList.contains('open'))) === false);
    await ctx3.close();
  }

  check('ошибок в консоли нет', errors.length === 0, errors.slice(0, 3));
  await b.close();
  console.log('\n' + (fails.length ? 'ПРОВАЛЫ: ' + fails.join(', ') : 'все проверки прошли'));
  process.exit(fails.length ? 1 : 0);
})();
